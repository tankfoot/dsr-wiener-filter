/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*---------------------------------------------------------------------------
 *
 * FILE NAME: common_VAD.h
 * PURPOSE:   header for ExtCoder_VAD and ExtDecoder_VAD of Extended DSR
 *            compression   
 *
 *---------------------------------------------------------------------------*/


#ifndef TRUE
#define TRUE (1==1)
#define FALSE !TRUE
#endif




#define SYNC_SEQ  0x87b2
#define INV_SYNC_SEQ  0x784d



#define ONE_FRAME 0
#define TWO_FRAMES !ONE_FRAME



/*defines for the DSR header*/

#define track1  0x0
#define track2  0x1


#define eight_kHz  0x0
#define eleven_kHz 0x1
#define sixteen_kHz 0x3


/*Not used in DSR header anymore, but used elsewhere in code.*/
#define standard  0

#define last_frame 1
#define error -1


/****************************/

#define feType  track1 

unsigned char sampRate = eight_kHz; /*Can be 00 (8), 01 (11) or 11 (16). Set by a command line flag.*/



/*HTK File formats.*/


#define EXPECTED_SAMP_PERIOD 100000  /*100,000  100ns = 10,000 us*/

#define EXPECTED_SAMP_SIZE 56  /*14 * 4 byte floats*/

#define EXPECTED_PARM_KIND 8262 /* HTK header parameter type MFCC_E_0 */


/*Structures for HTK Files*/


typedef struct HTK_DataFrame{
                          float c1;
                          float c2;
                          float c3;
                          float c4;
                          float c5;
                          float c6;
                          float c7;
                          float c8;
                          float c9;
                          float c10;
                          float c11;
                          float c12;
                          float c0;
                          float logE;
			  int VAD;
                          }HTK_DataFrame;

typedef struct HTK_Header{
                          unsigned int nSamples;
                          unsigned int sampPeriod;
                          unsigned short int sampSize;
                          unsigned short int parmKind;
                          }HTK_Header;

