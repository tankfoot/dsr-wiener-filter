/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*---------------------------------------------------------------------------
 *
 * FILE NAME: ExtDecoder_VAD.c
 * PURPOSE:   This file contains the main program for the decoding of the 
 *	      Extended Distributed Speech Recognition (DSR) Advanced
 *            Front-End.  It performs decompression and error mitigation
 *            of the binary bitstream format for the Extended Advanced DSR
 *            standard proposal.
 *
 * INPUT:     ExtDecoder_VAD reads the binary DSR bitstream format file 
 *
 * OUTPUT:    ExtDecoder_VAD creates 1) HTK format file containing the
 *            Mel-Cepstrum parameters after decompression containing both
 *            C0 and logE, 2) Pitch Period file containing the pitch
 *            period value after decompression, 3) Classification
 *            file containing the class information, and 4) Error status
 *            file.  It also creates an aditional ascii file containing
 *            the VAD flag.
 *
 *---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include "common_VAD.h"
#include "ExtGolay.h"


/*include the quantiser tables*/

#include "quantiser_16kHz_Oct03_2002.tab"
#include "quantiser_8kHz_Oct03_2002.tab"




/*Structures to hold the bitstream.*/

typedef struct dframe{
  unsigned char a[7];
  unsigned char b[7];
  unsigned char crc;
  unsigned char pitch1_index;
  unsigned char pitch2_index;
  unsigned char class1_index;
  unsigned char class2_index;
}dframe;


typedef struct mframe{
  unsigned char sync[2];
  unsigned char golay[4];
  unsigned char data[162];
}mframe;


typedef struct golaydata{
  unsigned short int data;
  unsigned short int crc;
}golaydata;


void init_thresholds(void);
int process_two_frames(dframe **BufferedDFrames, dframe *CurrentDFrame, dframe *LastGoodDFrame, dframe *PreviousDFrame,  
                        int *dataframes_buffered, int endFrames, int buffering_data_mode);
int find_good_golay(mframe **BufferedMultiFrames, golaydata **BufferedGolays, short int *GoodGolay, int *frames_buffered);
void add_to_buffer(dframe **BufferedData, dframe *ToBuffer, int buffered_count);
int threshold_error(dframe DataFrame);
void dequantise_dataframe(HTK_DataFrame *result, unsigned char given_index[7]);
void error_correct_and_write(dframe *Left, int Left_a_or_b, dframe *Right, int Right_a_or_b, dframe *BufferedData, int count);
void get_next_golay(golaydata **BufferedGolays, mframe BufferedMultiFrames, int golays_buffered);
int get_next_frame(mframe **BufferedMultiFrames, int frames_buffered);
int sync_error(unsigned char *given_sync, unsigned short int sync);
int get_two_data_frames(dframe *DataFrame, mframe BufferedMultiFrame, int frame);
void write_two_data_frames(dframe given, int numFrames, unsigned char error_status);
void process_params(int argc, char *argv[]);
void write_htk_coefs(HTK_DataFrame *given);
void write_htk_header(HTK_Header *header);
void print_htk_coefs(HTK_DataFrame given);
void inv_quant_pitch_abs(unsigned char cQPIndex, float *pfQuantPeriod);
void inv_quant_pitch_diff(unsigned char cQPIndex, float *pfQPHistory,
                          int *piReliableFlag, float *pfQuantPeriod);
void get_class(unsigned char class_index, float pitch_period,
               unsigned char *class);



#define debug FALSE
/*#define debug TRUE */



/*Thresholds.*/

/* Last speech frame detection for frame detected with bad crc */
#define ZEROS_THRESHOLD 5 

/*if in a crc errored frame, if ZEROS_THRESHOLD out of 7 are zero, assume that this is the lastframe + 1*/



/* Search for errored frames missed by CRC */
#define ERRORS_THRESHOLD 2 

/* When looking at thresholds if ERRORS_THRESHOLD or greater are over the thres then decide it is in error. */



#define DETECTION_THRES_COEF 3.0

/*in relation to s.d.'s of differences from training data*/



/* Some addtional defines for inverse pitch quantization */


#define                 LOG_OF_19               2.94443897917f
#define                 DELTA_WIDTH_1           0.01572601137f
#define                 DELTA_WIDTH_2           0.06442591753f

#ifndef MIN_PERIOD
#define                 MIN_PERIOD              19.0
#endif

#ifndef MAX_PERIOD
#define                 MAX_PERIOD              140.0
#endif

#define                 NUM_MULTI_LEVELS_1      26
#define                 NUM_MULTI_LEVELS_2      24


/***************************************/




FILE *BitStream_File, *HTK_Quantised_Format_File, *VAD_File;
FILE *Quantised_Pitch_Period_File, *Classification_File;
FILE *Error_Status_File;



int dataframes=0; /*Global only for ease of printf statements showing warnings*/


HTK_DataFrame SD, 
              DETECTION_THRESHOLD;



int main(int argc, char *argv[])
{
  HTK_Header header;

  dframe PreviousDFrame, 
         CurrentDFrame, 
         LastGoodDFrame, 
         *BufferedDFrames;

  mframe *BufferedMultiFrames;

  golaydata *BufferedGolays;

  short int GoodGolay = -1;

  int i,
      frame,
      result,
      done,
      frames_buffered,
      dataframes_buffered,
      endFrames,
      buffering_data_mode,
      start_of_data_stream;




  process_params(argc, argv);

  init_thresholds();

  header.nSamples = 0; /*Unknown - will be updated at end by dataframes variable*/

  header.sampPeriod = EXPECTED_SAMP_PERIOD;
  header.sampSize = EXPECTED_SAMP_SIZE;
  header.parmKind = EXPECTED_PARM_KIND;

  write_htk_header(&header);
  /*Will be overwritten later*/


  printf("Dequantising bitstream and creating output files....\n\n");

  

  BufferedMultiFrames = NULL;
  BufferedGolays = NULL;
  buffering_data_mode = TRUE;
  start_of_data_stream = TRUE;
  done = FALSE;
  dataframes_buffered = 0;
  dataframes = 0;
  /************************************************/
  /* Initialization of BufferedDFrames missing!   */
  /* Guenter 23.11.00                             */
  /************************************************/
  BufferedDFrames = NULL;

  while(!done)
  {
    frames_buffered = 1;

    if(get_next_frame(&BufferedMultiFrames, frames_buffered)==EOF)
    {
      #if(debug)
        fprintf(stdout, "End of file found \n");
        fflush(stdout);
      #endif
      frames_buffered--;

      if(start_of_data_stream) /*Couldn't find a good frame to work with.*/
      {
        if(dataframes_buffered > 0) /*incase this file was in fact empty.*/
        {      
          error_correct_and_write(NULL, 0, NULL, 0, BufferedDFrames, dataframes_buffered); 
          free(BufferedDFrames); BufferedDFrames=NULL;
          
          dataframes_buffered = 0;
        }
      }
      else /*Have finished exactly at the end of a multiframe, and thus still have previous data to put out.*/
      {
        if(buffering_data_mode)
        {
          error_correct_and_write(&LastGoodDFrame, 1, &LastGoodDFrame, 1, BufferedDFrames, dataframes_buffered); 
          free(BufferedDFrames); BufferedDFrames=NULL;
          
          dataframes_buffered = 0;
        }
        else
        {
          write_two_data_frames(PreviousDFrame, TWO_FRAMES, '0');
        }


      }
      done = TRUE;
    }
    else /*There are more frames.*/
    {

      get_next_golay(&BufferedGolays, BufferedMultiFrames[frames_buffered - 1], 1); /* the 1 means there is only one golay in buffer now.*/
        /*frames_buffered - 1 will always equal zero here. Included for niceness.*/

      if(GoodGolay == -1) /*i.e. havn't found two good golays that match yet*/
      {

        if(find_good_golay(&BufferedMultiFrames, &BufferedGolays, &GoodGolay, &frames_buffered)) /*Ran out of file before finding a good golay*/
        {
          /******************************************************/
          /* The following loop was moved into the subroutine   */
          /* find_good_golay. Running the loop here over the    */
          /* number of buffered frames is WRONG because there   */
          /* may not exist the same number of buffered Golays   */
          /* than number of buffered frames!                    */
          /*  Guenter 23.11.00                                  */
          /******************************************************/
          /*for(i=0; i<(frames_buffered - 1); i++)
            BufferedGolays[i].data = GoodGolay;*/ 
        }
        else
        {
          printf("Warning: Was unable to find a good golay header before end of file!\n");

          /*Just going to continue and put out all the data as it is.*/
        }



      }
      else /*There is a GoodGolay that has been found, i.e. GoodGolay != -1, only have one buffered golay and MultiFrame here*/
      {

        /*if error, or,  if the data is not the same as the previous golays print a warning but keep the previous header */
        /*The 0x078 mask fixes the bits concerning the header case MULTIFRAMER COUNTER to 1's */
	/*Otherwise the comparation between sucessive frames is always different	*/
	if((golay_errors(&(BufferedGolays[0].data), &(BufferedGolays[0].crc))) || (((0x0078 | BufferedGolays[0].data) ^ (0x0078 | GoodGolay))  != 0x0))if((golay_errors(&(BufferedGolays[0].data), &(BufferedGolays[0].crc))) || ((BufferedGolays[0].data ^ GoodGolay)  != 0x0))
        {
          printf("Warning: A error found in multiframe header: %3d\n", (dataframes/23));

          BufferedGolays[0].data = GoodGolay;
        }
      }
     






      #if(debug)
        fprintf(stdout, "Writing out frames to HTK file\n");
        fflush(stdout);
      #endif

      frame=0; 




      /******************************************************************************/
      /* Processing of Multiframe headers completed and have either found a         */
      /* good Golay header or we have reached the end of the file.                  */
      /*                                                                            */
      /* The next code blocks process the frame packet stream to unquantise the     */
      /* good data frames which have been received without error and handle the     */
      /* data frames received with errors by applying nearest frame error mitigation */
      /******************************************************************************/


      if(start_of_data_stream) /*Try and get first good dataframe.*/
      {
        buffering_data_mode=TRUE; 

        while((frame < (frames_buffered-1)) && (start_of_data_stream))
        {
          i=0;
          while((i<24) && (start_of_data_stream))
          {
            result = get_two_data_frames(&CurrentDFrame, BufferedMultiFrames[frame], i);
            dataframes += 2;

            if(buffering_data_mode)
            {
              if(result & 0x4) /*there is a crc error*/
              {
                dataframes_buffered += 2;
                add_to_buffer(&BufferedDFrames, &CurrentDFrame, dataframes_buffered);
              }
              else
              {
                memcpy(&PreviousDFrame , &CurrentDFrame, sizeof(struct dframe));
                buffering_data_mode = FALSE;
              }
            }
            else
            {
              if(result & 0x4)/*crc is in error*/
              {
                dataframes -= 4; /*Due to the following threshold check.*/
                if(threshold_error(PreviousDFrame))
                {
                  dataframes += 4;

                  dataframes_buffered += 2;
                  add_to_buffer(&BufferedDFrames, &PreviousDFrame, dataframes_buffered);

                  dataframes_buffered += 2;
                  add_to_buffer(&BufferedDFrames, &CurrentDFrame, dataframes_buffered);

                  buffering_data_mode = TRUE;
                }
                else
                {
                  dataframes += 4;
                  
                  if(dataframes_buffered>0)
                  {
                    error_correct_and_write(&PreviousDFrame, 0, &PreviousDFrame, 0, BufferedDFrames, dataframes_buffered); 
                    /*i.e. frame repeat backwards*/
                    free(BufferedDFrames); BufferedDFrames = NULL;
                    dataframes_buffered = 0;
                  }

                  write_two_data_frames(PreviousDFrame, TWO_FRAMES, '0');

                  memcpy(&LastGoodDFrame, &PreviousDFrame, sizeof(struct dframe));

                  dataframes_buffered += 2;
                  add_to_buffer(&BufferedDFrames, &CurrentDFrame, dataframes_buffered);

                  buffering_data_mode = TRUE;
                  start_of_data_stream = FALSE;
                }
              }
              else
              {
                if(dataframes_buffered>0)
                {
                  error_correct_and_write(&PreviousDFrame, 0, &PreviousDFrame, 0, BufferedDFrames, dataframes_buffered); 
                  /*i.e. frame repeat backwards*/
                  free(BufferedDFrames); BufferedDFrames = NULL;
                  dataframes_buffered = 0;
                }

                write_two_data_frames(PreviousDFrame, TWO_FRAMES, '0');

                memcpy(&LastGoodDFrame, &PreviousDFrame, sizeof(struct dframe));

                memcpy(&PreviousDFrame, &CurrentDFrame, sizeof(struct dframe));

                buffering_data_mode = FALSE;

                start_of_data_stream=FALSE;
              }
            }
            i+=2;
          }
          if(start_of_data_stream) frame++; /*avoids incrementing frame when coming out of the loop.*/
        }
      }
      else
        i=0;











         /* main loop of error mitigation code */

        if(!start_of_data_stream)
        {

          while(frame < frames_buffered)
          {
            /*  Note: Do not need to set data frame counter (i) here, since the if statement in the initialisation function above has 
                i = 0;
             */

            while((!done) && (i<24))
            {

   
              endFrames = get_two_data_frames(&CurrentDFrame, BufferedMultiFrames[frame], i);


              switch(endFrames)
              {
                case 0:  /*For case 0 and 4, there is no data in the current frame (0 padding detected) */
                case 4:  /*thus as there is no data, whether the frame had a crc error or not is irrelevant*/
                         if(buffering_data_mode)
                         {
                           error_correct_and_write(&LastGoodDFrame, 1, &LastGoodDFrame, 1, BufferedDFrames, dataframes_buffered); /*Just have to frame repeat*/
                           free(BufferedDFrames); BufferedDFrames = NULL;
                           dataframes_buffered = 0;

                         }
                         else
                         {
                           write_two_data_frames(PreviousDFrame, TWO_FRAMES, '0');
                         }

                         done = TRUE; /*Think that there were no more frames*/
                         i++;
                break;

                /*crc is ok, but only have one HTK frame to write.*/
                case 1:  
                         dataframes++;

                         if(buffering_data_mode) /*i.e. last one was crc errored.*/
                         {
                           if(threshold_error(CurrentDFrame))
                           {
                             dataframes_buffered++;
                             add_to_buffer(&BufferedDFrames, &CurrentDFrame, dataframes_buffered);

                             error_correct_and_write(&LastGoodDFrame, 1, &LastGoodDFrame, 1, BufferedDFrames, dataframes_buffered);
                             /*Frame repeat*/
                             free(BufferedDFrames); BufferedDFrames = NULL;
                             dataframes_buffered = 0;
                           }
                           else
                           {
                             if(dataframes_buffered>0)
                             {
                               error_correct_and_write(&LastGoodDFrame, 1, &CurrentDFrame, 0, BufferedDFrames, dataframes_buffered);
                               free(BufferedDFrames); BufferedDFrames = NULL;
                               dataframes_buffered = 0;
                             }
                             write_two_data_frames(CurrentDFrame, ONE_FRAME, '0'); /*Think this is last frame*/
                           }
                         }
                         else
                         {
                           if(dataframes_buffered>0)
                           {
                             error_correct_and_write(&LastGoodDFrame, 1, &PreviousDFrame, 0, BufferedDFrames, dataframes_buffered);
                             free(BufferedDFrames); BufferedDFrames = NULL;
                             dataframes_buffered = 0;
                           }
                           write_two_data_frames(PreviousDFrame, TWO_FRAMES, '0');
                           write_two_data_frames(CurrentDFrame, ONE_FRAME, '0'); /*Think this is last frame*/
                         }

                         done = TRUE;
                         i++;
                break;


                
                case 5:  /*bad crc and only one HTK Frame to write*/
                         dataframes++;

                         if(buffering_data_mode)
                         {
                           dataframes_buffered++;
                           add_to_buffer(&BufferedDFrames, &CurrentDFrame, dataframes_buffered);

                           error_correct_and_write(&LastGoodDFrame, 1, &LastGoodDFrame, 1, BufferedDFrames, dataframes_buffered);
                           free(BufferedDFrames); BufferedDFrames = NULL;
                           dataframes_buffered = 0;
                         }
                         else
                         {
                           if(threshold_error(PreviousDFrame))
                           {
                             dataframes_buffered+=2;
                             add_to_buffer(&BufferedDFrames, &PreviousDFrame, dataframes_buffered);

                             dataframes_buffered++;
                             add_to_buffer(&BufferedDFrames, &CurrentDFrame, dataframes_buffered);

                             error_correct_and_write(&LastGoodDFrame, 1, &LastGoodDFrame, 1, BufferedDFrames, dataframes_buffered);
                             free(BufferedDFrames); BufferedDFrames = NULL;
                             dataframes_buffered = 0;
                           }
                           else
                           {
                             if(dataframes_buffered > 0)
                             {
                               error_correct_and_write(&LastGoodDFrame, 1, &PreviousDFrame, 0, BufferedDFrames, dataframes_buffered);
                               free(BufferedDFrames); BufferedDFrames = NULL;
                               dataframes_buffered = 0;
                             }
                             write_two_data_frames(PreviousDFrame, TWO_FRAMES, '0');
                             memcpy(&LastGoodDFrame, &PreviousDFrame, sizeof(struct dframe));

                             dataframes_buffered++;
                             add_to_buffer(&BufferedDFrames, &CurrentDFrame, dataframes_buffered);

                             error_correct_and_write(&LastGoodDFrame, 1, &LastGoodDFrame, 1, BufferedDFrames, dataframes_buffered);
                             free(BufferedDFrames); BufferedDFrames = NULL;

                             dataframes_buffered = 0;
                           }                
                         }
                         done = TRUE;
                         i++;
                break;




                case 2:  /*general case here, two frames of data, bad, or good.*/
                case 6:  
                         dataframes += 2;
                         buffering_data_mode = process_two_frames(&BufferedDFrames, &CurrentDFrame, &LastGoodDFrame, &PreviousDFrame,  
                                                                  &dataframes_buffered, endFrames, buffering_data_mode);

                         i += 2;
                break;

                  default: printf("ERROR: unexpected return value for get_two_data_frames().\n");
                           exit(1);

              }

            }

            frame++;
            i=0;
          
          }

        }/*end of start_of_data if*/

    }/*end of if(get_next_frame(&BufferedMultiFrames, frames_buffered)==EOF) statement*/

  }/*end of while(!done) loop*/

  /**********************************************/
  /* fclose was missing!  Guenter 23.11.00      */
  /**********************************************/
  fclose(BitStream_File);
  /**********************************************/
  /* free of memory included! Guenter 23.11.00  */
  /**********************************************/
  if (BufferedMultiFrames != NULL)
	free(BufferedMultiFrames);
  if (BufferedGolays != NULL)
        free(BufferedGolays);


  /*Put HTK header back out*/
  header.nSamples = dataframes;

  rewind(HTK_Quantised_Format_File);
  write_htk_header(&header);
  fflush(HTK_Quantised_Format_File);

  printf("%d samples writen.\n", dataframes);
  fflush(HTK_Quantised_Format_File);
  printf("\nDone !\n");
  fclose(HTK_Quantised_Format_File);
  fclose(Quantised_Pitch_Period_File);
  fclose(Classification_File);
  fclose(Error_Status_File);
  
  if(VAD_File != NULL)
  	{
  	fprintf(VAD_File,"\n");
  	fflush(VAD_File);
  	fclose(VAD_File);
	}


  if(BufferedDFrames!=NULL) /*this is just a check that the code is ok*/
  {  
    printf("\nWarning: Data still left in Buffer dframes %d  frame %d  buffer %d\n", dataframes, frame, dataframes_buffered);

    HTK_Quantised_Format_File = fopen("/org/erl/users/alune/DSR/Found_Unemptied buffer", "a");
    fprintf(HTK_Quantised_Format_File, "mare\n"); /*need to do this cause I can't check all the screen fulls of output.*/
    fclose(HTK_Quantised_Format_File);
  }


  return 0;
}





void init_thresholds(void)
{
  SD.c1 =    5.89043;
  SD.c2 =    4.41609;
  SD.c3 =    3.69742;
  SD.c4 =    3.32596;
  SD.c5 =    3.00301;
  SD.c6 =    2.78532;
  SD.c7 =    2.59213;
  SD.c8 =    2.43293;
  SD.c9 =    2.29550;
  SD.c10 =   2.13293;
  SD.c11 =   2.03381;
  SD.c12 =   1.87658;
  SD.c0 =    17.34211;
  SD.logE =  0.81309;




  DETECTION_THRESHOLD.c1   = DETECTION_THRES_COEF * SD.c1;
  DETECTION_THRESHOLD.c2   = DETECTION_THRES_COEF * SD.c2;
  DETECTION_THRESHOLD.c3   = DETECTION_THRES_COEF * SD.c3;
  DETECTION_THRESHOLD.c4   = DETECTION_THRES_COEF * SD.c4;
  DETECTION_THRESHOLD.c5   = DETECTION_THRES_COEF * SD.c5;
  DETECTION_THRESHOLD.c6   = DETECTION_THRES_COEF * SD.c6;
  DETECTION_THRESHOLD.c7   = DETECTION_THRES_COEF * SD.c7;
  DETECTION_THRESHOLD.c8   = DETECTION_THRES_COEF * SD.c8;
  DETECTION_THRESHOLD.c9   = DETECTION_THRES_COEF * SD.c9;
  DETECTION_THRESHOLD.c10  = DETECTION_THRES_COEF * SD.c10;
  DETECTION_THRESHOLD.c11  = DETECTION_THRES_COEF * SD.c11;
  DETECTION_THRESHOLD.c12  = DETECTION_THRES_COEF * SD.c12;
  DETECTION_THRESHOLD.c0   = DETECTION_THRES_COEF * SD.c0;
  DETECTION_THRESHOLD.logE = DETECTION_THRES_COEF * SD.logE;


  return;
}














int process_two_frames(dframe **BufferedDFrames, dframe *CurrentDFrame, dframe *LastGoodDFrame, dframe *PreviousDFrame,  
                        int *dataframes_buffered, int endFrames, int buffering_data_mode)
{

  if(buffering_data_mode)
  {
    if(endFrames & 0x4) /*crc is in error*/
    {
      (*dataframes_buffered) += 2;
      add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));
    }
    else
    {
      if(threshold_error(*CurrentDFrame))
      {
        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));
      }
      else
      {

        if((*dataframes_buffered)>0)
        {
          error_correct_and_write(LastGoodDFrame, 1, CurrentDFrame, 0, *BufferedDFrames, *dataframes_buffered);
          /*i.e. frame repeat backwards*/
          free(*BufferedDFrames); (*BufferedDFrames) = NULL;
          (*dataframes_buffered) = 0;
        }
        memcpy(PreviousDFrame, CurrentDFrame, sizeof(struct dframe));
        memcpy(LastGoodDFrame, CurrentDFrame, sizeof(struct dframe));

        buffering_data_mode = FALSE;
      }
    }
  }
  else /*Not buffering data mode*/
  {
    if(endFrames & 0x4) /*crc is in error*/
    {
      dataframes -= 4;

      if(threshold_error(*PreviousDFrame))
      {
        dataframes += 4;

        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, PreviousDFrame, (*dataframes_buffered));

        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));

        buffering_data_mode = TRUE;
      }
      else/*threshold of previous is ok*/
      {
        dataframes += 4;

        write_two_data_frames(*PreviousDFrame, TWO_FRAMES, '0');
        memcpy(LastGoodDFrame, PreviousDFrame, sizeof(struct dframe));

        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));

        buffering_data_mode = TRUE;
      }
    }
    else /*crc was ok*/
    {
      write_two_data_frames(*PreviousDFrame, TWO_FRAMES, '0');
      memcpy(LastGoodDFrame, PreviousDFrame, sizeof(struct dframe));

      memcpy(PreviousDFrame, CurrentDFrame, sizeof(struct dframe));
    }
  }



  return buffering_data_mode;

}










int find_good_golay(mframe **BufferedMultiFrames, golaydata **BufferedGolays, short int *GoodGolay, int *frames_buffered) 
{
  /*here we search for two golays that match each other, and have ok crcs.*/

  int i, j,
      end_of_file= FALSE,
      golays_buffered = 1; /*Must equal one since one was got before.*/ 
 
 
 
  /*note: golay_errors() also performs bit correction on the golay.*/

  /*golays_buffered - 1 will always equal zero here. Included for niceness.*/

  if(golay_errors(&((*BufferedGolays)[golays_buffered - 1].data), &((*BufferedGolays)[golays_buffered - 1].crc)))
  {
    printf("Warning: Error found in multiframe header: %3d\n", ((dataframes/23)+(*frames_buffered)-1));
    golays_buffered--; /*i.e. frame header just read in is bad, therefore exclude it from comparison*/
  }

  while(((*GoodGolay) == -1) && (!end_of_file))
  {
    #if(debug)
      fprintf(stdout, "Buffering for a good golay.\n");
      fflush(stdout);
    #endif

    (*frames_buffered)++;
    if(get_next_frame(BufferedMultiFrames, (*frames_buffered))==EOF) /*get another frame to compare with previous one(s)*/
    {
      #if(debug)
        fprintf(stdout, "End of file found while buffering for good golay.\n");
        fflush(stdout);
      #endif

      (*frames_buffered)--;
      end_of_file=TRUE;
    }
    else
    {

      golays_buffered++;
      get_next_golay(BufferedGolays, (*BufferedMultiFrames)[(*frames_buffered) - 1], golays_buffered);

      if(golay_errors((&(*BufferedGolays)[golays_buffered - 1].data), &((*BufferedGolays)[golays_buffered - 1].crc)))
      {
        printf("Warning: Error found in multiframe header: %3d\n", ((dataframes/23)+(*frames_buffered)-1));
        golays_buffered--; /*i.e. frame just read in is bad will exclude it from comparison*/
      }


      for(i=0; i<(golays_buffered - 1); i++)
      {
        /*BufferedGolays[golays_buffered - 1].data since already compared other ones*/

        /*i.e. first have [golay a, golay b] -> test whether a==b ? if so, then we have found a good golay. */
       /*if a!=b then buffer c & have [a,b,c]  don't need to do a==b? since done time b4, only a==c? and b==c?*/

        /*Therefore always compare most recent one (c) with all the others (a,b). and exculde itself from the comparison (i.e. c==c).*/

	/*The 0x078 mask fixes the bits concerning the header case MULTIFRAMER COUNTER to 1's */
	/*Otherwise the comparation between sucessive frames is always different */
	if((0x078 | (*BufferedGolays)[i].data) == (0x0078 | (*BufferedGolays)[golays_buffered - 1].data)) /*i.e. found two that match.*/
        {
          *GoodGolay = (*BufferedGolays)[i].data;
          i = golays_buffered; /*To force loop exit*/


          /*Extract common information bits from header.*/

          sampRate = 0x003 & (*GoodGolay); /*selects which quantisers to use.*/
          /**********************************************************/
          /* The following loop was introduced here to set all buffered  */
          /* golays to GoodGolay. (shifted from main routine)            */
          /*   Guenter 23.11.00                                          */
          /***************************************************************/
             for(j=0; j<(golays_buffered - 1); j++)
		(*BufferedGolays)[j].data = *GoodGolay;      
          
          /*printf("Found Good Header !\n\n");*/ 
        }
      }
    }
  }


  return !end_of_file; /*i.e. if(eof==true) then we havn't found a good golay.*/

}










void add_to_buffer(dframe **BufferedData, dframe *ToBuffer, int buffered_count)
{

  /*buffered_count+1 since may have half a frame at the end. and will want to alloc space for that too.*/

  (*BufferedData) = (struct dframe *) realloc((struct dframe *)(*BufferedData), sizeof(struct dframe) * ((buffered_count+1)/2));

  if((*BufferedData)==NULL)
  {
    printf("Error: Out of memory allocating space for Data !\n");
    exit(1);
  }

  memcpy(&((*BufferedData)[((buffered_count+1)/2) - 1]), ToBuffer, sizeof(struct dframe));


  return;

}






int threshold_error(dframe DataFrame)
{
  HTK_DataFrame difference, first, second;
  int threshold_errors = 0, result = 0;

  dequantise_dataframe(&first, DataFrame.a);
  dequantise_dataframe(&second, DataFrame.b);


  difference.c1   = fabs(second.c1   - first.c1);
  difference.c2   = fabs(second.c2   - first.c2);
  difference.c3   = fabs(second.c3   - first.c3);
  difference.c4   = fabs(second.c4   - first.c4);
  difference.c5   = fabs(second.c5   - first.c5);
  difference.c6   = fabs(second.c6   - first.c6);
  difference.c7   = fabs(second.c7   - first.c7);
  difference.c8   = fabs(second.c8   - first.c8);
  difference.c9   = fabs(second.c9   - first.c9);
  difference.c10  = fabs(second.c10  - first.c10);
  difference.c11  = fabs(second.c11  - first.c11);
  difference.c12  = fabs(second.c12  - first.c12);
  difference.c0   = fabs(second.c0   - first.c0);
  difference.logE = fabs(second.logE - first.logE);



  threshold_errors = 0;

  if((difference.c1 > DETECTION_THRESHOLD.c1)   || (difference.c2 > DETECTION_THRESHOLD.c2))     threshold_errors++;
  if((difference.c3 > DETECTION_THRESHOLD.c3)   || (difference.c4 > DETECTION_THRESHOLD.c4))     threshold_errors++;
  if((difference.c5 > DETECTION_THRESHOLD.c5)   || (difference.c6 > DETECTION_THRESHOLD.c6))     threshold_errors++;
  if((difference.c7 > DETECTION_THRESHOLD.c7)   || (difference.c8 > DETECTION_THRESHOLD.c8))     threshold_errors++;
  if((difference.c9 > DETECTION_THRESHOLD.c9)   || (difference.c10 > DETECTION_THRESHOLD.c10))   threshold_errors++;
  if((difference.c11 > DETECTION_THRESHOLD.c11) || (difference.c12 > DETECTION_THRESHOLD.c12))   threshold_errors++;
  if((difference.c0 > DETECTION_THRESHOLD.c0)   || (difference.logE > DETECTION_THRESHOLD.logE)) threshold_errors++;

  if(threshold_errors >= ERRORS_THRESHOLD)
  {

    printf("Warning: %d Threshold error(s) in multiframe: %3d dataframe %2d or %2d\n", threshold_errors,
        (dataframes/24), (dataframes%24), ((dataframes%24)+1));

    result = -1;

  }


  return result;
}










void dequantise_dataframe(HTK_DataFrame *result, unsigned char *given_index)
{
  result->VAD = given_index[5] & 0x01; /*unpack VAD flag*/
  given_index[5]= given_index[5]>>1; /*move c11 and c12 from transmission postion to evaluation postion*/


  /*Select which quantiser tables to use for dequantisation.*/
  switch(sampRate)
  {
    case eight_kHz:
    case eleven_kHz:    
                     result->c1   = quantiser8kHz_0_1[given_index[0]][0];
                     result->c2   = quantiser8kHz_0_1[given_index[0]][1];
                     result->c3   = quantiser8kHz_2_3[given_index[1]][0];
                     result->c4   = quantiser8kHz_2_3[given_index[1]][1];
                     result->c5   = quantiser8kHz_4_5[given_index[2]][0];
                     result->c6   = quantiser8kHz_4_5[given_index[2]][1];
                     result->c7   = quantiser8kHz_6_7[given_index[3]][0];
                     result->c8   = quantiser8kHz_6_7[given_index[3]][1];
                     result->c9   = quantiser8kHz_8_9[given_index[4]][0];
                     result->c10  = quantiser8kHz_8_9[given_index[4]][1];
                     result->c11  = quantiser8kHz_10_11[given_index[5]][0];
                     result->c12  = quantiser8kHz_10_11[given_index[5]][1];
                     result->c0   = quantiser8kHz_12_13[given_index[6]][0];
                     result->logE = quantiser8kHz_12_13[given_index[6]][1];
                     break;


    case sixteen_kHz:
                     result->c1   = quantiser16kHz_0_1[given_index[0]][0];
                     result->c2   = quantiser16kHz_0_1[given_index[0]][1];
                     result->c3   = quantiser16kHz_2_3[given_index[1]][0];
                     result->c4   = quantiser16kHz_2_3[given_index[1]][1];
                     result->c5   = quantiser16kHz_4_5[given_index[2]][0];
                     result->c6   = quantiser16kHz_4_5[given_index[2]][1];
                     result->c7   = quantiser16kHz_6_7[given_index[3]][0];
                     result->c8   = quantiser16kHz_6_7[given_index[3]][1];
                     result->c9   = quantiser16kHz_8_9[given_index[4]][0];
                     result->c10  = quantiser16kHz_8_9[given_index[4]][1];
                     result->c11  = quantiser16kHz_10_11[given_index[5]][0];
                     result->c12  = quantiser16kHz_10_11[given_index[5]][1];
                     result->c0   = quantiser16kHz_12_13[given_index[6]][0];
                     result->logE = quantiser16kHz_12_13[given_index[6]][1];
                     break;



    default: printf("ERROR: Bad sampling rate.\n");
             exit(1);
  }
  
  
  return;

}





void error_correct_and_write(dframe *Left, int Left_a_or_b, dframe *Right, int Right_a_or_b, dframe *BufferedData, int count)
{
  int i;
  HTK_DataFrame L, R;

  float quant_pitch_left, quant_pitch_right;
  unsigned char class_left, class_right;


  if((Left==NULL) && (Right==NULL)) /*No good left or right data given, thus have to just put out bad data.*/
  {
    printf("Writing out bad data !\n");
  
    for(i=0; i<count; i+=2)
      write_two_data_frames(BufferedData[i/2], TWO_FRAMES, '3');

    if((i%2)!=0) /*in case of odd one at the end.*/
    {
      write_two_data_frames(BufferedData[(count+1)/2], ONE_FRAME, '3');
    }
  }
  else
  {

     /*Dequantise the given good indicies*/

     if (Left_a_or_b == 0)
     {
       dequantise_dataframe(&L, Left->a);
     }
     else
     {
       dequantise_dataframe(&L, Left->b);
     }
     if (Right_a_or_b == 0)
     {
       dequantise_dataframe(&R, Right->a);
     }
     else
     {
       dequantise_dataframe(&R, Right->b);
     }

     inv_quant_pitch_abs(Left->pitch1_index,&quant_pitch_left);
     get_class(Left->class1_index,quant_pitch_left,&class_left);

     inv_quant_pitch_abs(Right->pitch1_index,&quant_pitch_right);
     get_class(Right->class1_index,quant_pitch_right,&class_right);

     for(i=1; i<=((count+1)/2); i++)
     {
       write_htk_coefs(&L);
       fwrite(&quant_pitch_left,4,1,Quantised_Pitch_Period_File);
       fprintf(Classification_File,"%c",class_left);
       fprintf(Error_Status_File,"%c",'1');
     }

     for(i=(((count+1)/2)+1); i<=count; i++)
     {
       write_htk_coefs(&R);
       fwrite(&quant_pitch_right,4,1,Quantised_Pitch_Period_File);
       fprintf(Classification_File,"%c",class_right);
       fprintf(Error_Status_File,"%c",'2');
     }

  }



  return;
}











void get_next_golay(golaydata **BufferedGolays, mframe BufferedMultiFrames, int golays_buffered)
{
  static int last_size=0;
  unsigned char header[4];
  golaydata temp;


#if(debug)
  fprintf(stdout, "get_next_golay:\n");
  fflush(stdout);
#endif

  memcpy(header, BufferedMultiFrames.golay, 4 * sizeof(unsigned char));

  temp.data = 0x00ff & header[0];
  temp.data |= 0xff00 & (header[1]<<8);

  temp.crc = 0x00ff & (header[2]); 
  temp.crc |= 0xff00 & (header[3]<<8);
  
  if(last_size!=golays_buffered)
  {
    (*BufferedGolays) = (struct golaydata *) realloc((struct golaydata *)(*BufferedGolays), sizeof(struct golaydata) *
        golays_buffered);

    if((*BufferedGolays)==NULL)
    {
      printf("Error: Out of memory allocating space for golay !\n");
      exit(1);
    }
    last_size = golays_buffered;
  }


  (*BufferedGolays)[golays_buffered - 1].crc = temp.crc;

  (*BufferedGolays)[golays_buffered - 1].data = temp.data;

#if(debug)
  fprintf(stdout, "next golay read : \n");
  fprintf(stdout, "data: %03x\n", (*BufferedGolays)[golays_buffered - 1].data);
  fprintf(stdout, "crc : %03x\n\n", (*BufferedGolays)[golays_buffered - 1].crc);
  fflush(stdout);
#endif

  return;
}




int get_next_frame(mframe **BufferedMultiFrames, int frames_buffered)
{
  static int last_size=0;
  int i;
  mframe temp;
  unsigned char sync_byte;

#if(debug)
  fprintf(stdout, "get_next_frame\n");
  fflush(stdout);
#endif

  /*read start sync or inv end sync.*/

  /*get sync, lsb first*/

  fread(&sync_byte, sizeof(unsigned char), 1, BitStream_File);

  temp.sync[1] = sync_byte;

  fread(&sync_byte, sizeof(unsigned char), 1, BitStream_File);

  temp.sync[0] = sync_byte;
  
  /*In a realtime system then would perform sync searching here.*/
  /*Not implemented in this release.*/  


  fread(temp.golay, sizeof(unsigned char), 4, BitStream_File);
  fread(temp.data, sizeof(unsigned char), 162, BitStream_File);

  if(feof(BitStream_File)!=0)
    return EOF;


  if(frames_buffered!=last_size)
  {
    (*BufferedMultiFrames) = (struct mframe *) realloc((struct mframe *)(*BufferedMultiFrames), sizeof(struct mframe) * frames_buffered);


    if((*BufferedMultiFrames)==NULL)
    {
      printf("Error: Out of memory allocating space for multiframes !\n");
      exit(1);
    }

    last_size = frames_buffered;
  }


  for(i=0; i<2; i++)
    (*BufferedMultiFrames)[frames_buffered - 1].sync[i] = temp.sync[i];

  for(i=0; i<4; i++)
    (*BufferedMultiFrames)[frames_buffered - 1].golay[i] = temp.golay[i];

  for(i=0; i<162; i++)
    (*BufferedMultiFrames)[frames_buffered - 1].data[i] = temp.data[i];



#if(debug)
  fprintf(stdout, "get_next_frame: %d\n", frames_buffered);

  fprintf(stdout , "sync : %02x", (*BufferedMultiFrames)[frames_buffered - 1].sync[0]);
  fprintf(stdout , "%02x\n", (*BufferedMultiFrames)[frames_buffered - 1].sync[1]);

  fprintf(stdout , "golay : ");

  for(i=0; i<4; i++)
    fprintf(stdout , "%02x", (*BufferedMultiFrames)[frames_buffered - 1].golay[i]);

  fprintf(stdout , "\ndata : ");

  for(i=0;i<162;i++)
    fprintf(stdout , "%02x ", (*BufferedMultiFrames)[frames_buffered - 1].data[i]);

  fprintf(stdout , "\n\n");
#endif

  return 0;

}




int get_two_data_frames(dframe *DataFrame, mframe BufferedMultiFrame, int frame)
{
  static int get_two_pairs=TRUE;

  static unsigned char four_data_frames[27];
  unsigned char two_data_frames[11];

  int index, frames_non_zero=2, zeros_found;

  unsigned char pc_data[14];
  unsigned char pc_crc[2];


/*need to get two pairs here, due to the way they fit. damn.*/


  if(get_two_pairs==TRUE)
  {
    memcpy(four_data_frames, &BufferedMultiFrame.data[frame/4 * 27], sizeof(unsigned char) * 27);

#if(debug)
    printf("mem cpy : ");
    for(index=0;index<27;index++)
      printf("%02x ", BufferedMultiFrame.data[frame/4 * 27 + index]);
    printf("\n");
#endif

    DataFrame->a[0] = (0x3f & four_data_frames[0]);
    DataFrame->a[1] = (0x03 & (four_data_frames[0]>>6));
    DataFrame->a[1] |= (0x3c & (four_data_frames[1]<<2));
    DataFrame->a[2] = (0x0f & (four_data_frames[1]>>4));
    DataFrame->a[2] |= (0x30 & (four_data_frames[2]<<4));
    DataFrame->a[3] = (0x3f & (four_data_frames[2]>>2));
    DataFrame->a[4] = (0x3f & four_data_frames[3]);
    DataFrame->a[5] = (0x03 & (four_data_frames[3]>>6));
    DataFrame->a[5] |= (0x3c & (four_data_frames[4]<<2));
    DataFrame->a[6] = (0x0f & (four_data_frames[4]>>4));
    DataFrame->a[6] |= (0xf0 & (four_data_frames[5]<<4));

    DataFrame->b[0] = (0x0f & (four_data_frames[5])>>4);
    DataFrame->b[0] |= (0x30 & (four_data_frames[6])<<4);
    DataFrame->b[1] = (0x3f & (four_data_frames[6]>>2));
    DataFrame->b[2] = (0x3f & four_data_frames[7]);
    DataFrame->b[3] = (0x03 & (four_data_frames[7]>>6));
    DataFrame->b[3] |= (0x3c & (four_data_frames[8]<<2));
    DataFrame->b[4] = (0x0f & (four_data_frames[8]>>4));
    DataFrame->b[4] |= (0x30 & (four_data_frames[9]<<4));
    DataFrame->b[5] = (0x3f & (four_data_frames[9]>>2));
    DataFrame->b[6] = (0xff & four_data_frames[10]);

    DataFrame->crc = (0x0f & four_data_frames[11]);


    /*
     * Get pitch and class information
     */

    DataFrame->pitch1_index = (0x0f & (four_data_frames[11] >> 4));
    DataFrame->pitch1_index |= (0x70 & (four_data_frames[12] << 4));
    DataFrame->pitch2_index = (0x1f & (four_data_frames[12] >> 3));
    DataFrame->class1_index = (0x01 & four_data_frames[13]);
    DataFrame->class2_index = (0x01 & (four_data_frames[13] >> 1));

    pc_crc[0] = (0x01 & (four_data_frames[13] >> 2));
    pc_crc[1] = (0x01 & (four_data_frames[13] >> 3));

    for (index = 0; index < 7; index++)
    {
      pc_data[index] = (0x01 & (DataFrame->pitch1_index >> index));
    }
    for (index = 7; index < 12; index++)
    {
      pc_data[index] = (0x01 & (DataFrame->pitch2_index >> (index-7)));
    }
    pc_data[12] = (0x01 & DataFrame->class1_index);
    pc_data[13] = (0x01 & DataFrame->class2_index);


    for(index=0; index<11; index++) 
      two_data_frames[index] = four_data_frames[index];


    get_two_pairs=FALSE;

  }
  else
  {

    DataFrame->a[0] = (0x0f & (four_data_frames[13])>>4);
    DataFrame->a[0] |= (0x30 & (four_data_frames[14])<<4);
    DataFrame->a[1] = (0x3f & (four_data_frames[14]>>2));
    DataFrame->a[2] = (0x3f & four_data_frames[15]);
    DataFrame->a[3] = (0x03 & (four_data_frames[15]>>6));
    DataFrame->a[3] |= (0x3c & (four_data_frames[16]<<2));
    DataFrame->a[4] = (0x0f & (four_data_frames[16]>>4));
    DataFrame->a[4] |= (0x30 & (four_data_frames[17]<<4));
    DataFrame->a[5] = (0x3f & (four_data_frames[17]>>2));
    DataFrame->a[6] = (0xff & four_data_frames[18]);

    DataFrame->b[0] = (0x3f & four_data_frames[19]);
    DataFrame->b[1] = (0x03 & (four_data_frames[19]>>6));
    DataFrame->b[1] |= (0x3c & (four_data_frames[20]<<2));
    DataFrame->b[2] = (0x0f & (four_data_frames[20]>>4));
    DataFrame->b[2] |= (0x30 & (four_data_frames[21]<<4));
    DataFrame->b[3] = (0x3f & (four_data_frames[21]>>2));
    DataFrame->b[4] = (0x3f & four_data_frames[22]);
    DataFrame->b[5] = (0x03 & (four_data_frames[22]>>6));
    DataFrame->b[5] |= (0x3c & (four_data_frames[23]<<2));
    DataFrame->b[6] = (0x0f & (four_data_frames[23]>>4));
    DataFrame->b[6] |= (0xf0 & (four_data_frames[24]<<4));


    DataFrame->crc = (0x0f & (four_data_frames[24]>>4));


    /*
     * Get pitch and class information
     */

    DataFrame->pitch1_index = (0x7f & four_data_frames[25]);
    DataFrame->pitch2_index = (0x01 & (four_data_frames[25] >> 7));
    DataFrame->pitch2_index |= (0x1e & (four_data_frames[26] << 1));
    DataFrame->class1_index = (0x01 & (four_data_frames[26] >> 4));
    DataFrame->class2_index = (0x01 & (four_data_frames[26] >> 5));

    pc_crc[0] = (0x01 & (four_data_frames[26] >> 6));
    pc_crc[1] = (0x01 & (four_data_frames[26] >> 7));

    for (index = 0; index < 7; index++)
    {
      pc_data[index] = (0x01 & (DataFrame->pitch1_index >> index));
    }
    for (index = 7; index < 12; index++)
    {
      pc_data[index] = (0x01 & (DataFrame->pitch2_index >> (index-7)));
    }
    pc_data[12] = (0x01 & DataFrame->class1_index);
    pc_data[13] = (0x01 & DataFrame->class2_index);


    two_data_frames[0] = (0x3f & DataFrame->a[0]);
    two_data_frames[0] |= (0xc0 & (DataFrame->a[1] << 6));
    two_data_frames[1] = (0x0f & (DataFrame->a[1] >> 2));
    two_data_frames[1] |= (0xf0 & (DataFrame->a[2] << 4));
    two_data_frames[2] = (0x03 & (DataFrame->a[2] >> 4));
    two_data_frames[2] |= (0xfc & (DataFrame->a[3] << 2));
    two_data_frames[3] = (0x3f & DataFrame->a[4]);
    two_data_frames[3] |= (0xc0 & (DataFrame->a[5] << 6));
    two_data_frames[4] =  (0x0f & (DataFrame->a[5] >> 2));
    two_data_frames[4] |= (0xf0 & (DataFrame->a[6] << 4));
    two_data_frames[5] = (0x0f & (DataFrame->a[6] >> 4));

    two_data_frames[5] |= (0xf0 & (DataFrame->b[0] << 4));
    two_data_frames[6] = (0x03 & (DataFrame->b[0] >> 4));
    two_data_frames[6] |= (0xfc & (DataFrame->b[1] << 2));
    two_data_frames[7] = (0x3f & DataFrame->b[2]);
    two_data_frames[7] |= (0xc0 & (DataFrame->b[3] << 6));
    two_data_frames[8] = (0x0f & (DataFrame->b[3] >> 2));
    two_data_frames[8] |= (0xf0 & (DataFrame->b[4] << 4));
    two_data_frames[9] = (0x03 & (DataFrame->b[4] >> 4));
    two_data_frames[9] |= (0xfc & (DataFrame->b[5] << 2));
    two_data_frames[10] = (0xff & DataFrame->b[6]);


  
    get_two_pairs=TRUE;
  }




#if(debug)
  fprintf(stdout, "get_two_data_frames ");

  for(index=0; index<11; index++)
    fprintf(stdout, "%02x ", two_data_frames[index]);

  fprintf(stdout, "\ncrc: %01x\n", DataFrame->crc);
#endif




  if((crc_errors(two_data_frames, DataFrame->crc)==TRUE) ||
     (pc_crc_errors(pc_data,pc_crc) == TRUE))
  {
    printf("Warning: A CRC error detected in multiframe: %3d dataframe %2d or %2d\n", (dataframes/24), (dataframes%24), ((dataframes%24)+1));

    zeros_found = 0;

    for(index=0; index<7; index++)
      if(DataFrame->a[index]==0) zeros_found++;

    if(zeros_found>=ZEROS_THRESHOLD)
      frames_non_zero=0;  /*i.e. these are all zero padding frames*/
    else
    {
      zeros_found = 0;

      for(index=0; index<7; index++)
        if(DataFrame->b[index]==0) zeros_found++;

      if(zeros_found>=ZEROS_THRESHOLD)
        frames_non_zero=1;
      else
        frames_non_zero=2;
    }



    frames_non_zero |= 0x4;
  }
  else
  {

    zeros_found = 0;

    for(index=0; index<7; index++)
      if(DataFrame->a[index]==0) zeros_found++;

    if(zeros_found==7)  /*CRC is ok therefore all indicies have to be zero for padding*/
      frames_non_zero=0;
    else
    {
      zeros_found = 0;

      for(index=0; index<7; index++)
        if(DataFrame->b[index]==0) zeros_found++;

      if(zeros_found==7)
        frames_non_zero=1;
      else
        frames_non_zero=2;
    }
  
  }



  return frames_non_zero;

}







void write_two_data_frames(dframe given, int numFrames, unsigned char error_status)
{
  HTK_DataFrame quantised_frame;

  float quant_pitch1, quant_pitch2;
  unsigned char class1, class2;
  static float pfQPHistory[3] = {0.0, 0.0, 0.0};
  static int iReliableFlag = FALSE;

  dequantise_dataframe(&quantised_frame, given.a);
  write_htk_coefs(&quantised_frame);

  inv_quant_pitch_abs(given.pitch1_index,&quant_pitch1);
  get_class(given.class1_index,quant_pitch1,&class1);
  pfQPHistory[2] = pfQPHistory[1];
  pfQPHistory[1] = pfQPHistory[0];
  pfQPHistory[0] = quant_pitch1;

  fwrite(&quant_pitch1,4,1,Quantised_Pitch_Period_File);
  fprintf(Classification_File,"%c",class1);
  fprintf(Error_Status_File,"%c",error_status);

  if(numFrames==TWO_FRAMES)
  {
    dequantise_dataframe(&quantised_frame, given.b);
    write_htk_coefs(&quantised_frame);

    inv_quant_pitch_diff(given.pitch2_index,pfQPHistory,
                         &iReliableFlag,&quant_pitch2);
    get_class(given.class2_index,quant_pitch2,&class2);
    pfQPHistory[2] = pfQPHistory[1];
    pfQPHistory[1] = pfQPHistory[0];
    pfQPHistory[0] = quant_pitch2;

    fwrite(&quant_pitch2,4,1,Quantised_Pitch_Period_File);
    fprintf(Classification_File,"%c",class2);
    fprintf(Error_Status_File,"%c",error_status);

  }


  return;
}












void process_params(int argc, char *argv[])
{
  int errors=0;





  if(argc!=7)
  {
    printf("Decoder for Extended Advanced DSR parameter bit stream\n");
    printf("A program to take a binary BitStream File as input, and produce\n");
    printf("(1) HTK file containing the decoded Mel-Cepstrum parameters\n");
    printf("(2) Pitch Period file containing the decoded pitch values\n");
    printf("(3) Classification file containing the class information, and\n");
    printf("(4) Error status file indicating the status of each frame with\n");
    printf("    respect to channel errors\n\n");

    printf("Usage: %s bitstream_file htk_file pitch_file class_file\n",argv[0]);
    printf("       error_file -VAD/No_VAD\n\n");
    printf("               bitstream_file: input binary bitstream\n");
    printf("               htk_file:       output quantised parameter file\n");
    printf("               pitch_file:     output quantised pitch file\n");
    printf("               class_file:     output class file\n");
    printf("               error_file:     output error status file\n");
    printf("               -VAD:           write integer VAD data to VAD file (.vad)\n");
    printf("               -No_VAD:        Do not use VAD info\n");
    exit(1);
  }



  if((BitStream_File = fopen(argv[1], "rb"))==NULL)
  {
    printf("\nError: cannot open file: %s\n", argv[1]);
    errors++;
  }


  if((HTK_Quantised_Format_File = fopen(argv[2], "wb"))==NULL)
  {
    printf("\nError: cannot create file: %s\n", argv[2]);
    errors++;
  }


  if((Quantised_Pitch_Period_File = fopen(argv[3], "wb"))==NULL)
  {
    printf("\nError: cannot create file: %s\n", argv[3]);
    errors++;
  }


  if((Classification_File = fopen(argv[4], "w"))==NULL)
  {
    printf("\nError: cannot create file: %s\n", argv[4]);
    errors++;
  }


  if((Error_Status_File = fopen(argv[5], "w"))==NULL)
  {
    printf("\nError: cannot create file: %s\n", argv[5]);
    errors++;
  }

  
  if (strcmp("-VAD", argv[6])==0)
  {
    printf("Running with VAD\n");
    if((VAD_File = fopen(strcat(strtok(argv[2],"."),".vad"), "w"))==NULL)
    {
      fprintf(stderr, "Error: cannot open file: %s\n", strcat(strtok(argv[2],"."),".vad"));
      errors++;  
    }
  }	

  else
  {
    if (strcmp("-No_VAD", argv[6])!=0)
      errors++;
    printf("Running without VAD\n");
    VAD_File = NULL;    
  }

  if(errors!=0)
  {
    printf("%d errors in arguments found, exiting...\n", errors);
    exit(1);
  }

  return;
}






void write_htk_coefs(HTK_DataFrame *given)
{

  fwrite(&given->c1, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c2, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c3, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c4, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c5, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c6, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c7, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c8, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c9, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c10, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c11, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c12, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->c0, 4, 1, HTK_Quantised_Format_File);
  fwrite(&given->logE, 4, 1, HTK_Quantised_Format_File);

  if(VAD_File != NULL)
  	{
  	fprintf(VAD_File,"%d ",given->VAD);/* if output VAD file is required then write VAD bit */
	if(ferror(VAD_File)!=0)
  		{
  		  printf("An error occured while writing VAD values.\n");
   		 exit(1);
  		}
	fflush(VAD_File);
	}
  

  if(ferror(HTK_Quantised_Format_File)!=0)
  {
    printf("An error occured while writing HTK coefs.\n");
    exit(1);
  }


  fflush(HTK_Quantised_Format_File);

  return;
}




void write_htk_header(HTK_Header *header)
{

  /*This function writes the header from the struct*/

  fwrite(&header->nSamples, 4, 1, HTK_Quantised_Format_File);
  fwrite(&header->sampPeriod, 4, 1, HTK_Quantised_Format_File);
  fwrite(&header->sampSize, 2, 1, HTK_Quantised_Format_File);
  fwrite(&header->parmKind, 2, 1, HTK_Quantised_Format_File);

  if(ferror(HTK_Quantised_Format_File)!=0)
  {
    printf("An error occured while writing Header.\n");
    exit(1);
  }

  fflush(HTK_Quantised_Format_File);

  return;

}




void print_htk_coefs(HTK_DataFrame given)
{
  printf("c1   %e\n", given.c1);
  printf("c2   %e\n", given.c2);
  printf("c3   %e\n", given.c3);
  printf("c4   %e\n", given.c4);
  printf("c5   %e\n", given.c5);
  printf("c6   %e\n", given.c6);
  printf("c7   %e\n", given.c7);
  printf("c8   %e\n", given.c8);
  printf("c9   %e\n", given.c9);
  printf("c10  %e\n", given.c10);
  printf("c11  %e\n", given.c11);
  printf("c12  %e\n", given.c12);
  printf("c0   %e\n", given.c0);
  printf("logE %e\n\n", given.logE);

  return;
}



void inv_quant_pitch_abs(unsigned char cQPIndex, float *pfQuantPeriod)
{

  if (cQPIndex == 0)
  {
    *pfQuantPeriod = 0.0;
  }
  else
  {
    *pfQuantPeriod = exp(LOG_OF_19+((float)(cQPIndex)-0.5)*DELTA_WIDTH_1);
  }

  return;

}




void inv_quant_pitch_diff(unsigned char cQPIndex, float *pfQPHistory,
                      int *piReliableFlag, float *pfQuantPeriod)
{


  /*
   * Ratio threshold table and multi-level threshold index
   * table for Case 2
   */

  static float pfRatioThld_1[4][6] = {

    {0.8163, 1.2250, 2.0000, 3.0000, 4.0000, 5.0000},
    {0.8163, 1.2250, 1.5000, 2.0000, 2.5000, 3.0000},
    {0.5000, 0.6667, 0.8163, 1.2250, 1.5000, 2.0000},
    {0.2500, 0.3333, 0.5000, 0.6667, 0.8163, 1.2250}

  };


  static int piMultiLevelIndex_1[4] = {

    0,
    0,
    2,
    4

  };
    

  /*
   * Ratio threshold table and multi-level threshold index
   * table for Cases 3 and 4
   */

  static float pfRatioThld_2[4][8] = {

    {0.7781, 1.2852, 1.5000, 2.0000, 2.5000, 3.0000, 4.0000, 5.0000},
    {0.6667, 0.7781, 1.2852, 1.5000, 2.0000, 2.5000, 3.0000, 4.0000},
    {0.3333, 0.5000, 0.6667, 0.7781, 1.2852, 1.5000, 1.7500, 2.0000},
    {0.2000, 0.2500, 0.3333, 0.5000, 0.6667, 0.7781, 1.2852, 1.5000}

  };


  static int piMultiLevelIndex_2[4] = {

    0,
    1,
    3,
    5

  };
    



  int iMultiLevelIndex;
  int iRowIndex;
  int iColIndex;

  float fQuantPeriod;
  float fDeltaWidth;
  float fLowPeriod;
  float fLogLowPeriod;
  float fHighPeriod;
  float fLogHighPeriod;
  float fRefPeriod;




  /*
   * First, handle the unvoiced condition
   */

  if (cQPIndex == 0)
  {
    *pfQuantPeriod = 0.0;
    *piReliableFlag = FALSE;
  }


  /*
   * Next, handle case 1 - Absolute quantization
   */

  else if ((pfQPHistory[0] <= 0.0) &&
           ((pfQPHistory[1] <= 0.0) || (*piReliableFlag == FALSE)) &&
           (pfQPHistory[2] <= 0.0))
  {

    *pfQuantPeriod = exp(LOG_OF_19 + ((float)cQPIndex-0.5)*DELTA_WIDTH_2);
    *piReliableFlag = TRUE;

  }


  /*
   * Next, handle case 2 - Differential quantization with
   * pfQPHistory[0] as reference
   */

  else if (pfQPHistory[0] > 0.0)
  {

    fRefPeriod = pfQPHistory[0];


    /*
     * Establish the appropriate row of ratio thresholds to use
     * based on the reference pitch period
     */

    if (fRefPeriod <= 30.0)
    {
      iRowIndex = 0;
    }
    else if (fRefPeriod <= 60.0)
    {
      iRowIndex = 1;
    }
    else if (fRefPeriod <= 95.0)
    {
      iRowIndex = 2;
    }
    else
    {
      iRowIndex = 3;
    }

    iMultiLevelIndex = piMultiLevelIndex_1[iRowIndex];


    /*
     * Inverse quantize the pitch period
     */

    /*
     * First, check the thresholds below the multi-level threshold
     * to inverse quantize the pitch period
     */

    if (cQPIndex <= iMultiLevelIndex+1)
    {
      iColIndex = cQPIndex-1;
      *pfQuantPeriod = fRefPeriod * pfRatioThld_1[iRowIndex][iColIndex];
      *piReliableFlag = TRUE;
      return;
    }


    /*
     * Next, check the multi-level threshold to inverse quantize
     * the pitch period
     */

    else if ((cQPIndex > iMultiLevelIndex+1) &&
             (cQPIndex < iMultiLevelIndex + 1 + NUM_MULTI_LEVELS_1))
    {

      iColIndex = iMultiLevelIndex;
      fLowPeriod = fRefPeriod * pfRatioThld_1[iRowIndex][iColIndex];
      if (fLowPeriod < MIN_PERIOD)
      {
        fLowPeriod = MIN_PERIOD;
      }

      fHighPeriod = fRefPeriod * pfRatioThld_1[iRowIndex][iColIndex+1];
      if (fHighPeriod > MAX_PERIOD)
      {
        fHighPeriod = MAX_PERIOD;
      }

      fLogLowPeriod = log(fLowPeriod);
      fLogHighPeriod = log(fHighPeriod);
      fDeltaWidth = (fLogHighPeriod - fLogLowPeriod)/NUM_MULTI_LEVELS_1;

      *pfQuantPeriod = exp(fLogLowPeriod+
                          (float)(cQPIndex-1-iMultiLevelIndex)*fDeltaWidth);
      *piReliableFlag = TRUE;

      return;

    }


    /*
     * Finally, check the thresholds above the multi-level
     * threshold to inverse quantize the pitch period
     */

    else
    {

      iColIndex = cQPIndex - NUM_MULTI_LEVELS_1;
      fQuantPeriod = fRefPeriod * pfRatioThld_1[iRowIndex][iColIndex];
      if (fQuantPeriod > MAX_PERIOD)
      {
        fQuantPeriod = MAX_PERIOD;
      }
      *pfQuantPeriod = fQuantPeriod;
      *piReliableFlag = TRUE;
      return;

    }

  }


  /*
   * Next, handle cases 3 and 4 - Differential quantization
   * with pfQPHistory[1] and pfQPHistory[2] as references
   */

  else
  {

    if ((pfQPHistory[1] > 0.0) && (*piReliableFlag == TRUE))
    {
      fRefPeriod = pfQPHistory[1];
    }
    else
    {
      fRefPeriod = pfQPHistory[2];
    }


    /*
     * Establish the appropriate row of ratio thresholds to use
     * based on the reference pitch period
     */

    if (fRefPeriod <= 30.0)
    {
      iRowIndex = 0;
    }
    else if (fRefPeriod <= 60.0)
    {
      iRowIndex = 1;
    }
    else if (fRefPeriod <= 95.0)
    {
      iRowIndex = 2;
    }
    else
    {
      iRowIndex = 3;
    }
    
    iMultiLevelIndex = piMultiLevelIndex_2[iRowIndex];


    /*
     * Inverse quantize the pitch period
     */

    /*
     * First, check the thresholds below the multi-level threshold
     * to inverse quantize the pitch period
     */

    if (cQPIndex <= iMultiLevelIndex+1)
    {
      iColIndex = cQPIndex-1;
      *pfQuantPeriod = fRefPeriod * pfRatioThld_2[iRowIndex][iColIndex];
      *piReliableFlag = FALSE;
      return;
    }


    /*
     * Next, check the multi-level threshold to inverse quantize
     * the pitch period
     */

    else if ((cQPIndex > iMultiLevelIndex+1) &&
             (cQPIndex < iMultiLevelIndex + 1 + NUM_MULTI_LEVELS_2))
    {

      iColIndex = iMultiLevelIndex;
      fLowPeriod = fRefPeriod * pfRatioThld_2[iRowIndex][iColIndex];
      if (fLowPeriod < MIN_PERIOD)
      {
        fLowPeriod = MIN_PERIOD;
      }

      fHighPeriod = fRefPeriod * pfRatioThld_2[iRowIndex][iColIndex+1];
      if (fHighPeriod > MAX_PERIOD)
      {
        fHighPeriod = MAX_PERIOD;
      }

      fLogLowPeriod = log(fLowPeriod);
      fLogHighPeriod = log(fHighPeriod);
      fDeltaWidth = (fLogHighPeriod - fLogLowPeriod)/NUM_MULTI_LEVELS_2;

      *pfQuantPeriod = exp(fLogLowPeriod+
                          (float)(cQPIndex-1-iMultiLevelIndex)*fDeltaWidth);
      *piReliableFlag = FALSE;

      return;

    }


    /*
     * Finally, check the thresholds above the multi-level
     * threshold to inverse quantize the pitch period
     */

    else
    {

      iColIndex = cQPIndex - NUM_MULTI_LEVELS_2;
      fQuantPeriod = fRefPeriod * pfRatioThld_2[iRowIndex][iColIndex];
      if (fQuantPeriod > MAX_PERIOD)
      {
        fQuantPeriod = MAX_PERIOD;
      }
      *pfQuantPeriod = fQuantPeriod;
      *piReliableFlag = FALSE;
      return;

    }

  }

}





void get_class(unsigned char class_index, float pitch_period,
               unsigned char *class)
{


  if (class_index == 0x00)
  {
    if (pitch_period <= 0.0)
    {
      *class = '0';
    }
    else
    {
      *class = '2';
    }
  }
  else if (class_index == 0x01)
  {
    if (pitch_period <= 0.0)
    {
      *class = '1';
    }
    else
    {
      *class = '3';
    }
  }
  else
  {
    printf("ERROR found in class index\n\n");
  }

  return;

}






