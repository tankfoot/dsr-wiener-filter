/*===============================================================================
 *      ETSI ES 202 211   Distributed Speech Recognition
 *      Extended Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*---------------------------------------------------------------------------
 *
 * FILE NAME: Extgolay.h
 * PURPOSE:   Golay and CRC routines prototype for the Extended Distributed Speech
 *            Recognition Compression Extcoder and Extdecoder.
 *
 *---------------------------------------------------------------------------*/


unsigned short golay_encode(unsigned short data);
int golay_errors(unsigned short *data, unsigned short *crc);
unsigned char crc_encode(unsigned char data[]);
int crc_errors(unsigned char data[], unsigned char crc);
void pc_crc_encode(unsigned char pc_data[], unsigned char pc_crc[]);
int pc_crc_errors(unsigned char pc_data[], unsigned char pc_crc[]);
