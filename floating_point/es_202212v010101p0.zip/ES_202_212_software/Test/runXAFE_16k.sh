#! /bin/tcsh

set SYS_IN_USE = `uname`

if ($SYS_IN_USE == "SunOS") then
  set OPTION  = ""
else if ($SYS_IN_USE == "Linux") then
        set OPTION  = "-swap"
     else
        echo unknown system: $SYS_IN_USE ...
        exit
     endif
endif 
echo ""
echo "SYS_IN_USE = $SYS_IN_USE"
echo "OPTION = $OPTION"

echo ""
echo "Running ../ExtAdvFrontEnd/"$SYS_IN_USE"/bin/ExtAdvFrontEnd $OPTION -F RAW -fs 16 16k.pcm 16k.ftr_o 16k.pit_o 16k.vc_o"
../ExtAdvFrontEnd/"$SYS_IN_USE"/bin/ExtAdvFrontEnd $OPTION -F RAW -fs 16 16k.pcm 16k.ftr_o 16k.pit_o 16k.vc_o
cp 16k.vad 16k.vad_o

echo "Running ../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeCoder 16k.ftr_o 16k.pit_o 16k.vc_o 16k.bs 16k.ftr_enc 16k.pit_enc -freq 16 -VAD"
../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeCoder 16k.ftr_o 16k.pit_o 16k.vc_o 16k.bs 16k.ftr_enc 16k.pit_enc -freq 16 -VAD

echo "Running ../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeDecoder 16k.bs 16k.ftr 16k.pit_dec 16k.vc_dec 16k.cherr -VAD"
../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeDecoder 16k.bs 16k.ftr 16k.pit_dec 16k.vc_dec 16k.cherr -VAD

echo "Running ../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeErrHandle 16k.ftr 16k.pit_dec 16k.vc_dec 16k.cherr 16k.ftr_rcnst 16k.pit 16k.vc_dec_eh 16k.loge"
../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeErrHandle 16k.ftr 16k.pit_dec 16k.vc_dec 16k.cherr 16k.ftr_rcnst 16k.pit 16k.vc_dec_eh 16k.loge

echo " Running ../PitchTracking/"$SYS_IN_USE"/bin/PitchTrack -ip 16k.pit -op 16k.pit_rcnst -ie 16k.loge -iv 16k.vc_dec_eh -ov 16k.vc_rcnst"
../PitchTracking/"$SYS_IN_USE"/bin/PitchTrack -ip 16k.pit -op 16k.pit_rcnst -ie 16k.loge -iv 16k.vc_dec_eh -ov 16k.vc_rcnst

echo "Running ../XafeReconstruction/"$SYS_IN_USE"/bin/XafeReconstruct -cep 16k.ftr_rcnst -pit 16k.pit_rcnst -vc 16k.vc_rcnst -out 16k.synt -s16"
../XafeReconstruction/"$SYS_IN_USE"/bin/XafeReconstruct -cep 16k.ftr_rcnst -pit 16k.pit_rcnst -vc 16k.vc_rcnst -out 16k.synt -s16

