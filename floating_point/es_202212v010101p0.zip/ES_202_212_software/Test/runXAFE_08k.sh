#! /bin/tcsh

set SYS_IN_USE = `uname`

if ($SYS_IN_USE == "SunOS") then
  set OPTION  = ""
else if ($SYS_IN_USE == "Linux") then
        set OPTION  = "-swap"
     else
        echo unknown system: $SYS_IN_USE ...
        exit
     endif
endif 
echo ""
echo "SYS_IN_USE = $SYS_IN_USE"
echo "OPTION = $OPTION"

echo ""
echo "Running ../ExtAdvFrontEnd/"$SYS_IN_USE"/bin/ExtAdvFrontEnd $OPTION -F RAW -fs 8 08k.pcm 08k.ftr_o 08k.pit_o 08k.vc_o"
../ExtAdvFrontEnd/"$SYS_IN_USE"/bin/ExtAdvFrontEnd $OPTION -F RAW -fs 8 08k.pcm 08k.ftr_o 08k.pit_o 08k.vc_o
cp 08k.vad 08k.vad_o

echo "Running ../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeCoder 08k.ftr_o 08k.pit_o 08k.vc_o 08k.bs 08k.ftr_enc 08k.pit_enc -freq 8 -VAD"
../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeCoder 08k.ftr_o 08k.pit_o 08k.vc_o 08k.bs 08k.ftr_enc 08k.pit_enc -freq 8 -VAD

echo "Running ../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeDecoder 08k.bs 08k.ftr 08k.pit_dec 08k.vc_dec 08k.cherr -VAD"
../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeDecoder 08k.bs 08k.ftr 08k.pit_dec 08k.vc_dec 08k.cherr -VAD

echo "Running ../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeErrHandle 08k.ftr 08k.pit_dec 08k.vc_dec 08k.cherr 08k.ftr_rcnst 08k.pit 08k.vc_dec_eh 08k.loge"
../XafeCoderDecoder/"$SYS_IN_USE"/bin/XafeErrHandle 08k.ftr 08k.pit_dec 08k.vc_dec 08k.cherr 08k.ftr_rcnst 08k.pit 08k.vc_dec_eh 08k.loge

echo " Running ../PitchTracking/"$SYS_IN_USE"/bin/PitchTrack -ip 08k.pit -op 08k.pit_rcnst -ie 08k.loge -iv 08k.vc_dec_eh -ov 08k.vc_rcnst"
../PitchTracking/"$SYS_IN_USE"/bin/PitchTrack -ip 08k.pit -op 08k.pit_rcnst -ie 08k.loge -iv 08k.vc_dec_eh -ov 08k.vc_rcnst

echo "Running ../XafeReconstruction/"$SYS_IN_USE"/bin/XafeReconstruct -cep 08k.ftr_rcnst -pit 08k.pit_rcnst -vc 08k.vc_rcnst -out 08k.synt -s8"
../XafeReconstruction/"$SYS_IN_USE"/bin/XafeReconstruct -cep 08k.ftr_rcnst -pit 08k.pit_rcnst -vc 08k.vc_rcnst -out 08k.synt -s8

