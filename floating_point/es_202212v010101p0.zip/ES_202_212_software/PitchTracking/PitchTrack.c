/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: PitchTrack.c
 * PURPOSE:   This file contains main program for server side tracking and
 *            smoothing of pitch and voicing class contours.
 *            The program reads:
 *            1) Pitch file ibtained after decoding & channel errors recovery; 
 *            2) Voicing class file ibtained after decoding & channel errors
 *             recovery;
 *            3) Log-energy file ibtained after decoding & channel errors
 *             recovery;
 *            The program outputs:
 *            1) Smoothed pitch contour file;
 *            2) Smoothed voicing class contour file;
 *
 *-------------------------------------------------------------------------------*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* To #define FLT_MAX under Linux */ 
#include <values.h>
#include <float.h>



/* ================================================================================
                   

   ================================================================================== */

/// Look ahead required for first stage of for pitch tracking (in number of frames)
#define DELAY1   8 
/// Backwards frames required for first stage of for pitch tracking
#define HISTORY1 10 

/// Look ahead required for second stage of for pitch tracking (in number of frames)
#define DELAY2   1
/// Backwards frames required for second stage of for pitch tracking
#define HISTORY2 1

/// Look ahead required for third stage of for pitch tracking (in number of frames)
#define DELAY3   2
/// Backwards frames required for third stage of for pitch tracking
#define HISTORY3 (DELAY3)

/// First stage buffer length 
#define INPUT_BUFFER_LEN   ((HISTORY1)+(1)+(DELAY1))  //  = 5 + 1 + 4 = 10
/// Second stage buffer length 
#define INTERIM_BUFFER_LEN ((HISTORY2)+(1)+(DELAY2))  //  = 1 + 1 + 1 = 3
/// Third stage buffer length
#define FILTER_BUFFER_LEN  ((HISTORY3)+(1)+(DELAY3))  //  = 2 + 1 + 2 = 5

/*
* Symmetric FIR filter for third stage pitch tracking. 
* Filter coefficients must sum up to 1.0
*/
static float afFilterCoefs[FILTER_BUFFER_LEN] = {
 1.0f/9.0f,
 2.0f/9.0f,
 3.0f/9.0f,
 2.0f/9.0f,
 1.0f/9.0f
};

/// Maximum natural pitch change between two succesive frames (28%)
#define JUMP    1.28f 
/*
* Maximum natural pitch change between frames who are one frame
* apart. This should be a bit smaller than JUMP*JUMP
*/
#define LONG_JUMP  1.4f  
/*
* Number of frames to the left and right of the current frame that mini-tracks
* are searched for in a voiced segment in the INPUT_BUFFER.
* Not used any more -- the search is done in all the input buffer
*/

/*
* This value is assigned to all the fields of a VOICED_SEG
* structure, when the associated voiced frame it represents is ignored.
* The selection is done in the IdentifyRelevantFrames function.
* This value must be negative.
*/
#define REMOVED (-1)

/* 
 Define boolean as an integer. 
 It can have one of two integer values, TRUE or FALSE.
*/
typedef int BOOL;
#ifndef TRUE
    /// A boolean true value is defined as integer 1.
	#define TRUE	(BOOL)1
#endif
#ifndef FALSE
    /// A false value is defined as integer 0
	#define FALSE	(BOOL)0 
#endif

/*
 This structure holds the informatoin of a single
 frame in a voiced segment. An array of such
 structures is used in the first stage of 
 pitch tracking to hold a single voiced segment
*/
typedef struct VOICED_SEG_T {
    /// Input pitch of the frame
    float fPitch;
    /// Input log energy of the frame
    float fEnergy;
    /// Relative location of the frame in the voiced segment
    int   iLoc;
} VOICED_SEG;

/*
 This structure holds internal buffers used
 for pitch tracking.
*/
typedef struct PITCH_TRACKING_T {
    /// Input pitch buffer
    float afInputPitch[INPUT_BUFFER_LEN];
    /// Input log energy buffer
    float afInputLogEnergy[INPUT_BUFFER_LEN];    
    /// Buffer to hold a signle voiced segment
    VOICED_SEG astVoicedSeg[INPUT_BUFFER_LEN];
    /// Interim pitch buffer (stage two)
    float afInterimPitch[INTERIM_BUFFER_LEN];
    /// Buffer to filter (stage three)
    float afPitchToFilter[FILTER_BUFFER_LEN];    
} PITCH_TRACKING;




/// Value of pitch period indicating unvoiced frame
#define UNVOICED    0.0f
/// Minimum log energy as defined by ETSI MFCC front-end
#define MIN_LOG_E   -50.0f 





/*----------------------------------------------------------------------------
 * FUNCTION NAME: ComparePitchValues
 *
 * PURPOSE:    This function is passed to ANSI-C "qsort" function as the comparison
 *             function. The pitch period values in these structure is compared
 *
 * INPUT:
 *   var1         A first structure of type VOICED_SEC passed as a void
 *                pointer.
 *   var2         A second structure of type VOICED_SEC passed as a void
 *                pointer.
 *
 * OUTPUT
 *   none
 *
 * RETURN VALUE
 *  0 If the value of the fPitch field in both structures is equal
 *  1 if the pitch value in "var1" is bigger than the pitch value in "var2"
 *  -1 Otherwise
 *  
 *---------------------------------------------------------------------------*/
static int ComparePitchValues(const void *var1, const void *var2)
{
    if (((VOICED_SEG *)var1)->fPitch > ((VOICED_SEG *)var2)->fPitch) {
        return(1);
    }
    
    if (((VOICED_SEG *)var1)->fPitch < ((VOICED_SEG *)var2)->fPitch) {
        return(-1);
    }
    
    return(0);
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME: IsSimilar
 *
 * PURPOSE:    checks if two floating point numbers X and
 *             Y are "similar". Similarity is defined as: r*Y >= X >= Y/r
 *             or (r*X >= Y >= X/r), where "r" is a positive floating 
 *             point number
 *
 * INPUT:
 *   fX        First floating point number
 *   fY        Second floating point number
 *   fMult     The multiplication factor (=r) used to check the similarity
 *             between fX and fY. 
 *
 * OUTPUT
 *   none
 *
 * RETURN VALUE
 *  TRUE or FALSE
 *  
 *---------------------------------------------------------------------------*/
static BOOL IsSimilar(const float fX,
                      const float fY,
                      const float fMult)
{
 if ( (fY * fMult >= fX) &&
      (fX * fMult >= fY)   )
  return(TRUE); 
 else
  return(FALSE); 
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME: UpdateInterimPitchValues
 *
 * PURPOSE:   Updates the values of the pitch period in the interim buffer 
 *            at the second stage. The second value from the end in the buffer
 *            is updated
 * INPUT:
 *
 *   pfInterimPitch      A pointer to the interim pitch buffer
 *                       of size INTERIM_BUFFER_LEN. This buffer, at the last
 *                       location (INTERIM_BUFFER_LEN-1) should hold the newest
 *                       pitch value which is the output of the first stage of
 *                       pitch tracking.
 *
 * OUTPUT
 *   none
 *
 * RETURN VALUE
 *   The updated pitch value of one frame behind, i.e. in
 *   location INTERIM_BUFFER_LEN-2 (a delay of DELAY2 frames)
 *  
 *---------------------------------------------------------------------------*/
static float UpdateInterimPitchValues(float *pfInterimPitch)
{
 float fP2 = pfInterimPitch[INTERIM_BUFFER_LEN-1]; // Recent (newest) value
 float fP1 = pfInterimPitch[INTERIM_BUFFER_LEN-2]; // One frame before
 float fP0 = pfInterimPitch[INTERIM_BUFFER_LEN-3]; // Two frames before
 float fAvrg;

 // If all three are voiced,
 // first and third are similar,
 // but second is different,
 // caluclate new value for second
 if (UNVOICED != fP2 &&
     UNVOICED != fP1 &&
     UNVOICED != fP0 &&
     TRUE == IsSimilar(fP2,fP0,LONG_JUMP)) {
  fAvrg = 0.5f * (fP2+fP0);            
  if (FALSE==IsSimilar(fP1,fAvrg,JUMP)) {
    fP1 = fAvrg;
  }
 }

 // If only the middle is unvoiced,
 // but the first and third are voiced and
 // very close, then reverse the u/v decision
 // for the second frame
 else if (UNVOICED != fP2 &&
          UNVOICED == fP1 &&
          UNVOICED != fP0 &&
          TRUE == IsSimilar(fP2,fP0,JUMP)) {
  fP1 = 0.5f * (fP2+fP0);
 }
 
 // Switch voiced to unvoiced at the begginig
 // or end of voiced segment, if two initial/last
 // voiced frames don't have a stable pitch
 else if (UNVOICED != fP2 &&
          UNVOICED != fP1 &&
          UNVOICED == fP0 && 
          FALSE==IsSimilar(fP1,fP2,JUMP)) {
  fP1 = UNVOICED;
 }
 else if (UNVOICED == fP2 &&
          UNVOICED != fP1 &&
          UNVOICED != fP0 && 
          FALSE==IsSimilar(fP1,fP0,JUMP)) {
  fP1 = UNVOICED;
 }

 // Alex: added
 else if (UNVOICED == fP2 &&
          UNVOICED != fP1 &&
          UNVOICED == fP0) {
  fP1 = UNVOICED;
 }


 // Update buffer and return with new updated value
 pfInterimPitch[INTERIM_BUFFER_LEN-2] = fP1;

 return(fP1);
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  IntegerScaling
 *
 * PURPOSE:    Finds by how much an input pitch value should be multipled
 *             (or divided) in order to come close to the "reference pitch"
 *             value
 *
 * INPUT:
 *   fReferencePitch         The reference pitch value
 *   fInputPitch             The input pitch value
 *
 * OUTPUT
 *   none
 *
 * RETURN VALUE
 *   The scaled pitch value
 *  
 *---------------------------------------------------------------------------*/
static float IntegerScaling(const float fReferencePitch, const float fInputPitch)
{
 int iRatio;
 float a, b;
    
 if (fReferencePitch > fInputPitch) { // this means we have to find an integer MULTIPLIER (=1,2,3,...)

        // This gives the higest multiplier such that the multiplication is still below the reference pitch
        // (could be 1 or any integer bigger)
        iRatio = (int)(fReferencePitch / fInputPitch);
        
        // The distance measure can be defined as the difference divided by
        // the average pitch value (the reference and the tested value)
        a =   (fReferencePitch - iRatio * fInputPitch)
            / (fReferencePitch + iRatio * fInputPitch);
        
        // Also the distance for the next integer multiplier is checked
        b =   ((iRatio + 1) * fInputPitch - fReferencePitch)
            / ((iRatio + 1) * fInputPitch + fReferencePitch);
        
        // The normalized distances are compared and the smallest one wins.
        // iRation now holds the best ratio, and "a" now hold the smallest
        // distance
        if (a > b) {
            iRatio = iRatio + 1;
            a = b;
        }
        
        /*
         Recheck the common case where a factor of 2 is selected (meaning the
         input pitch is half the correct pitch - at least we think so...)
         For this case, leave the original value in some cases even
         if the error is bigger
        */
        if ( (iRatio == 2 ) && 
            ((1.4 * a) > (fReferencePitch - fInputPitch)/(fReferencePitch + fInputPitch))) {
            iRatio = 1;
        }

        // Retrun the corrected pitch value 
        return (float)iRatio * fInputPitch;

    }
    else if (fReferencePitch < fInputPitch) {

        iRatio = (int)(fInputPitch / fReferencePitch);
        
          a = - (iRatio * fReferencePitch - fInputPitch)
              / (fReferencePitch + iRatio * fInputPitch);
        
        b =   ((iRatio + 1) * fReferencePitch - fInputPitch)
            / ((iRatio + 1) * fReferencePitch + fInputPitch);
        
        if (a > b) {
            iRatio = iRatio + 1;
            a = b;
        }
        
        if ((iRatio == 2 ) && ((1.4 * a) > (fInputPitch - fReferencePitch)/(fReferencePitch + fInputPitch))) {
            iRatio = 1;
        }
        
        return fInputPitch/(float)(iRatio);
    }
    // fReferencePitch == fInputPitch
    else {
        return fInputPitch;
    }
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  RunningAverageFilter
 *
 * PURPOSE:   Smoothing by applying FIR filter. 
 *
 * INPUT:
 *   pfPitchToFilter   Pointer to the buffer of pitch values
 *                     to be filterd. This buffer size is FILTER_BUFFER_LEN.
 *                     The last  value in the buffer holds the most recent
 *                     pitch value (output from second stage pitch tracking)
 *
 * OUTPUT
 *   none
 *
 * RETURN VALUE
 *  The filted output pitch delaed by DELAY3 compared to the
 *  the most recent pitch (last pitch) in the buffer 
 *  
 *---------------------------------------------------------------------------*/
static float RunningAverageFilter(const float *pfPitchToFilter)
{
 float fReferencePitch = pfPitchToFilter[HISTORY3];
 float fOutputPitch = 0.0f;
 int i;

 // unvoiced frames are not changed
 if (UNVOICED==fReferencePitch) {
    return(UNVOICED);
 }

 for(i=0;i<FILTER_BUFFER_LEN;i++) {

    float fTemp = pfPitchToFilter[i];

    if(UNVOICED==fTemp) {
      fTemp = fReferencePitch;
    }
    else {
      // Modify pitch value such that it becomes closer to the input pitch
      fTemp = IntegerScaling(fReferencePitch,fTemp);
    }

    // Filter (weight by filter coefficients and add)
    fOutputPitch += afFilterCoefs[i]*fTemp;
 }
 
  
 return(fOutputPitch);
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  FindMostEnergeticTrack
 *
 * PURPOSE:   Given a set of voiced frames with a pitch value and
 *            energy for each frame, this function:
 *            1) Partitions the set into "pitch tracks", i.e. groups
 *            groups, such that in each group the neighbouring pitch
 *            values are similar.
 *            2) Selects the group which has the largest total energy.
 *
 *            Frames which are "deleted" are skipped, and cannot
 *            be part of a track. 
 *
 * INPUT:
 *   pstVoicedSeg     Pointer to buffer containing the frame information
 *   iLength          Number of frames in the buffer 
 *
 * OUTPUT
 *   piBegin    The index of the first frame in the track
 *   piEnd      The index of the last frame in the track
 *
 * RETURN VALUE
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void FindMostEnergeticTrack(const VOICED_SEG *pstVoicedSeg,
                                   const int iLength,
                                   int *piBegin,
                                   int *piEnd)
{
 int n =0;
 int iCurrentBegin;
 float fCurrentEnergy;
 float fMaxEnergy = -FLT_MAX;
 


 // Loop on all frames in the voiced buffer
 while (n < iLength) {

   // Skip removed frames
   if ( (float)REMOVED== pstVoicedSeg[n].fPitch) {
    n++;
    continue;
   } 

   // Initialize a new group
   fCurrentEnergy = pstVoicedSeg[n].fEnergy;
   iCurrentBegin  = n;
   n++;
      
   // Advance forward, pitch continuity and sum energy
   while ((n < iLength) && 
          ((float)REMOVED != pstVoicedSeg[n].fPitch) &&
          (TRUE==IsSimilar(pstVoicedSeg[n-1].fPitch,pstVoicedSeg[n].fPitch,JUMP)) ) {
     fCurrentEnergy += pstVoicedSeg[n].fEnergy; 
     n++;
   }

   // When track ends, check if most energetic so far     
   if (fCurrentEnergy>fMaxEnergy) {
     *piBegin = iCurrentBegin;
     *piEnd   = n-1;
     fMaxEnergy = fCurrentEnergy;
   }

 }  // end of while(n<iLength) (

} // of function


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  CalcReferencePitch
 *
 * PURPOSE:  Computes a "referene" (or "predicted") pitch value for current
 *          frame
 *
 * INPUT:
 *   pstVoicedSeg     A pointer to a buffer containing the information of the
 *                    frames in the voiced segment
 *   iRangeLength     The length of the above buffer
 *   iCurrIndex       Location of the current processed frame
 *
 * OUTPUT
 *   none
 *
 * RETURN VALUE
 *   The reference pitch value
 *  
 *---------------------------------------------------------------------------*/
static float CalcReferencePitch(VOICED_SEG *pstVoicedSeg, 
                              const int iRangeLength, 
                              const int iCurrIndex)
{
 int iBegin,iEnd;
 float fReferencePitch;

 // Find location of most energetic pitch track
 FindMostEnergeticTrack(pstVoicedSeg,iRangeLength,&iBegin,&iEnd);

 // If current frame is in this track, return current pitch
 if (iCurrIndex>=iBegin && iCurrIndex<=iEnd)
    fReferencePitch=pstVoicedSeg[iCurrIndex].fPitch;

 // Else return the pitch value in the track which belongs
 // to the colsest frame to the current frame
 else if (iCurrIndex > iEnd)
    fReferencePitch=pstVoicedSeg[iEnd].fPitch;
 else
    fReferencePitch=pstVoicedSeg[iBegin].fPitch;



 return fReferencePitch;
}



static void SwapFrameStructers(VOICED_SEG *pstVoicedSeg, 
                            const int iLoc1, 
                            const int iLoc2)
{
 VOICED_SEG stTemp;

 stTemp.fPitch  = pstVoicedSeg[iLoc1].fPitch;
 stTemp.fEnergy = pstVoicedSeg[iLoc1].fEnergy;
 stTemp.iLoc    = pstVoicedSeg[iLoc1].iLoc;
   
 pstVoicedSeg[iLoc1].fPitch  = pstVoicedSeg[iLoc2].fPitch;
 pstVoicedSeg[iLoc1].fEnergy = pstVoicedSeg[iLoc2].fEnergy;
 pstVoicedSeg[iLoc1].iLoc    = pstVoicedSeg[iLoc2].iLoc;

 pstVoicedSeg[iLoc2].fPitch  = stTemp.fPitch;
 pstVoicedSeg[iLoc2].fEnergy = stTemp.fEnergy;
 pstVoicedSeg[iLoc2].iLoc    = stTemp.iLoc;
}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  IdentifyRelevantFrames
 *
 * PURPOSE:        Deletes frames from a voiced segment, such that
 *                 the frames left are the most energetic, and with similar
 *                 pitch values
 *          
 *
 * INPUT/OUTPUT:
 *   pstVoicedSeg        A pointer to a buffer containing the information of
 *                       the frames in the voiced segment. On output, deleted
 *                       frames will be marked  with an UNVOICED pitch
 * INPUT:
 *   iLength             The length of the above buffer
 * OUTPUT
 *   none
 *
 * RETURN VALUE
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void IdentifyRelevantFrames(VOICED_SEG *pstVoicedSeg, 
                                   const int iLength)
{
 int iSelectedSegStart;
 int iSelectedSegEnd;
 int iNdex;


       
 // Sort pitch values of the current voiced section in ascending order. The results
 // is returned in the same array. 
 qsort(pstVoicedSeg, (iLength), sizeof(VOICED_SEG), ComparePitchValues);




 // Identify most energetic pitch track in the sorted frames domain
 FindMostEnergeticTrack(pstVoicedSeg,iLength,&iSelectedSegStart,&iSelectedSegEnd);

    
 // Mark all pitch values which are not in the most energetic
 // segment as invalid
 for(iNdex = 0; iNdex < iSelectedSegStart; iNdex++) {
        pstVoicedSeg[iNdex].fPitch  = (float)REMOVED;
        pstVoicedSeg[iNdex].fEnergy = (float)REMOVED;
        pstVoicedSeg[iNdex].iLoc    =   (int)REMOVED;
 }
    
 for(iNdex = iSelectedSegEnd + 1; iNdex < iLength; iNdex++) {
        pstVoicedSeg[iNdex].fPitch  = (float)REMOVED;
        pstVoicedSeg[iNdex].fEnergy = (float)REMOVED;
        pstVoicedSeg[iNdex].iLoc    =   (int)REMOVED;
 }

 // loop over all pitch values within the most energetic segment
 // and place their associated structure back to the original
 // place. This is an "inverse" of the sorting operation, just
 // done on the subset of the pitch values which belong to the
 // most energetic segment.
 for(iNdex = iSelectedSegStart; iNdex <= iSelectedSegEnd; iNdex++) {

        // pstVoicedSeg[iNdex].iLoc saves the original location
        // of this pitch before sorting. So this "if" makes sure we
        // only process those pitch who have "moved" in the sorting
        if (iNdex != pstVoicedSeg[iNdex].iLoc) {

            int iTempIndex;
            
            iTempIndex = pstVoicedSeg[iNdex].iLoc;
            
            if ((int)REMOVED != pstVoicedSeg[iTempIndex].iLoc) {
                SwapFrameStructers(pstVoicedSeg,iNdex, iTempIndex);                
                iNdex--;
            }
            else {
                pstVoicedSeg[iTempIndex].fPitch        = pstVoicedSeg[iNdex].fPitch;
                pstVoicedSeg[iTempIndex].fEnergy       = pstVoicedSeg[iNdex].fEnergy;
                pstVoicedSeg[iTempIndex].iLoc = iTempIndex;
    
                pstVoicedSeg[iNdex].fPitch  = (float)REMOVED;
                pstVoicedSeg[iNdex].fEnergy = (float)REMOVED;
                pstVoicedSeg[iNdex].iLoc     =  (int)REMOVED;
            } // of if (INVALID_INDEX != ...

        } // of if (iNdex != ...

 } // of for(iNdex = i




} // of function



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  FindVoicedRegion
 *
 * PURPOSE:        Locates the voiced segment in which the current
 *                 frame is located in (assuming the current frame is
 *                 voiced).
 *          
 * INPUT:
 *   pfInputPitch      Pointer to the input pitch buffer of size
 *                     INPUT_BUFFER_LEN
 *   pfInputLogEnergy  Pointer to the input log energy of size
 *                     INPUT_BUFFER_LEN
 * OUTPUT
 *   pstVoiceSeg       Buffer containing the information of the voiced segment
 *   piLen             The number of frames in the pstVoicedSeg buffer
 *   piStart           The starting location of the voiced segment within the
 *                     input buffer (from zero to HISTORY1)
 *   piEnd             The end location of the voiced segment within the input
 *                     buffer (from HISTORY1 to INPUT_BUFFER_LEN-1)
 *
 * RETURN VALUE
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void FindVoicedRegion(const float *pfInputPitch,
                             const float *pfInputLogEnergy,
                             VOICED_SEG *pstVoicedSeg,                             
                             int *piLen,
                             int *piStart,
                             int *piEnd)
{
 int i;
 *piStart = -1;  // Invalid
 *piEnd   = -1;  // Invalid
 *piLen = 0;
 
 // If current frame is unvoiced, return lengh zero
 if (UNVOICED==pfInputPitch[HISTORY1]) {
    return;
 } 

 // Default - a voiced section of length 1
 *piLen = 1;
 *piStart = *piEnd = HISTORY1;

 // Move backwards and count voiced frames
 i = HISTORY1-1;
 while(i>=0 &&
       UNVOICED!=pfInputPitch[i]) {
  *piStart = i;    
  (*piLen)++;
  i--;
 }

 // Move forwards and count voiced frames
 i = HISTORY1+1;
 while(i<INPUT_BUFFER_LEN &&
       UNVOICED!=pfInputPitch[i]) {
  *piEnd = i;    
  (*piLen)++;
  i++;
 }

 // Copy voiced segment into "PitchIndex" array
 for(i=0;i<(*piLen);i++) {
    pstVoicedSeg[i].fPitch  = pfInputPitch[i+(*piStart)];
    pstVoicedSeg[i].fEnergy = pfInputLogEnergy[i+(*piStart)];        
    pstVoicedSeg[i].iLoc = i;
 }

}





/*----------------------------------------------------------------------------
 * FUNCTION NAME:      PitchTracking
 *
 * PURPOSE:        Produces one additional output pitch value after tracking
 *          
 * INPUT:
 *   pstPitchTracking    A pointer to the PITCH_TRACKING object
 *   fInputPitch         Input pitch period in 8Khz samples.
 *   fInputLogEnergy     Input log energy as defined by the ETSI DSR front-end
 * OUTPUT
 *   pfOutputPitch       Output pitch value which is delayed by
 *                       (DELAY1+DELAY2+DELAY3) number of frames relatively to
 *                        the input pitch
 * RETURN VALUE
 *   none
 *  
 *---------------------------------------------------------------------------*/
void PitchTracking(PITCH_TRACKING *pstPitchTracking,
                  float  fPitch,
                  float  fLogEnergy,
                  float *pfOutputPitch)
{

 int iLen,iStart,iEnd;
 float *pfInputPitch      = pstPitchTracking->afInputPitch;
 float *pfInputLogEnergy  = pstPitchTracking->afInputLogEnergy;
 float *pfInterimPitch    = pstPitchTracking->afInterimPitch;
 float *pfPitchToFilter   = pstPitchTracking->afPitchToFilter;

 VOICED_SEG *pstVoicedSeg = pstPitchTracking->astVoicedSeg;



/*************************************************************************
 *
 * Phase 1 - Calculate a new interim pitch value (delay = DELAY1 frames)
 *
 *************************************************************************/

 // Push new input pitch and log energy to the top of the buffer, and delete old values
 // from bottom of the buffer
 memmove(pfInputPitch,pfInputPitch+1,(INPUT_BUFFER_LEN-1)*sizeof(float));
 pfInputPitch[INPUT_BUFFER_LEN-1]=fPitch;
 memmove(pfInputLogEnergy,pfInputLogEnergy+1,(INPUT_BUFFER_LEN-1)*sizeof(float));
 pfInputLogEnergy[INPUT_BUFFER_LEN-1]=fLogEnergy;


 
 // Find voiced region (if any) around the current frame
 FindVoicedRegion(pfInputPitch,
                  pfInputLogEnergy,
                  pstVoicedSeg,
                  &iLen,
                  &iStart, 
                  &iEnd); 

 // If current input frame is unvoiced or if there is only one
 // voiced frame, set the interim value to unvoiced
 if (0==iLen || 1==iLen) {
    fPitch = UNVOICED;
 }
 // For a voiced segments of exactly two frames
 else if (2==iLen) {

   // If the pitch vales are similar, stay with original value
   if (TRUE==IsSimilar(pfInputPitch[iStart],pfInputPitch[iEnd],JUMP)) {
    fPitch = pfInputPitch[HISTORY1];
   }
   // Otherwise, switch voiced frame to unvoiced
   else {
    fPitch = UNVOICED;
   }
 
 }
 // For a voiced segments of three frames or more
 else {

  float fReferencePitch;

  // Delete low-energy, non continuous pitch track frames
  IdentifyRelevantFrames(pstVoicedSeg,iLen);

  // Calculate a pitch value representing the most energetic mini pitch track
  fReferencePitch = CalcReferencePitch(pstVoicedSeg,
                                       iLen,
                                       HISTORY1-iStart);
  // Modify input pitch value by integer multiplication/division
  fPitch = IntegerScaling(fReferencePitch,pfInputPitch[HISTORY1]);
 
 }

/***************************************************************
 *
 * Phase 2 - Update Intrim Pitch Values (delay = DELAY2 frames)
 *
 ***************************************************************/

 // Push new interim pitch value to end of interim pitch buffer
 memmove(pfInterimPitch,pfInterimPitch+1,(INTERIM_BUFFER_LEN-1)*sizeof(float));
 pfInterimPitch[INTERIM_BUFFER_LEN-1]=fPitch;


 // Filter
 fPitch = UpdateInterimPitchValues(pfInterimPitch);

/*****************************************************
 *
 * Phase 3 - Running average (dealy = DELAY3 frames)
 *
 *****************************************************/

 // Push new unfiltered pitch to end of unfiltered pitch buffer
 memmove(pfPitchToFilter,pfPitchToFilter+1,(FILTER_BUFFER_LEN-1)*sizeof(float));
 pfPitchToFilter[FILTER_BUFFER_LEN-1]=fPitch;



 fPitch = RunningAverageFilter(pfPitchToFilter);


 *pfOutputPitch = fPitch;


}




/* =====================================================================================

                                     MAIN
                 
   ====================================================================================== */





// Structure to hold input (console) arguments 
typedef struct  {

  FILE  *fpInputPitch;     
  FILE  *fpInputLogEnergy;     
  FILE  *fpOutputPitch;     
  FILE  *fpInputVoicing;
  FILE  *fpOutputVoicing;

} MAIN_PARAMS;

static int QuietMode = 0;


static void ReadInputArguments(int argc, char *argv[], MAIN_PARAMS *pstMainParams);
static void CloseFiles(MAIN_PARAMS *pstMainParams);
static void PrintUsage(void);
static void PrintHeader(void);
static int  FileLenght(FILE *fp);

/*
--------------------------------------------------------------------------
 Main program
-------------------------------------------------------------------------- 
*/
void main( int iArgc , char *pcArgv[] )
{
 MAIN_PARAMS      stMainParams;      
 PITCH_TRACKING     *pPitchTracking;
 int iFrameCount;
 int iFramesDelay;
 int iFileLength1,iFileLength2;
 float            fInputPitch;
 float            fInputLogEnergy;
 float            fOutputPitch;
 float  *pfInpPitchBuf = NULL;
 unsigned char   *pcInpVoicingBuf=NULL;
 unsigned char    cVoicingClass;
 unsigned char    cPreviousClass = '0';
 int i, iPush, iPop;
 
 
 // Process command line arguments
 ReadInputArguments(iArgc,pcArgv,&stMainParams);

 // Check that input pitch file and input energy file are of the same length
 if(0>=(iFileLength1 = FileLenght(stMainParams.fpInputPitch))) {
   printf(" Error: failed reading input pitch file\n");
   exit(1);
 }
 if(0>=(iFileLength2 = FileLenght(stMainParams.fpInputLogEnergy))) {
   printf(" Error: failed reading input log energy file\n");
   exit(1);
 }
 if(iFileLength1!=iFileLength2) {
   printf(" Warning: input pitch and log-energy files must be the same length\n");
// #######   exit(1);
 }
 
 
 if (stMainParams.fpInputVoicing != NULL) {
     // Check that input pitch file and input voicing file are of the same lenght
   if(0>=(iFileLength2 = FileLenght(stMainParams.fpInputVoicing))) {
    printf(" Warning: failed reading input voicing class file\n");
    exit(1);
   }
   if(iFileLength1!=iFileLength2*(int)sizeof(float)) {
    printf(" Warning: input pitch and voicing class files must be the same length\n");
// #######    exit(1);
   }
 }

 /* ------------------------------------------ */
 /*        Initialize pitch tracking           */
 /* ------------------------------------------ */

 // Allocate memory for pitch tracking data structure
 pPitchTracking=(PITCH_TRACKING *)malloc(sizeof(PITCH_TRACKING));

 if ((PITCH_TRACKING *)NULL==pPitchTracking) {
    printf(" Error: failed initializing pitch tracking\n");
    exit(1);
 }

 // Reset input pitch and log energy buffers
 for (i=0;i<INPUT_BUFFER_LEN;i++) {
    pPitchTracking->afInputPitch[i]     = UNVOICED;    
    pPitchTracking->afInputLogEnergy[i] = MIN_LOG_E;
 }

 for (i=0;i<INTERIM_BUFFER_LEN;i++) {
    pPitchTracking->afInterimPitch[i]   = UNVOICED;        
 }

 for (i=0;i<FILTER_BUFFER_LEN;i++) {
    pPitchTracking->afPitchToFilter[i]   = UNVOICED;        
 }

 

      
 // Get number the number of frames the output
 // pitch will be delayed compared to the input pitch
 iFramesDelay = DELAY1 + DELAY2 + DELAY3;


 if (stMainParams.fpInputVoicing != NULL) {
     // Allocate buffers needed for processing voicing information
     pfInpPitchBuf = (float*)malloc((iFramesDelay+1)*sizeof(float));
     pcInpVoicingBuf = (char*)malloc((iFramesDelay+1)*sizeof(char));
     if (NULL == pfInpPitchBuf || NULL == pcInpVoicingBuf) {
         printf("Error: Cannot allocate memory\n");
         exit(1);
     }
 }


 // 
 //    Main Decoding Loop
 //
 iPop = iPush = 0;
 for (iFrameCount=0;;iFrameCount++) {

	  // Read next input pitch 
	  if (1!=fread(&fInputPitch,
	 	           sizeof(float),
				   1,
				   stMainParams.fpInputPitch)) {
       break;
	  }

      // Read next input log energy 
	  if (1!=fread(&fInputLogEnergy,
	 	           sizeof(float),
				   1,
				   stMainParams.fpInputLogEnergy)) {
       break;
	  }

      if (stMainParams.fpInputVoicing != NULL) {
          if (1 != fscanf(stMainParams.fpInputVoicing,"%c",&cVoicingClass)) {
              printf("Error: cannot read a value from the input voicing file\n");
              exit(1);
          }
          // Push input pitch and voicing class values
          pfInpPitchBuf[iPush] = fInputPitch;
          pcInpVoicingBuf[iPush] = cVoicingClass;
          iPush = (iPush+1)%(iFramesDelay+1);
      }

      // Calculate new output pitch value
      PitchTracking(pPitchTracking,
		    fInputPitch,
		    fInputLogEnergy,
		    &fOutputPitch);

      // Write new value of pitch to output 
      // Discard first values corresponding to negative time frames,
      // such that the output pitch is time aligned with the input pitch
      if (iFrameCount>=iFramesDelay) {
       if(1 != (int)fwrite(&fOutputPitch, 
                          sizeof(float), 
                          1, 
                          stMainParams.fpOutputPitch)) {
        printf(" Error: failed writing to output file\n");
	    CloseFiles(&stMainParams);
        exit(1); 
       }

       if (stMainParams.fpInputVoicing != NULL) {
          // Pop input pitch and voicing values, process voicing class and write
           fInputPitch = pfInpPitchBuf[iPop];
           cVoicingClass = pcInpVoicingBuf[iPop];
           iPop = (iPop+1)%(iFramesDelay+1);
           if ((cPreviousClass == '2') && (cVoicingClass == '3') &&
               (pcInpVoicingBuf[iPop] <= '2'))
           {
             cVoicingClass = '2';
           }
           if (0 == fInputPitch && 0 != fOutputPitch) cVoicingClass = '2';
           else if (0 != fInputPitch && 0 == fOutputPitch) cVoicingClass = '1';
           if (1 != fprintf(stMainParams.fpOutputVoicing,"%c",cVoicingClass)) {
               printf(" Error: failed writing to output file\n");
	           CloseFiles(&stMainParams);
               exit(1);
           }
           cPreviousClass = cVoicingClass;
       } // endif process voicing class

      } // endif iFrameCount>=iFramesDelay

                   
      // Print frame in process
      if (!QuietMode)
        printf(" Processed %d frames\r",iFrameCount);	  
 } // end of frame loop


 //
 // Extract last output pitch values by assuming
 // NULL input. This is required because we want
 // the output pitch file to be alinged with the
 // input pitch file and with the same length
 //
 for (iFrameCount=0;iFrameCount<iFramesDelay;iFrameCount++) {

      // Calculate new pitch value with null input
      PitchTracking(pPitchTracking,
		    UNVOICED,
		    MIN_LOG_E,
		    &fOutputPitch);
       

      // Write new value of pitch to output 
      if(1 != (int)fwrite(&fOutputPitch, 
                          sizeof(float), 
                          1, 
                          stMainParams.fpOutputPitch)) {
        printf(" Error: failed writing to output file\n");
	    CloseFiles(&stMainParams);
        exit(1); 
      }

      if (stMainParams.fpInputVoicing != NULL) {
         // Pop input pitch and voicing values, process voicing class and write
           fInputPitch = pfInpPitchBuf[iPop];
           cVoicingClass = pcInpVoicingBuf[iPop];
           iPop = (iPop+1)%(iFramesDelay+1);
           if ((cPreviousClass == '2') && (cVoicingClass == '3') &&
               (pcInpVoicingBuf[iPop] <= '2'))
           {
             cVoicingClass = '2';
           }
           if (0 == fInputPitch && 0 != fOutputPitch) cVoicingClass = '2';
           else if (0 != fInputPitch && 0 == fOutputPitch) cVoicingClass = '1';
           if (1 != fprintf(stMainParams.fpOutputVoicing,"%c",cVoicingClass)) {
               printf(" Error: failed writing to output file\n");
	           CloseFiles(&stMainParams);
               exit(1);
           }
           cPreviousClass = cVoicingClass;
       } // endif process voicing class
                 
 } // end of second frame loop

 free(pPitchTracking);

 if (stMainParams.fpInputVoicing != NULL) {
     free(pfInpPitchBuf);
     free(pcInpVoicingBuf);
 }

 // Close files and free allocated buffers
 CloseFiles(&stMainParams);
 
 if (!QuietMode)
    printf("\n Done.\n\n\n");

 exit(0);
}


// Close opened files
void CloseFiles(MAIN_PARAMS *pstMainParams)
{
  if (pstMainParams->fpOutputPitch != NULL) 
	  fclose(pstMainParams->fpOutputPitch);
  if (pstMainParams->fpInputPitch != NULL) 
	  fclose(pstMainParams->fpInputPitch);
  if (pstMainParams->fpInputLogEnergy != NULL) 
	  fclose(pstMainParams->fpInputLogEnergy);
  if (pstMainParams->fpInputVoicing != NULL) 
	  fclose(pstMainParams->fpInputVoicing);
  if (pstMainParams->fpOutputVoicing != NULL) 
	  fclose(pstMainParams->fpOutputVoicing);
}

// Get size of file in bytes. File must already be opned.
static int  FileLenght(FILE *fp)
{
 int iFileLength;

 if (NULL==fp) {
    return(-1);
 }

 fseek(fp,0,SEEK_END);
 iFileLength = ftell(fp);
 fseek(fp,0,SEEK_SET);

 return(iFileLength);
}

// Read and process command line arguments
void ReadInputArguments(int iArgc,
                        char *pcArgv[],
		                MAIN_PARAMS *pstMainParams)
{
 int iArgIndx;

 // If run without arguments, print usage help
 if (iArgc==1) {
   PrintHeader();    
   PrintUsage();
   exit(1);   
 }
  
 // Set default arguments
 pstMainParams->fpOutputPitch    = NULL;
 pstMainParams->fpInputPitch     = NULL;
 pstMainParams->fpInputLogEnergy = NULL;
 pstMainParams->fpInputVoicing     = NULL;
 pstMainParams->fpOutputVoicing     = NULL;

 for(iArgIndx = 1; iArgIndx < iArgc; iArgIndx++) {
     if (0==strcmp("-q",pcArgv[iArgIndx])) {
         QuietMode = 1;
         break;
     }
 }

 if (!QuietMode)
    PrintHeader();
   
 for(iArgIndx = 1; iArgIndx < iArgc; iArgIndx++) {
    
    //  
    // Process output pitch file name
    //
    if (0==strcmp("-op",pcArgv[iArgIndx])) {
      if (iArgIndx < iArgc-1 &&
        (pstMainParams->fpOutputPitch = fopen(pcArgv[iArgIndx+1], "wb")) == NULL) {
        printf(" Error: can't open output pitch file\n");
        exit(1);
      }
      if (!QuietMode)
        printf(" Output pitch file:      %s\n",  pcArgv[iArgIndx+1]);
    } 
    	
    //
    // Process input pitch file name
    //
    else if (0==strcmp("-ip",pcArgv[iArgIndx])) {
      if (iArgIndx < iArgc-1 &&
        (pstMainParams->fpInputPitch = fopen(pcArgv[iArgIndx+1], "rb")) == NULL) {
        printf(" Error: can't open input pitch file\n");
        exit(1);
      }
      if (!QuietMode)
        printf(" Input pitch file:       %s\n",  pcArgv[iArgIndx+1]);
    }
     
    //
    // Process input log energy file name
    //
    else if (0==strcmp("-ie",pcArgv[iArgIndx])) {
      if (iArgIndx < iArgc-1 &&
        (pstMainParams->fpInputLogEnergy = fopen(pcArgv[iArgIndx+1], "rb")) == NULL) {
        printf(" Error: can't open input log energy file\n");
        exit(1);
      }
      if (!QuietMode)
        printf(" Input log energy file:  %s\n",  pcArgv[iArgIndx+1]);
    } 
    
    else if (0==strcmp("-iv",pcArgv[iArgIndx])) {
      if (iArgIndx < iArgc-1 &&
        (pstMainParams->fpInputVoicing = fopen(pcArgv[iArgIndx+1], "r")) == NULL) {
        printf(" Error: can't open input voicing class file\n");
        exit(1);
      }
      if (!QuietMode)
        printf(" Input voicing file:       %s\n",  pcArgv[iArgIndx+1]);
    }

    else if (0==strcmp("-ov",pcArgv[iArgIndx])) {
      if (iArgIndx < iArgc-1 &&
        (pstMainParams->fpOutputVoicing = fopen(pcArgv[iArgIndx+1], "w")) == NULL) {
        printf(" Error: can't open output voicing class file\n");
        exit(1);
      }
      if (!QuietMode)
        printf(" Output voicing file:       %s\n",  pcArgv[iArgIndx+1]);
    }

     
  
 }	// end of arguments read loop 

 //
 // Check if mandatory files were given
 //  
 if (NULL == pstMainParams->fpOutputPitch ||
	 NULL == pstMainParams->fpInputPitch  ||
     NULL == pstMainParams->fpInputLogEnergy) {
		PrintUsage();
		exit(1);   
 }

 if ((NULL == pstMainParams->fpInputVoicing &&
     NULL != pstMainParams->fpOutputVoicing) ||
     (NULL != pstMainParams->fpInputVoicing &&
     NULL == pstMainParams->fpOutputVoicing)) {
     printf("Error: both -iv and -ov options must be either specified\n");
     printf("       or not sumultaneously\n");
     exit(1);
 }
  
}



void PrintHeader()
{
 printf("\n");
 printf("\n");
 printf(" ETSI ES 202 212 Server Side Pitch & Voicing Class Tracking and Smoothing\n");
 printf(" Compiled at %s\n",__DATE__);
 printf("\n"); 
}

void PrintUsage()
{
 printf("\n");
 printf("\n");
 printf(" Usage:\n");
 printf("\n");
 printf(" PitchTrack    -ip  <input_pitch_file_name>\n");
 printf("               -ie  <input_log_energy_file_name>\n");
 printf("               -op  <output_pitch_file_name>\n");
 printf("              [-iv  <input_voicing_file_name>]\n");
 printf("              [-ov  <output_voicing_file_name>]\n");
 printf("\n");
 printf(" Where:\n");
 printf("   <input_pitch_file_name> - Input floating\n"); 
 printf("   point pitch periods. One number for each frame\n");
 printf("   in 8 Khz samples. A zero value indicates unvoiced frame.\n");
 printf("\n");
 printf("   <input_log_energy_file_name> - Input floating\n"); 
 printf("   point log energy values, as defined in the ETSI DSR\n");
 printf("   front-end. One number for each frame.\n");
 printf("\n");
 printf("   <output_pitch_file_name> - Output floating\n"); 
 printf("   point pitch periods. The format is the same as the input\n");
 printf("   format, and the file will be of the same length. The input\n");
 printf("   and output pitch values are time aligned.\n");
 printf("\n");
 printf("   <input/output_voicing_file_name> - ASCII encoded voicing class\n");
 printf("\n\n");
}


