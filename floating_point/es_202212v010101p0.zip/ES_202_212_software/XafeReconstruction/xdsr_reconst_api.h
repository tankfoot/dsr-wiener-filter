/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: xdsr_recons_api.h
 * PURPOSE:   This file contains the declaration of the reconstruction 
 *            package API
 *
 *-------------------------------------------------------------------------------*/

#ifndef XDSR_RECONST_API_H
#define XDSR_RECONST_API_H





/*----------------------------------------------------------------------------
 * FUNCTION NAME: XDSR_InitReconstructor
 *
 * PURPOSE:       Initialize the reconstruction, i.e. create an instance
 *                of Reconstructor that should be passed to other
 *                API functions
 *
 * INPUT:
 *    iSampleRatekHz   Sampling rate in kHz
 * OUTPUT
 *   ppvReconstructor  Pointer to the Reconstructor data structure
 *   piPcmFrameSize    Length of the portion (frame) of output speech signal
 *                     produced by each call to the XDSR_ReconstructFrame()
 *                     function
 * RETURN VALUE
 *   0 - OK
 *   1 - memomy allocation error
 *---------------------------------------------------------------------------*/
int XDSR_InitReconstructor(
                void**            ppvReconstructor,
                const int         iSampleRatekHz, 
                int*              piPcmFrameSize);


/*----------------------------------------------------------------------------
 * FUNCTION NAME: XDSR_ReleaseReconstructor
 *
 * PURPOSE:       Deallocate the Reconstructor
 *
 * INPUT:
 *   pvReconstructor  Pointer to Reconstructor (produced by XDSR_InitReconstructor())
 * OUTPUT
 *   none
 * RETURN VALUE
 *   none
 *---------------------------------------------------------------------------*/
void	XDSR_ReleaseReconstructor(void* pvReconstructor);





/*----------------------------------------------------------------------------
 * FUNCTION NAME:  XDSR_ReconstructFrame
 *
 * PURPOSE:     Reconstruct the next frame of speech signal
 *
 * INPUT/OUTPUT:
 *   pvReconstructor  Pointer to Reconstructor object which is modified 
 *                    by every call to this function
 * INPUT:
 *   pfFeatureVector  Feature vector containing 13 MFCC and log-energy
 *                    [C1,...,C12,C0,logE]
 *   fPitchPeriod8khz Pitch period (number of samples at 8kHz rate)
 *   cVoicingClass    Voicing class
 * OUTPUT
 *   psOutputPCM      Reconstructed frame, its size is defined by
 *                    the call to XDSR_InitReconstructor()
 * RETURN VALUE
 *   none
 *---------------------------------------------------------------------------*/
void XDSR_ReconstructFrame(
                void*  pvReconstructor,
                float  *pfFeatureVector, 
                float  fPitchPeriod8khz,
                unsigned char cVoicingClass,
                short  *psOutputPCM
                );







#endif








