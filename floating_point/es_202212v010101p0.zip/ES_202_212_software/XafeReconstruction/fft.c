/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: fft.c
 * PURPOSE:   FFT implementation
 *
 *-------------------------------------------------------------------------------*/

#include <math.h>
#include <stdio.h>




#define SWAP(a,b) tempr=(a);(a)=(b);(b)=tempr              
  
                                                           
static void four1(float *data, int nn, int isign);                      
                                
/*----------------------------------------------------------------------------
 * FUNCTION NAME:  realft
 *
 * PURPOSE:   FFT/IFFT for real valued signals, done in-place
 * 
 * INPUT/OUTPUT:
 *   data - Input output array. 
 *          Spectrum data layout: data[0] = Re(0), data[1] = Re(pi),
 *             data[2k]=Re(2pi*k/n),data[2k+1]=Im(2pi*k/n),...; k=1,2,... 
 * INPUT:
 *   n - the array length
 *   isign - 1: FFT, -1: Inverse FFT
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void realft(float *data, unsigned long n, int isign)      
{                                                          
	unsigned long i,i1,i2,i3,i4,np3;                          
	float c1=0.5f,c2,h1r,h1i,h2r,h2i;                          
	float wr,wi,wpr,wpi,wtemp,theta;                          
	float *orig_data;

	if (isign==-1)
		data[n/2+1] = -data[n/2+1];
	orig_data = data;

	data-= 1; 
                                                           
	theta=-3.141592653589793f/(float) (n>>1);                  
	if (isign == 1) {                                         
		c2 = -0.5f;                                              
		four1(data,n>>1,1);                                      
	} else {                                                  
		c2=0.5f;                                                 
		theta = -theta;                                          
	}                                                         
	wtemp=(float)sin(0.5*theta);                              
	wpr = -2.0f*wtemp*wtemp;                                  
	wpi=(float)sin(theta);                                    
	wr=1.0f+wpr;                                              
	wi=wpi;                                                   
	np3=n+3;                                                  
	for (i=2;i<=(n>>2);i++) {                                 
		i4=1+(i3=np3-(i2=1+(i1=i+i-1)));                         
		h1r=c1*(data[i1]+data[i3]);                              
		h1i=c1*(data[i2]-data[i4]);                              
		h2r = -c2*(data[i2]+data[i4]);                           
		h2i=c2*(data[i1]-data[i3]);                              
		data[i1]=(float)(h1r+wr*h2r-wi*h2i);                     
		data[i2]=(float)(h1i+wr*h2i+wi*h2r);                     
		data[i3]=(float)(h1r-wr*h2r+wi*h2i);                     
		data[i4]=(float)(-h1i+wr*h2i+wi*h2r);                    
		wr=(wtemp=wr)*wpr-wi*wpi+wr;                             
		wi=wi*wpr+wtemp*wpi+wi;                                  
	}                                                         
	if (isign == 1) {                                         
		data[1] = (float)((h1r=data[1])+data[2]);                
		data[2] = (float)(h1r-data[2]);                          
	} else {                                                  
		data[1]=(float)(c1*((h1r=data[1])+data[2]));             
		data[2]=(float)(c1*(h1r-data[2]));                       
		four1(data,n>>1,-1);                                     
	}                                                         

	if (isign==1)
		orig_data[n/2+1] = -orig_data[n/2+1];


}                                                          



static void four1( float *data, int nn, int isign)
{
        int n,mmax,m,j,istep,i;
        float      wtemp,wr,wpr,wpi,wi,theta;
        float        tempr,tempi;

        n=nn << 1;
        j=1;
        for (i=1;i<n;i+=2) {
                if (j > i) {
                        SWAP(data[j],data[i]);
                        SWAP(data[j+1],data[i+1]);
                }
                m=n >> 1;
                while (m >= 2 && j > m) {
                        j -= m;
                        m >>= 1;
                }
                j += m;
        }
        mmax=2;
        while (n > mmax) {
                istep=2*mmax;
                theta=-(float)(6.28318530717959/(isign*mmax));
                wtemp=(float)sin(0.5*theta);
                wpr = (float)(-2.0*wtemp*wtemp);
                wpi=(float)sin(theta);
                wr=(float)1.0;
                wi=(float)0.0;
                for (m=1;m<mmax;m+=2) {
                        for (i=m;i<=n;i+=istep) {
                                j=i+mmax;
                                tempr= (float) (wr*data[j]-wi*data[j+1]);
                                tempi= (float) (wr*data[j+1]+wi*data[j]);
                                data[j]=data[i]-tempr;
                                data[j+1]=data[i+1]-tempi;
                                data[i] += tempr;
                                data[i+1] += tempi;
                        }
                        wr=(wtemp=wr)*wpr-wi*wpi+wr;
                        wi=wi*wpr+wtemp*wpi+wi;
                }
                mmax=istep;
        }


         if ( isign==-1 )
          {  /* inverse transform */
                  tempi= (float)1.0/nn;
                  for ( i=1; i<=2*nn; i++ )
                          data[i]*= tempi;
          }
}


