/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: utils.c
 * PURPOSE:   Miscellaneous routines
 *
 *-------------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>



#include "common.h"


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  AddPhase
 *
 * PURPOSE:   Multiply two complex numbers with unit absolute value each
 * INPUT:
 *   fCos1 + j*fSin1 - first numer
 *   fCos2 + j*fSin2 - second numer
 * OUTPUT:
 *   pfCos + j*pfSin
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void AddPhase(
        float fCos1,
        float fSin1,
        float fCos2,
        float fSin2,
        float *pfCos,
        float *pfSin        
        )
{
    float fCos, fSin;

    fCos = fCos1*fCos2 - fSin1*fSin2;
    fSin = fCos1*fSin2 + fSin1*fCos2;
    *pfCos = fCos;
    *pfSin = fSin;
}






/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GetCosSinOfQuantizedArg
 *
 * PURPOSE:   Retrieve table values of Cos and Sin by index
 * INPUT:
 *   pstRec - pointer to the Reconstructor
 *   iIndex - the index
 * OUTPUT:
 *   pfCos, pfSin - cos and sin
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GetCosSinOfQuantizedArg(Reconstructor *pstRec,                           
                             int           iIndex,
                             float         *pfSin,
                             float         *pfCos)
                      
{
    float *pfSinTable = pstRec->afSinTable;
    float *pfCosTable = pstRec->afCosTable;

    // The implied argument is 2pi*iIndex/SIN_TABLE_RES. We should subtract
    // from it the maximal integer multiple of 2pi.
    iIndex %= SIN_TABLE_RES_MASK;
    // Now iIndex < SIN_TABLE_RES

   // If the implied argument (2pi*iIndex/SIN_TABLE_RES) is in the range [0,pi),
   // then enter the cos and sin tables whith the index
    if (iIndex < SIN_TABLE_SIZE) {
        *pfSin = pfSinTable[iIndex];
        *pfCos = pfCosTable[iIndex];    
    }
   // Otherwise, the implied argument is in the range [pi,2pi), so subtract
   // pi and enter the sin and cos tables with sign correction
   // cos(x) = -cos(x-pi) , sin(x) = -sin(x-pi)
   else {
        iIndex -= SIN_TABLE_SIZE;
        *pfSin = -pfSinTable[iIndex];
        *pfCos = -pfCosTable[iIndex];    
   }
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GetCosSinOfNormalizedArg
 *
 * PURPOSE:   Given normalized frequency retrieve Cos and Sin values from the tables 
 * INPUT:
 *   pstRec - pointer to the Reconstructor
 *   fNormArg - normalized frequency
 * OUTPUT:
 *   pfCos, pfSin - cos and sin
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GetCosSinOfNormalizedArg(Reconstructor *pstRec,                               
                              float         fNormArg,
                              float         *pfSin,
                              float         *pfCos)
                      
{
    int iIndex;

    // Quantize fNormArg
    iIndex = (int)((float)SIN_TABLE_RES*fNormArg + 0.5f);
    GetCosSinOfQuantizedArg(pstRec, iIndex, pfSin, pfCos);   
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GetCosSin
 *
 * PURPOSE:   Given cyclic frequency retrieve Cos and Sin values from the tables 
 * INPUT:
 *   pstRec - pointer to the Reconstructor
 *   fArg - cyclic frequency
 * OUTPUT:
 *   pfCos, pfSin - cos and sin
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GetCosSin(Reconstructor *pstRec, 
               float         fArg,
               float         *pfSin,
               float         *pfCos)
                      
{
    int iIndex;
    

    // Quantize fArg
    iIndex = (int)((float)SIN_TABLE_RES*fArg*M_1_2PI + 0.5f);
    GetCosSinOfQuantizedArg(pstRec, iIndex, pfSin, pfCos);   
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GetRandomPhase
 *
 * PURPOSE:   Random phase generator
 * INPUT/OUTPUT:
 *   pstRec - pointer to the Reconstructor
 * OUTPUT:
 *   pfCosRandPhase, pfSinRandPhase - cos and sin of the random phase
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GetRandomPhase(Reconstructor *pstRec,
                    float         *pfSinRandPhase,
                    float         *pfCosRandPhase)
{
    int iUVPhase, iUVPhaseIndex;

    iUVPhaseIndex = pstRec->iUVPhaseIndex;
    iUVPhase = pstRec->piUVphaseTable[iUVPhaseIndex];
    // iUVPhase is a quantized phase
    GetCosSinOfQuantizedArg(pstRec,iUVPhase,pfSinRandPhase,pfCosRandPhase);                          
    // Be prepared for the next access to the random phase table                             
    pstRec->iUVPhaseIndex++;
    if (pstRec->iUVPhaseIndex >= pstRec->iUVPhaseTableSize) 
        pstRec->iUVPhaseIndex = 0;
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  ReconstructDftFromHarmonics
 *
 * PURPOSE:   Sample at DFT points the convolution of given harmonics with window
 *            Fourier Transform. In other words, this function builds STFT which
 *            may be used for modeling or OLA synthesis
 * INPUT:
 *   pstHarmonic - array of harmonics
 *   pfWinTrans  - set of shifted window transform operators
 *   iNoOfHarmonics - Number of harmonics in the array
 *   iDftLimit - The highest DFT point to be computed
 *   iWinFtBw  - The bandwidth of window FT oparator measured in DFT points
 *   pfAdditionalWeights - if not NULL specifies weights to be applied
                           to harmonics amplitude
 * OUTPUT:
 *   pfDftResult -    A complex array that will hold the reconstruced
 *                    DFT. Its size is (iDftLimit + 1)
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void ReconstructDftFromHarmonics(
                 Cmplx           *pfDftResult,
                 HarmonicInfo    *pstHarmonic,
                 float           *pfWinTrans,
                 int             iNoOfHarmonics,
                 int             iDftLimit,
                 int             iWinFtBw,
                 float           *pfAdditionalWeights
                 )
{
    int i;
    int    iWinFTIndx;
    int    iDftStartLocation, iDftEndLocation,
           iWinFTStartLocation, iWinFTEndLocation;
    float  fReal,fImag;
    float  fAdditionalWeight;
    
    float  *pfScanWinTrans;
    Cmplx  *pfScanDftResult;
    int    iSampleSetIndx;
    int    iTotalWinSamples = 2*iWinFtBw+1;

 

    // Reset resulting complex DFT
    memset(pfDftResult, 0, sizeof(Cmplx) * (iDftLimit + 1));
 
    // -------------------------------
    //   Loop over all harmonics
    // -------------------------------
    for (i=0; i<iNoOfHarmonics; i++, pstHarmonic++) {

        // Calculate first DFT point affected by the current harmonic
        iDftStartLocation  = pstHarmonic->iDftFreq  - iWinFtBw;

        // Calculate start point of the Win FT operator (usualy 0)
	    iWinFTStartLocation =  
            (iDftStartLocation < 0) ? (-iDftStartLocation) : 0;
   
        // Calculate last DFT point affected by the current harmonic
        iDftEndLocation = pstHarmonic->iDftFreq  + iWinFtBw;

	    // Calculate end point of the Win FT operator
        iWinFTEndLocation = iTotalWinSamples-1;


        // Check if overflow        
        if (iDftEndLocation >= iDftLimit) 
            iWinFTEndLocation -= (iDftEndLocation - iDftLimit + 1);

        // Initialize
        fReal = pstHarmonic->fAmpCosPhase; 
        fImag = pstHarmonic->fAmpSinPhase;

        // Apply additional weight if required
	    if (NULL != pfAdditionalWeights) {
            fAdditionalWeight = *pfAdditionalWeights;
            pfAdditionalWeights++;            
            fReal *= fAdditionalWeight;
            fImag *= fAdditionalWeight;
        }
              

        iSampleSetIndx = pstHarmonic->iWinSampleSet;
        pfScanWinTrans  = 
            &(pfWinTrans[iSampleSetIndx*iTotalWinSamples+iWinFTStartLocation]);
        pfScanDftResult = 
            &(pfDftResult[iDftStartLocation+iWinFTStartLocation]);

        // Loop over all samples of the Win FT operator
        for (iWinFTIndx = iWinFTStartLocation;
        iWinFTIndx <= iWinFTEndLocation;
        iWinFTIndx++, pfScanWinTrans++, pfScanDftResult++) {
            pfScanDftResult->real += *pfScanWinTrans * fReal;
            pfScanDftResult->imag += *pfScanWinTrans * fImag;                
        }

    } // end of loop over all harmonics

}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  ApplyMelFiltersBank
 *
 * PURPOSE:   Apply Mel-filters as defined by the front-end
 *
 * INPUT:
 *   pstDft  - Short-time FT
 *   pstMel  - array of 24 Mel-filters
 *
 * OUTPUT:
 *   pfBins - output vector, dimension = 24
 *                    DFT. Its size is (iDftLimit + 1)
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void  ApplyMelFiltersBank(
		             Cmplx     *pstDft,
			         MelFilter *pstMel,
			         float     *pfBins
                     )
{
    int j, iMelNo;
    float fSum,fAbs;

    // Reset resulting bins buffer
    memset(pfBins,0,NUM_OF_FILTERS*sizeof(float));

    // Loop over all mel filtes
    for  (iMelNo=0; iMelNo < NUM_OF_FILTERS; iMelNo++, pstMel++) {

        fSum = 0.0f;

        for(j=pstMel->iStartingPoint; j <= pstMel->iEndingPoint; j++) {
            fAbs = pstDft[j].real*pstDft[j].real + 
	               pstDft[j].imag*pstDft[j].imag;
           
	       fSum += (float)sqrt(fAbs)*
                           pstMel->pfData[j-pstMel->iStartingPoint];	
        }

        pfBins[iMelNo] = fSum;

    } // end of loop over mel filters
 

}

/*----------------------------------------------------------------------------
 * FUNCTION NAME:  SamplePreEmpFilter
 *
 * PURPOSE:   Sample the pre-emphasis filter (used at the front-end)
 *            at harmonic frequencies
 * INPUT:
 *   pstRec  - pointer to the Reconstructor
 *   iNoOfHarmonics - number of harmonics 
 *
 * INPUT/OUTPUT:
 *   pstHarmonicInfo - array of the harmonics
 *   
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void SamplePreEmpFilter(
                     Reconstructor *pstRec,
                     int           iNoOfHarmonics,
                     HarmonicInfo  *pstHarmonicInfo
                     )
{
    int i;
    float fOmega, fAbs, fCos, fSin;

    
    for (i=0; i<iNoOfHarmonics; i++, pstHarmonicInfo++) {
        fOmega = pstHarmonicInfo->fOmega;
                
        fCos = (float)cos(fOmega);
        fSin = (float)sin(fOmega);
        fAbs = (float)sqrt(1.f + pstRec->fPreEmph*pstRec->fPreEmph 
                           - 2.f*pstRec->fPreEmph*fCos);
        fCos = (1.f - pstRec->fPreEmph*fCos)/fAbs;
        fSin = pstRec->fPreEmph*fSin/fAbs;

        pstHarmonicInfo->fPreEmpAmp = fAbs;
        pstHarmonicInfo->fPreEmpCosPhase = fCos;
        pstHarmonicInfo->fPreEmpSinPhase = fSin;
    }
}






/*----------------------------------------------------------------------------
 * FUNCTION NAME:  CepstraToBinSpectrum
 *
 * PURPOSE:    Converts cepstra to binned spectra using IDCT and exp
 *            
 * INPUT/OUTPUT:
 *   pstRec  - pointer to the Reconstructor
 * INPUT:
 *   pfCepstra - array of (Low Order) cepstra
 *
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void CepstraToBinSpectrum(Reconstructor  *pstRec,
                          float          *pfCepstra)
{
    float fAccSum, fDCOffset;
    int    i, j;
    int    iDim        = pstRec->iCepstralDim-1; // without c0 !
    float  *pfBinSpectrum  = pstRec->afBinSpec;
    float  *pfBinSpectrumSave  = pstRec->afBinSpecSave;
    float  *pfIDCTMatrixRow;

    fDCOffset = pfCepstra[iDim] / (float) NUM_OF_FILTERS;

    for (j = 0; j < NUM_OF_FILTERS; j++) {

        // Begin IDCT sum with common first value.
        fAccSum = fDCOffset;
        pfIDCTMatrixRow = pstRec->aafIdct[j];
        for (i = 0; i < iDim; i++)
            fAccSum += pfCepstra[i] * pfIDCTMatrixRow[i];
   
	    // Inverse natural log operation done in the front-end
        pfBinSpectrum[j] = (float)exp(fAccSum);
        pfBinSpectrumSave[j] = pfBinSpectrum[j];
	
    } // of j loop

}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  AddHighestCepstra
 *
 * PURPOSE:    Add HOC in binned spectrum respresentation, i.e. multiply
 *             given (LOC) binned spectrum by a component corresponding to
 *             HOC  
 *            
 * INPUT/OUTPUT:
 *   pstRec  - pointer to the Reconstructor
 * INPUT:
 *   pfCepstra - High Order cepstra
 *
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void AddHighestCepstra(Reconstructor  *pstRec,
                       float          *pfCepstra)
{
    float fBin;
    int    i, j;
    int    iDim;
    float  *pfBinSpectrum  = pstRec->afBinSpec;
    float  *pfBinSpectrumSave  = pstRec->afBinSpecSave;
    float  *pfIDCTMatrixRow;
    int    iFirstHighCepsNo;
    
    iFirstHighCepsNo = pstRec->iCepstralDim-1;
    // use the columns #iFirstHighCepsNo,...,#NUM_OF_FILTERS-2
    // (the first column has #0)
    iDim = NUM_OF_FILTERS - pstRec->iCepstralDim;

    for (j = 0; j < NUM_OF_FILTERS; j++) {        
        fBin = 0.f;
        pfIDCTMatrixRow = pstRec->aafIdct[j];
        for (i = 0; i < iDim; i++)
            fBin += pfCepstra[i] * pfIDCTMatrixRow[iFirstHighCepsNo +i];
   
	    // Inverse natural log operation done in the front-end
        fBin = (float)exp(fBin);
        pfBinSpectrum[j] = pfBinSpectrumSave[j]*fBin;
	
    } // of j loop

}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:   Fix16kHzCepstraAndEnergy
 *
 * PURPOSE:   Given 16kHz feature vercotr approximate 8kHz feature vector.
 *             
 *             
 *            
 * INPUT:
 *   pstRec  - pointer to the Reconstructor
 * INPUT/OUTPUT:
 *   pfCepstra - High Order cepstra
 *
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void Fix16kHzCepstraAndEnergy(
			      Reconstructor  *pstRec,
			      float          *pfCepstra)
{
    float fAccSum, fDCOffset;
    int    i, j;
    int    iDim        = pstRec->iCepstralDim-1;
    static float  afLogBins[NUM_OF_FILTERS_EXT];
    float  *pfMatrixRow;
    float fFixEnr, fSaveLogEnr;
    

    // Cepstra -> LogBins
    fDCOffset = pfCepstra[iDim] / (float) NUM_OF_FILTERS_EXT;

    for (j = 0; j < NUM_OF_FILTERS_EXT; j++) {

        // Begin IDCT sum with common first value.
        fAccSum = fDCOffset;
        pfMatrixRow = pstRec->aafIdctExt[j];
        for (i = 0; i < iDim; i++) {
            fAccSum += pfCepstra[i] * pfMatrixRow[i];
        }
        afLogBins[j] = fAccSum;
	
    } // of j loop

    // LogBins excluding extended values -> Cepstra

    for (i = 0; i < STD_NUM_CEPS-1; i++) {        
        pfCepstra[i] = 0.f;
        pfMatrixRow = pstRec->aafDct[i];
        for (j = 0; j < NUM_OF_FILTERS; j++) {
            pfCepstra[i] += afLogBins[j] * pfMatrixRow[j];   	    	
        }
    }
    // C0
    pfCepstra[STD_NUM_CEPS-1] = 0.f;
    for (j = 0; j < NUM_OF_FILTERS; j++)
        pfCepstra[STD_NUM_CEPS-1] += afLogBins[j];

    // Fix Energy
    fSaveLogEnr = pfCepstra[STD_NUM_CEPS];
    fFixEnr = 0.f;
    for (i=NUM_OF_FILTERS; i < NUM_OF_FILTERS_EXT; i++) 
        fFixEnr += (float)exp(afLogBins[i]-log(1.9));
    pfCepstra[STD_NUM_CEPS] = (float)exp(pfCepstra[STD_NUM_CEPS]);
    pfCepstra[STD_NUM_CEPS] -= fFixEnr;
    if (pfCepstra[STD_NUM_CEPS] < 0) {                
        pfCepstra[STD_NUM_CEPS] = fSaveLogEnr;
    }
    else {        
        if (pfCepstra[STD_NUM_CEPS] < pstRec->f_EXP_LOG_FLOOR)
            pfCepstra[STD_NUM_CEPS] = LOG_FLOOR;
        else			
            pfCepstra[STD_NUM_CEPS] = (float)(log(pfCepstra[STD_NUM_CEPS]));
    }
    
    

}
