/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: common.h
 * PURPOSE:   Types and constants definition, functions declaration
 *
 *-------------------------------------------------------------------------------*/

#ifndef COMMON_H
#define COMMON_H

#include "xdsr_reconst_api.h"






// ===================================================================
//      General types, constants and macros
// ===================================================================   


// Boolean type  
typedef int BOOL;
#ifndef TRUE
	#define TRUE	(BOOL)1
#endif
#ifndef FALSE
	#define FALSE	(BOOL)0 
#endif



//
// Dynamic memory allocation
//
#define MALLOCATE(pVar, VarType, Number, iReturnCode)  \
	if ((VarType *)NULL==(pVar=(VarType *)malloc((Number)*sizeof(VarType)))) {	\
	   iReturnCode = 1;	\
	} else {	\
	  memset(pVar,0,(Number)*(sizeof(VarType)));	\
        iReturnCode = 0; \
	}

//
// Free dynamically allocated memory
//
#define MDEALLOCATE(var) \
 if (NULL!=(var)) {\
  free(var);\
  var=NULL;\
 }



#ifndef MIN
#define MIN(x,y)  (((x)>(y)) ? (y) :(x))
#endif

#ifndef MAX
#define MAX(x,y)  (((x)>(y)) ? (x) :(y))
#endif

#ifndef ABS
#define ABS(x)    (((x)<0) ? -(x) : (x))
#endif

#ifndef SQR
#define SQR(x)   ( (x) * (x) )
#endif



/*
 * Numerical constants
 */
#ifndef M_PI
#define M_PI        3.14159265358979323846f
#endif


#ifndef M_1_PI
#define M_1_PI      0.31830988618379067154f
#endif

#ifndef M_2PI
#define M_2PI        (2.0f * M_PI)
#endif

#ifndef M_1_2PI
#define M_1_2PI     (0.5f * M_1_PI)
#endif




//
// Complex number type
//
#ifndef CMPLX_DEFINED
#define CMPLX_DEFINED

typedef struct Cmplx_t {
  float real;
  float imag;
} Cmplx;
#endif




#define LOG_FLOOR  (-50.f)





// =======================================================================
//              Reconstruction Related Constants
// =======================================================================

// Number of Mel-filters used by Front-end
#define NUM_OF_FILTERS   23

// For 16kHz
#define NUM_OF_HB_FILTERS   3
#define NUM_OF_FILTERS_EXT   (NUM_OF_FILTERS + NUM_OF_HB_FILTERS)

// Number of MFCC computed by ETSI DSR Front-end
#define STD_NUM_CEPS     13


// The lower edge of the lowest filter used by the Front-end
#define STARTING_FREQ     64.f

// Defines low and high bands for semi-voiced frames reconstruction.   
// Pitch harmonics are generated in the low band while noisy (unvoiced)
// harmonics are generated in the high band. The value is given in Hz.
#define V_UV_TRANSITION_FREQ  1200.f

// Define the normalized upper frequency for harmonics used for reconstruction
// as a part of the full band (Nyquist frequency) 
#define UPPER_NORM_FREQ   0.93f 


//
//  Parameters of Sin/Cos table implementaion
//
#define SIN_TABLE_RES      512
#define SIN_TABLE_SIZE     256
#define SIN_TABLE_RES_MASK 0x1FF 
                                 

// Maximum all-pole model order - The all-pole model is computed from
// the harmonic magnitudes and is used for "additional" phase calculation
// as well as for adaptive postfiltering.
#define	MAX_AP_MODEL_ORDER	20


// Coefficients and weight limits to be used for adaptive post-filtering

#define	PF_ALPHA	0.95f
#define	PF_BETA		0.75f

#define	PF_MU		0.50f
#define MAX_WT		1.50f
#define MIN_WT		0.50f


// Maximum number of pitch harmonics - The maximum period is 140; this
// is also the maximum number of pitch harmonics at 16 kHz sampling

#define	MAX_NUM_PITCH_HARM	256

// Pitch related constants
#define REF_SAMPLE_RATE  8000.0f        // Reference sampling rate (for pitch)
#define UV_PITCH         0              // Code for unvoiced frame



// The reconstruction process involves the convolution operation of
// the line spectrum (given by either pitch or noisy harmonics) with
// the Fourier Transform of weighting window. It is used for both:
// 1. STFT synthesis of the reconstructed signal - in that case a modified
// Hann window is used ("Synthesis Window"); and
// 2. Building equations for magnitude reconstruction by BFUN method - in
// which case Hamming window (as in Front-end) is used ("Analysis Window").
//
// The Fourier Transform of weighting window (WWFT) is pre-computed.
// We use 16 versions of WWFT corresponding to 16 different locations
// of the center relatively to a DFT point. Each version (set) samples
// the corresponding WWFT at DFT points, and all of them have the same
// span (bandwidth). 
//
#define WIN_TRANS_SETS 16  
                                                      
// The bandwidth
#define WIN_TRANS_BW  100.0f 






// =====================================================================
//      Reconstruction Related Type Definitions
// =====================================================================


// Mel filter 
typedef struct MelFilter_t {
  int                   iStartingPoint; // first DFT point of mel filter
  int                   iEndingPoint; // last DFT point of mel filter
  int                   iLength; // No of DFT points in mel filter
  float                 *pfData; // values    
} MelFilter;                     


// Basis function ROM used by BFUN magnitudes reconstruction  
typedef struct BasisFunctionROM_t {

  int           iStartingPoint;
  int		iEndingPoint;
  int           iLength;
  float         *pfData;
	
} BasisFunctionROM;

// Basis function RAM used by BFUN magnitudes reconstruction
typedef struct BasisFunctionRAM_t {

  int   iFirstHarmonic;   // Index of first harmony in the basis function
  int   iLastHarmonic;    // Index of last harmony in the basis function
  int   iTotalHarmonics; // Total number of harmonies in the basis function (equals iLastHarmony-iFirstHarmony+1)
  float *pfSampledFunc; // Value of basis function sampled at pitch harmonics within the basis function

  float *pfBins; // An array holding the bins calculted from harmonics in the basis function                     

} BasisFunctionRAM;


// ---------------------  Harmonic ---------------------------------
// The type representing a single harmonic - a component of line spectrum
// It can be either pitch harmonic or noisy harmonic used for unvoiced
// speech synthesis.

typedef struct HarmonicInfo_t {

  // Frequency
  int    iDftFreq; // The nearest DFT point. For unvoiced harmonic it
  // exactly represents the harmonic frequency.
  // iDftFreq >= 1 because no DC is assumed.
  float  fFreqHz;  // In Hz
  float  fOmega;  // Normalized cyclic
    

  float  fAmp;        // Magnitude
  float  fAmpIM;      // Magnitude obtained by INTERP method


  // Basic Phase
  // Under B.P. we mean either linear in frequency phase for pitch harmonic
  // or random phase for unvoiced harmonic 
  float  fCosPhase;   
  float  fSinPhase; 
    
  // The following entries at the final stage represent real and imaginary
  // parts of the complex amplitude associated with the harmonic.
  // At an intermediate stage they are intended to hold cos and sin of
  // Additional Phase (all-pole, etc...) which being added to the Basic
  // Phase gives a whole Phase value assotiated with the harmonic.
  float  fAmpCosPhase;  
  float  fAmpSinPhase; 
      
  // Index of weighting window Fourier Transform to be used for this
  // harmonic when computing STFT
  int    iWinSampleSet; // 0 <= iWinSampleSet < WIN_TRANS_SETS
  
  // Magnitude and Cos/Sin of the phase of the Front-end pre-emphasis filter at the
  // harmonic frequemcy
  float  fPreEmpAmp;
  float  fPreEmpCosPhase;
  float  fPreEmpSinPhase;

} HarmonicInfo;


// Only three voicing classes are used. Both NONE-SPEECH and UNVOICED
// are mapped to VOICING_CLASS_NULL

typedef enum voicing_class_t {
    VOICING_CLASS_NULL = 0, // unvoiced
    VOICING_CLASS_MIX,      // semi-voiced
    VOICING_CLASS_FULL      // voiced
} VOICING_CLASS;


//
// Reconstructor data structure holds all the pre-computed
// tables and history information required for the 
// reconstruction process
//

typedef struct Reconstructor_t {

  int             iSampleRate;            // Hz
  int             iSampleRateOrig;        // Hz


    //                 iFrameSize
    // In the context of the reconstruction by frame we mean a piece
    // of speech signal produced by each call to the reconstruction
    // function. This piece has a size given by FrameShift parameter 
    // used by the Front-End. Thus the iFrameSize in the reconstruction
    // corresponds to the FrameShift parameter of the Fron-end. 
  int             iFrameSize;

    //             Analysis Window Size
    // iAnaWinSize corresponds to the FrameSize value used by Front-end.
  int             iAnaWinSize;
	
  int             iFftSize; 
  int             iFftLimit;              // = iFftSize/2
    
  int             iVUvTransitionDftPoint; // index of the DFT-point corresponding
                                          // to the V_UV_TRANSITION_FREQ (Hz)

  int             iCepstralDim;           // Number of MFCC

  float           fPreEmph;               // Preemphasis filter parameter

  int             iAPModelOrder;
    
	
    // Mel-filters (defined by Front-End) specification.
  MelFilter       astMelFilter[NUM_OF_FILTERS];


  float     afSinTable[SIN_TABLE_SIZE];   
  float     afCosTable[SIN_TABLE_SIZE];   


  float     aafIdct[NUM_OF_FILTERS][NUM_OF_FILTERS-1];
  float     aafDct[NUM_OF_FILTERS-1][NUM_OF_FILTERS];
  
  // For 16kHz
  float           aafIdctExt[NUM_OF_FILTERS_EXT][NUM_OF_FILTERS_EXT-1];  

  // Used to undo AFE MFCC blind equalization 
  float           afAfeCepBias[STD_NUM_CEPS-1];
  float           afAfeRefCep[STD_NUM_CEPS-1];

  float           f_EXP_LOG_FLOOR;

  // Weighting Window Fourier Transform (WWFT) sets for Dirichlet window
  float*          pfDirWinTranSamples;

  // WWFT sets for analysis window used at the Front-end
  float*          pfAnaWinTranSamples;

  // WWFT sets for the OLA window used for the synthesis
  float*          pfSynWinTranSamples; 

  // WWFT span, the same for all the windows 
  int             iWinFtBw;
                                            
    
    // The following entries are used to overcome gross pitch
    // discontinuities when computing linear phase
  int*            piRationalFactors;      
  int             iNoOfRationalFactors;

  // The entries for random phase implementation
  int*            piUVphaseTable; 
  int             iUVPhaseTableSize;

    

  // Used by BFUN magnitudes reconstruction
  BasisFunctionROM   astBasisFunctionROM[NUM_OF_FILTERS];

  // For INTERP magnitudes reconstruction
  float  *pfFixCep13_INTERP;
  float  *pfFixCep23_INTERP;
  float  *pfCBinMelFreq_INTERP;

  // For initializing of missing cepstra recovery algorithm
  int    iNoOfMissMfccCentroids;
  float  *pfMissMfccCentroids;
  float  *pfMissMfccCentroidsUV;
  float  *pfMissMfccPitchThld;


  int    iUpperDftFreq;


    
  int             iUVPhaseIndex;    // Running index into random phase table

                                                                                                
  // Buffer for reconstructed frame in float representation
  float*          pfReconPcm;        
    
  // Buffer for STFT of reconstructed frame
  Cmplx*          pfReconDft;      
    
    
  // Binned spectrum - filter bank output
  float          afBinSpec[NUM_OF_FILTERS];
  float          afBinSpecSave[NUM_OF_FILTERS];

  // To hold recovered missing MFCC, 10 elemenets is enough
  float          afHighestMfcc[NUM_OF_FILTERS];
    
  // Basis function weigts - BFUN magnitudes reconstruction
  float          afBasisFuncCoefs[NUM_OF_FILTERS];
    
  // Space for BFUN normal equation matrix
  float  *aafBfunMatrix[NUM_OF_FILTERS];
  float  afBufMatrixBuffer[NUM_OF_FILTERS*NUM_OF_FILTERS];
  int    aiLUPermIndex[NUM_OF_FILTERS];
    
  // Used for BFUN magnitudes reconstruction
  BasisFunctionRAM   astBasisFunctionRAM[NUM_OF_FILTERS];
    
  // All-pole model coefficients (a.k.a. predictor coefficients)
  float          pfAPModelCoef[MAX_AP_MODEL_ORDER];
  int            iAPModelInterpFactor;
  int            iAPModelInterpSize;

  //
  // Harmonic Arrays
  //
  HarmonicInfo*       pstHarmonicInfo;
  int             iNoOfHarmonics;
  int             iNoOfPitchHarmonics; // Number of voiced harmonics
    
  HarmonicInfo*       pstUvHarmonicInfo;
  int             iNoOfUvHarmonics;

  HarmonicInfo*  pstActiveHarmonicInfo;
  int            iActiveNoOfHarmonics;


  float           fPitchPeriod; // Adjusted for the actual sampling rate
  VOICING_CLASS   eVoicingClass;

  //
  // History information
  //

  float           fPrevPitchPeriod;   // Pitch of the previous frame
  float           fPrevPitchPhase;    // Linear phase value associated
                                        // with the first pitch harmonic
                                        // (at F0) of the previous frame
                                        // if it is voiced.
    
  // The last sample of the previous frame - used for
  // de-preemphasis performed in time domain
  float           pfPrevOutputSample;        	
 

} Reconstructor;




// ===================================================================
//             Function declarations
//             to be shared by different C-files
// ===================================================================


void AddPhase(
        float fCos1,
        float fSin1,
        float fCos2,
        float fSin2,
        float *pfCos,
        float *pfSin        
        );


void SamplePreEmpFilter(
                     Reconstructor *pstRec,
                     int           iNoOfHarmonics,
                     HarmonicInfo  *pstHarmonicInfo
                     );


void GetCosSinOfNormalizedArg(Reconstructor *pstRec,                                      
                              float         fNormArg,
                              float         *pfSin,
                              float         *pfCos);


void GetCosSin(Reconstructor *pstRec,  
               float         fArg,
               float         *pfSin,
               float         *pfCos);


void GetCosSinOfQuantizedArg(Reconstructor *pstRec,  
                             int           iIndex,
                             float         *pfSin,
                             float         *pfCos);


void realft(float *data, unsigned long n, int isign);



void GetRandomPhase(Reconstructor *pstRec,
                    float         *pfSinRandPhase,
                    float         *pfCosRandPhase);


void ReconstructDftFromHarmonics(
                 Cmplx           *pfDftResult,
                 HarmonicInfo    *pstHarmonic,
                 float           *pfWinTrans,
                 int             iNoOfHarmonics,
                 int             iDftLimit,
                 int             iWinFtBw,
                 float           *pfAdditionalWeights
                 );


void  ApplyMelFiltersBank(
		             Cmplx     *pstDft,
			     MelFilter *pstMel,
			     float     *pfBins
                     );


void CepstraToBinSpectrum(Reconstructor  *pstRec,
                          float          *pfCepstra);

void Fix16kHzCepstraAndEnergy(Reconstructor  *pstRec,
			      float          *pfCepstra);

void AddHighestCepstra(Reconstructor  *pstRec,
                       float          *pfCepstra);


void GetMissingMfccCentroid(Reconstructor *pstRec,                       
                            float         fPitchPeriod,
                            float         *pfMissCeps);


void BFUN_ReconstructMagnitudes(Reconstructor *pstRec,
                                int           iNoOfHarmonics,
                                HarmonicInfo  *pstHarmonicInfo,
                                BOOL          bVoiced);

void INTERP_ReconstructMagnitudes(Reconstructor *pstRec,
                                  float         fPitchPeriod,
                                  int           iNoOfHarmonics,
                                  HarmonicInfo  *pstHarmonicInfo,
                                  float         *pfCep);


void GenerateUvPhase(Reconstructor    *pstRec);

void GeneratePitchPhase(Reconstructor    *pstRec);


void GenerateAdditionalPhase(Reconstructor *pstRec);


void BuildAPModel(Reconstructor *pstRec);


void weight_spec_mag(Reconstructor *pstRec);


float APM_sample_phase(
               Reconstructor *pstRec,
               int           iHarmNo
               );

#endif 
