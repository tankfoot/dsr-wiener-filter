/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: main.c
 * PURPOSE:   This file contains the main program for speech reconstruction.
 *            The program reads:
 *            1) ETSI DSR Advanced Front-end features file (HTK or headerless);
 *            2) ETSI Extended DSR Front-end pitch file;
 *            3) ETSI Extended DSR Front-end voicing class file.
 *            The program outputs reconstructed speech signal as 16bit raw
 *            linear PCM.
 *
 *-------------------------------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "xdsr_reconst_api.h"


// ======================================================================
//
//                        TYPE DEFINITIONS
//
// ======================================================================

typedef int BOOL;
#ifndef TRUE
	#define TRUE	(BOOL)1
#endif
#ifndef FALSE
	#define FALSE	(BOOL)0 
#endif



typedef enum HtkSampleKind_t {
  ALL_FV =  0x2046, //All feature vector
  MFCC   =  0x0006,
  MFCC_E =  0x0046,
  MFCC_0 =  0x2006
} HtkSampleKind;



typedef struct HtkHeader_t {
  long            lNoOfSamples;              
  long            lSamplePeriod;
  short           sSampleSize;
  HtkSampleKind   enSampleKind;
} HtkHeader;


/* ---------------------------------------------
     Console arguments data structure
   --------------------------------------------- */
typedef struct  {

  // The Sampling Rate this file was originally encoded.
  int  iSamplingRateKhz;

  // Input file coantaning cepstra and LogEnergy
  FILE  *fpInputCepstra;     

  // Input file containing pitch values
  FILE  *fpInputPitch;     

  // Input file containing voicing class values
  FILE  *fpInputVoicing;

  // Output file for reconstructed speech
  FILE  *fpOutputPCM;       

  // Disable run time printouts
  BOOL   bSuppressPrintouts;
  
  // Input MFCC file has an HTK header 
  BOOL    bInputHtkHeader;    


} CONTROL_PARAMS;


// ===============================================================
//
//             STATIC FUNCTION PROTOTYPES
//
// ===============================================================

static void ParseCommandLine(int argc, char *argv[], CONTROL_PARAMS *pstCtrlParams);

static void CloseFiles(CONTROL_PARAMS *pstCtrlParams);

static void PrintUsage(char *progname);

static void PrintHeader(void);

static void ReadHTKHeader(FILE *HTK_File, HtkHeader *header);



// ===============================================================
//
//                     IMPLEMENTATION
//
// ===============================================================


void main( int iArgc , char *pcArgv[] )
{
    int              iReturnCode; 
    CONTROL_PARAMS   stCtrlParams;
    HtkHeader        stHtkHeader; 
    void*            pvReconstructor; 
    int              iPcmFrameSize;   
    int              iFeatureVectorLen; 
    short*           psPcmFrame = NULL; 
    int              iFrameCount;       
    float            afCepstraLogE[14]; 
                                        
                                     
    float            fPitch;            
    unsigned char    cVoicingClass = '3';   
 
    ParseCommandLine(iArgc,pcArgv,&stCtrlParams);

    // Read input features file HTK header
    if (TRUE==stCtrlParams.bInputHtkHeader) {
        ReadHTKHeader(stCtrlParams.fpInputCepstra, &stHtkHeader);
   
        if (ALL_FV !=(short)stHtkHeader.enSampleKind) {
            printf("\n Error: wrong feature vectors file\n");
	    exit(1);
        }    

        iFeatureVectorLen = stHtkHeader.sSampleSize / sizeof(float);
        if (iFeatureVectorLen != 14) {
	  printf("\n Error: wrong feature vectors dimension\n");
	  exit(1);
        }                                  
    } 
    else {
        // Raw (headerless) input MFCC file

        iFeatureVectorLen = 14;
                    
    }

    
    iReturnCode = XDSR_InitReconstructor(&pvReconstructor, 	                       
					 stCtrlParams.iSamplingRateKhz, 
					 &iPcmFrameSize); 
    if (iReturnCode != 0) {
        printf("Error: RC=%d - cannot initialize reconstruction\n",
               iReturnCode);
        exit(1);
    }
    


    // Allocate memory for reconstructed frame
    psPcmFrame = (short*)malloc(sizeof(short)*iPcmFrameSize);
    if (NULL == psPcmFrame) {
        printf(" Error: cannot allocate memory for output PCM frame\n");
        exit(1);
    }
  

    
  
    //
    //    Reconstruction Loop
    //
    for (iFrameCount=1; ;iFrameCount++) {


	    // Read input cepstra vector
	    if (iFeatureVectorLen!=
		    (signed)fread((void *)afCepstraLogE,
		                  sizeof(float),
				  iFeatureVectorLen,
				  stCtrlParams.fpInputCepstra)) break;
	  

	    // Read input pitch period value
  	    if (1!=fread(&fPitch,
			 sizeof(float),
			 1,
			 stCtrlParams.fpInputPitch)) {
	      printf("Error: missing pitch value for frame #%d\n",iFrameCount);
	      exit(1);
	    }

 	    // Read input voicing class
            if (1 != fscanf(stCtrlParams.fpInputVoicing,"%c",&cVoicingClass)) {
	      printf("Error: missing voicing-class info for frame #%d\n",
		     iFrameCount);
	      exit(1);
            }  	   


	    // Reconstruct current frame
	    XDSR_ReconstructFrame(pvReconstructor, 
				  afCepstraLogE,  
				  fPitch, 
				  cVoicingClass,
				  psPcmFrame);
	    
        
        // Write reconstructed PCM frame to output file 
	    if(iPcmFrameSize != (int)fwrite(psPcmFrame, 
					    sizeof(short), 
					    iPcmFrameSize, 
					    stCtrlParams.fpOutputPCM)) {
	      printf("Error: cannot write frame #%d to the output file\n",
		     iFrameCount);	        
	      exit(1); 
	    }
     
	    // Print frame in process
	    if (stCtrlParams.bSuppressPrintouts == FALSE)  {
	      printf(" Processed %d frames\r",iFrameCount);
	    }
 
    } // end of the loop over all frames

    CloseFiles(&stCtrlParams);

    XDSR_ReleaseReconstructor(pvReconstructor);
    
    free(psPcmFrame);
 
    if (stCtrlParams.bSuppressPrintouts == FALSE)  {
      printf("\n Done.\n\n\n");
    }
    exit(0);
    
}



static void CloseFiles(CONTROL_PARAMS *pstCtrlParams)
{
    
    if (pstCtrlParams->fpOutputPCM != NULL) 
	    fclose(pstCtrlParams->fpOutputPCM);
    if (pstCtrlParams->fpInputCepstra != NULL) 
	    fclose(pstCtrlParams->fpInputCepstra);
    if (pstCtrlParams->fpInputPitch != NULL) 
	    fclose(pstCtrlParams->fpInputPitch);
    if (pstCtrlParams->fpInputVoicing != NULL) 
	    fclose(pstCtrlParams->fpInputVoicing);
}



static void ParseCommandLine(int iArgc,
			     char *pcArgv[],
			     CONTROL_PARAMS *pstCtrlParams)
{
 int iArgIndx;


 // If run without arguments, print usage help
 if (iArgc==1) {
   PrintHeader();    
   PrintUsage(pcArgv[0]);
   exit(1);   
 }
  
 // Set default arguments
 pstCtrlParams->fpOutputPCM        = NULL;
 pstCtrlParams->fpInputCepstra     = NULL;
 pstCtrlParams->fpInputPitch       = NULL;
 pstCtrlParams->fpInputVoicing     = NULL;
 pstCtrlParams->iSamplingRateKhz   = 8;
 pstCtrlParams->bSuppressPrintouts = FALSE; 
 pstCtrlParams->bInputHtkHeader    = TRUE;    



 
 // First, check for the presence of the "-np" flag
 for(iArgIndx = 1; iArgIndx < iArgc; iArgIndx++) {
    if (0==strcmp("-np", pcArgv[iArgIndx])) {
      pstCtrlParams->bSuppressPrintouts = TRUE;
      break;
    }
 }
  
 
 if (pstCtrlParams->bSuppressPrintouts == FALSE) {
    PrintHeader();
 }
  
 for(iArgIndx = 1; iArgIndx < iArgc; iArgIndx++) {
    
    //  
    // Output PCM file name
    //
    if (0==strcmp("-out",pcArgv[iArgIndx])) {
      if (iArgIndx == iArgc-1 ||
        (pstCtrlParams->fpOutputPCM = fopen(pcArgv[++iArgIndx], "wb")) == NULL) {
        printf(" Error: can't open output file\n");
        exit(1);
      }     
    } 
    	
    //
    // Input cepstra file name
    //
    else if (0==strcmp("-cep",pcArgv[iArgIndx])) {
      if (iArgIndx == iArgc-1 ||
        (pstCtrlParams->fpInputCepstra = fopen(pcArgv[++iArgIndx], "rb")) == NULL) {
        printf(" Error: can't open input cepstra file\n");
        exit(1);
      }      
    }
    
    //
    // Input pitch file name
    //
    else if (0==strcmp("-pit",pcArgv[iArgIndx])) {
      if (iArgIndx == iArgc-1 ||
        (pstCtrlParams->fpInputPitch = fopen(pcArgv[++iArgIndx], "rb")) == NULL) {
        printf(" Error: can't open input pitch file\n");
        exit(1);
      }      
    }

    //
    // Input voicing class file name
    //
    else if (0==strcmp("-vc",pcArgv[iArgIndx])) {
      if (iArgIndx == iArgc-1 ||
        (pstCtrlParams->fpInputVoicing = fopen(pcArgv[++iArgIndx], "r")) == NULL) {
        printf(" Error: can't open input voicing file\n");
        exit(1);
      }      
    }
                

    //
    // Sampling rate
    //
    else if (strcmp("-s16",pcArgv[iArgIndx]) == 0) 
      pstCtrlParams->iSamplingRateKhz = 16;
    else if (strcmp("-s8",pcArgv[iArgIndx]) == 0) 
      pstCtrlParams->iSamplingRateKhz = 8;
			    	
    
    //
    // Input MFCC file has no HTK header
    //
    else if (strcmp("-noh",pcArgv[iArgIndx]) == 0) 
      pstCtrlParams->bInputHtkHeader = FALSE;
            
    
    else {
        printf(" Error: unknown argument %s\n", pcArgv[iArgIndx]);
        exit(1);
    }
    

	
 }	// end of arguments read loop 

 
 //
 // Check if mandatory arguments were given
 //  
 if (NULL == pstCtrlParams->fpOutputPCM ||
     NULL == pstCtrlParams->fpInputCepstra ||
     NULL == pstCtrlParams->fpInputPitch  ||
     NULL == pstCtrlParams->fpInputVoicing ) {
		PrintUsage(pcArgv[0]);
		exit(1);   
 }


}




static void PrintHeader()
{
 printf("\n");
 printf("\n");
 printf(" ETSI ES 202 212 Extended DSR Advanced Front-end\n");
 printf(" Speech reconstruction program\n");
 printf(" Compiled at %s\n",__DATE__);
 printf("\n"); 
}

static void PrintUsage(char *progname)
{
 printf("\n");
 printf("\n");
 printf(" List of command line arguments. Can be specified in arbitrary order\n");
 printf("\n");
 printf(" -cep <input_cepstra_file_name> - input feature file (cepstra & log-energy)\n");
 printf("[-noh] - cepstra file is headerless, default: HTK header \n");
 printf(" -pit <input_pitch_file_name>   - input pitch file\n");
 printf("[-vc  <input_voicing_class_file_name>] - ascii voicing class file\n");
 printf(" -out <output_pcm_file_name> - synthesized PCM file\n");
 printf("[-s8|-s16] - sampling rate kHz, default: s8\n");
 printf("[-np] - suppress printouts\n");
 printf("\n\n"); 
 
}


static void ReadHTKHeader(FILE *HTK_File, HtkHeader *header)
{
  long l;
  int i;
  short s;

  /*This function reads the header into the struct*/

  if (sizeof(long) == 4)
  {
    fread(&l,4,1,HTK_File);
    header->lNoOfSamples = l;
    fread(&l,4,1,HTK_File);
    header->lSamplePeriod = l;
  }
  else
  {
    fread(&i,4,1,HTK_File);
    header->lNoOfSamples = i;
    fread(&i,4,1,HTK_File);
    header->lSamplePeriod = i;
  }

  if (sizeof(int) == 2)
  {
    fread(&i,2,1,HTK_File);
    header->sSampleSize = i;
    fread(&i,2,1,HTK_File);
    header->enSampleKind = i;
  }
  else
  { 
    fread(&s,2,1,HTK_File);
    header->sSampleSize = s;
    fread(&s,2,1,HTK_File);
    header->enSampleKind = s;
  }

  if(feof(HTK_File)!=0 || ferror(HTK_File)!=0)
  {
    /*Should never find EOF here since you would be expecting the data in the MultiFrame too.*/
    printf("Error or end of file occured while reading Header.\n");
    exit(1);
  }

  return;
}
