/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: APmodel.c
 * PURPOSE:   All-pole modeling
 *
 *-------------------------------------------------------------------------------*/


#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"



/* ============================================================================

                                   INTERNAL FUNCTIONS

   =========================================================================== */


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  acf_to_pc
 *
 * PURPOSE:   transform Auto Correlation Function values to
 *            Predictor Coefficients
 * INPUT:
 *   pfAcf  - Array containing the Auto Correlation Function values
 *   iOrder - Order of the predictor  
 *
 * OUTPUT:
 *   pfPredCoef - Array of Predictor Coefficients
 * RETURN VALUE:
 *   prediction error
 *---------------------------------------------------------------------------*/
static float acf_to_pc(float *pfAcf, int iOrder, float *pfPredCoef)
{
  
  int i, j;

  float pfOldPredCoef[MAX_AP_MODEL_ORDER];

  float fError;
  float fReflCoef;
  float fTemp;
  

  /*
   * If the ACF value at zero lag, i.e., energy, is zero,
   * return with zero PC values
   */

  if (pfAcf[0] <= 0.0)
  {
    for (j = 0; j < iOrder; j++)
    {
      pfPredCoef[j] = 0.0;
    }
    fError = pfAcf[0];
    return(fError);
  }


  /*
   * Otherwise, perform L-D recursion
   */

  fError = pfAcf[0];

  for (j = 0; j < iOrder; j++)
  {

    fTemp = pfAcf[j+1];

    for (i = 0; i < j; i++)
    {
      fTemp += (pfOldPredCoef[i] * pfAcf[j-i]);
    }

    fReflCoef = -(fTemp / fError);

    pfPredCoef[j] = fReflCoef;

    for (i = 0; i < j; i++)
    {
      pfPredCoef[i] = pfOldPredCoef[i] + fReflCoef * pfOldPredCoef[j-i-1];
    }

    fError *= (1 - fReflCoef*fReflCoef);

    for (i = 0; i <= j; i++)
    {
      pfOldPredCoef[i] = pfPredCoef[i];
    }

  }


  return(fError);

}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  APM_gen_harm_freq
 *
 * PURPOSE:   Compute the harmonic frequencies for modeling purposes
 *            given the number of harmonics
 * INPUT:
 *   iNHar - Number of harmonics
 *
 * OUTPUT:
 *   pfHarmFreq[0:MAX_NUM_PITCH_HARM-1] - Array of harmonic frequencies
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void APM_gen_harm_freq(int iNHar, float *pfHarmFreq)
{
  
  int i;

  float fFreq;
  float fRunSumFreq;


  fFreq = 1.0f / (float) (iNHar+1);

  fRunSumFreq = 0.0;

  for(i = 0; i < iNHar; i++)
  {

    fRunSumFreq += fFreq;

    pfHarmFreq[i] = fRunSumFreq;

  }

}





/*----------------------------------------------------------------------------
 * FUNCTION NAME:  iit
 *
 * PURPOSE:    Model harmonic magnitudes by predictor coefficients
 *          
 * INPUT:
 *   pfMag[0:MAX_NUM_PITCH_HARM-1] - Array of harmonic magnitudes
 *   iNHar - Number of harmonics
 *   iNumIter - Number of iterations (to be performed in the
 *              modeling process)
 *   iOrder - Order of the predictor
 *
 * OUTPUT:
 *   pfPredCoef[0:iOrder-1] - Array of predictor coefficients  
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void iit(float *pfMag, int iNHar, int iNumIter, int iOrder,
         float *pfPredCoef, int *piInterpFactor, int *piInterpSize) 
{

  int i,j,k;
  int ii;
  int iInterpFactor;
  int iInterpSize;
  int iIter;
  int iMaxIter;

  float pfAcf[MAX_AP_MODEL_ORDER+1];
  float	pfEstMag[MAX_NUM_PITCH_HARM];
  float pfFreqArray[MAX_NUM_PITCH_HARM];
  float	pfInterpMag[MAX_NUM_PITCH_HARM];
  float	pfNormMag[MAX_NUM_PITCH_HARM];
  float	pfScale[MAX_NUM_PITCH_HARM];

  float fDCMag;
  float fError;
  float fEvenMag;
  float	fFreq;
  float fImag;
  float fInvNorm;
  float	fNorm;
  float fOddMag;
  float fPIMag;
  float fRatio;
  float	fReal;
  float fScale;


  

  /*
   * Normalize the harmonic magnitudes so that the
   * maximum value is 1.0
   */

  fNorm = 0.0;

  for(i = 0; i < iNHar; i++)
  {
    if(pfMag[i] > fNorm)
    {
      fNorm = pfMag[i];
    }
  }

  if(fNorm <= 0.0)
  {
    for(j = 0; j < MAX_AP_MODEL_ORDER; j++)
    {
       pfPredCoef[j] = 0.0;
    }

    return;
  }

  fInvNorm = 1.0f / fNorm;

  for(i = 0; i < iNHar; i++) 
  {
    pfNormMag[i] = pfMag[i] * fInvNorm;
  }


  /*
   * Build an interpolated vector
   */

  /*
   * First, determine the interpolation factor and
   * the interpolation size
   */

  if (iNHar < 12)
    {
      iInterpFactor = 4;
    }
    else if (iNHar < 16)
    {
      iInterpFactor = 3;
    }
    else if (iNHar < 25)
    {
      iInterpFactor = 2;
    }
    else
    {
      iInterpFactor = 1;
    }

    iInterpSize = iInterpFactor * (iNHar-1)  + 1;
    *piInterpFactor = iInterpFactor;
    *piInterpSize = iInterpSize;

  

  /*
   * Fill in the original and interpolated values
   */

  if (iInterpFactor == 1)
  {

    for (i = 0; i < iNHar; i++)
    {
      pfInterpMag[i] = pfNormMag[i];
    }

    iMaxIter = 0;

  }

  else
  {

    for (i = 0; i < iNHar-1; i++)
    {
      ii = i * iInterpFactor;

      for (k = 0; k < iInterpFactor; k++)
      {
        fRatio = (float)k / (float)iInterpFactor;
        pfInterpMag[ii+k] = pfNormMag[i] * (1.0f-fRatio) +
                            pfNormMag[i+1] * fRatio;
      }
    }

    pfInterpMag[iInterpSize-1] = pfNormMag[iNHar-1];

    iMaxIter = iNumIter;

  }


  /*
   * Generate the frequencies corresponding to the
   * interpolated values
   */

  APM_gen_harm_freq(iInterpSize,pfFreqArray);


  /*
   * Transform the interpolated vector into a pseudo-
   * autocorrelation sequence
   */
  
  /*
   * First, estimate the DC and PI magnitudes to be used
   */

  if (iInterpFactor == 1)
  {

    if (pfInterpMag[1] > 1.2 * pfInterpMag[0])
    {
      fDCMag = 0.8f * pfInterpMag[0];
    }
    else if (pfInterpMag[1] < 0.8 * pfInterpMag[0])
    {
      fDCMag = 1.2f * pfInterpMag[0];
    }
    else
    {
      fDCMag = pfInterpMag[0];
    }

    fPIMag = pfInterpMag[iNHar-1];

  }

  else
  {

    fDCMag = 2.0f * pfInterpMag[0] - pfInterpMag[1];

    fPIMag = 2.0f * pfInterpMag[iInterpSize-1] - 
                   pfInterpMag[iInterpSize-2];

  }


  /*
   * Compute the pseudo-autocorrelation function
   */

  for (j = 0; j <= iOrder; j++)
  {
    pfAcf[j] = 0.0;
  }

  for (i = 0; i < iInterpSize; i++)
  {

    fFreq = pfFreqArray[i] * M_PI;

    for (j = 0; j <= iOrder; j++)
    {
        pfAcf[j] += pfInterpMag[i] * (float)cos((float)j*fFreq);
    }

  }

  fEvenMag = (fDCMag + fPIMag) * 0.5f;

  fOddMag = (fDCMag - fPIMag) * 0.5f;

  for (j = 0; j <= iOrder; j++)
  {
    if ((j%2) == 0)
    {
      pfAcf[j] += fEvenMag;
    }
    else
    {
      pfAcf[j] += fOddMag;
    }
  }


  /*
   * Use the (iOrder+1) values of the pseudo-autocorrelation
   * function to model the spectral envelope through predictor
   * coefficients
   */

  fError = acf_to_pc(pfAcf,iOrder,pfPredCoef);


  /*
   * Perform the iterations
   */

  for(iIter = 0; iIter < iMaxIter; iIter++)
  {

    /*
     * Sample the model envelope at all the interpolated
     * frequencies as well as DC and PI
     */

    for(i = 0; i < iInterpSize; i++)
    {

      fFreq = pfFreqArray[i] * M_PI;

      fReal = 1.0;
      fImag = 0.0;

      for(j = 0; j < iOrder; j++)
      {
        fReal += pfPredCoef[j] * (float)cos((float)(j+1)*fFreq);
        fImag -= pfPredCoef[j] * (float)sin((float)(j+1)*fFreq);
      }

      pfInterpMag[i] = 1.0f/(fReal*fReal+fImag*fImag);

    }


    fReal = 1.0f;

    for(j = 0; j < iOrder; j++)
    {
        fReal += pfPredCoef[j];
    }

    fDCMag = 1.0f/(fReal*fReal);


    fReal = 1.0;

    for(j = 0; j < iOrder; j++)
    {
      if((j % 2) == 0)
      {
        fReal -= pfPredCoef[j];
      }
      else
      {
        fReal += pfPredCoef[j];
      }
    }

    fPIMag = 1.0f/(fReal*fReal);


    /*
     * Estimate the original harmonic magnitudes
     */

    for(i = 0; i < iNHar; i++)
    {
      pfEstMag[i] = pfInterpMag[i*iInterpFactor];
    }


    /*
     * Normalize all the envelope magnitudes so that the
     * maximum estimated magnitude is 1.0
     */

    fNorm = 0.0;

    for(i = 0; i < iNHar; i++)
    {
      if(pfEstMag[i] > fNorm)
      {
        fNorm = pfEstMag[i];
      }
    }

    fInvNorm = 1.0f / fNorm;

    for(i = 0; i < iNHar; i++) 
    {
      pfEstMag[i] *= fInvNorm;
    }

    for(i = 0; i < iInterpSize; i++)
    {
      pfInterpMag[i] *= fInvNorm;
    }

    fDCMag *= fInvNorm;

    fPIMag *= fInvNorm;


    /*
     * Scale the sampled envelope vector so that the estimated
     * harmonic magnitudes match the real harmonic magnitudes
     */

    for(i = 0; i < iNHar; i++)
    {
      if(pfEstMag[i] <= 0.0)
      {
        pfScale[i] = 1.0;
      }
      else
      {
        pfScale[i] = pfNormMag[i] / pfEstMag[i];
      }
    }

    for (i = 0; i < iNHar-1; i++)
    {

      ii = i * iInterpFactor;

      for (k = 0; k < iInterpFactor; k++)
      {

        fRatio = (float)k / (float)iInterpFactor;

        fScale = pfScale[i] * (1.0f-fRatio) + pfScale[i+1] * fRatio;

        pfInterpMag[ii+k] *= fScale;

      }

    }

    pfInterpMag[iInterpSize-1] = pfNormMag[iNHar-1];


    /*
     * Transform the new interpolated vector into a pseudo-
     * autocorrelation sequence
     */
  
    for (j = 0; j <= iOrder; j++)
    {
      pfAcf[j] = 0.0;
    }

    for (i = 0; i < iInterpSize; i++)
    {

      fFreq = pfFreqArray[i] * M_PI;

      for (j = 0; j <= iOrder; j++)
      {
        pfAcf[j] += (pfInterpMag[i] * (float)cos((float)j*fFreq));
      }

    }
 
    fEvenMag = (fDCMag + fPIMag) * 0.5f;

    fOddMag = (fDCMag - fPIMag) * 0.5f;

    for (j = 0; j <= iOrder; j++)
    {
      if ((j%2) == 0)
      {
        pfAcf[j] += fEvenMag;
      }
      else
      {
        pfAcf[j] += fOddMag;
      }
    }


    /*
     * Use the (iOrder+1) values of the pseudo-autocorrelation
     * function to model the spectral envelope through predictor
     * coefficients
     */

    fError = acf_to_pc(pfAcf,iOrder,pfPredCoef);

  }

  for (i = iOrder; i < MAX_AP_MODEL_ORDER; i++)
    {
      pfPredCoef[i] = 0.0;
    }

  return;

}


/* ============================================================================

                                   INTERNAL FUNCTIONS

   =========================================================================== */


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  APM_sample_phase
 *
 * PURPOSE:   Compute and return the all pole model inverse phase (divided by pi)
 *            for the harmonic given by its index iHarmNo, iHarmNo = 0 corresponds
 *            to the fundamental frequency
 * INPUT:
 *   pstRec - pointer to the Reconstructor
 *   iHarmNo - the harmonic index
 *
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   phase value
 *---------------------------------------------------------------------------*/
float APM_sample_phase(
               Reconstructor *pstRec,
               int           iHarmNo
               )
{
    float fReal, fImag, fPhase;
    float fFreq, fRunSumFreq;
    int j;
    float *pfPredCoef = pstRec->pfAPModelCoef; 
    int iOrder = pstRec->iAPModelOrder;              
    int iInterpFactor = pstRec->iAPModelInterpFactor;
    int iInterpSize = pstRec->iAPModelInterpSize;

     
    fFreq = 1.0f / (float) (iInterpSize+1);    
    fFreq *= (float)(iHarmNo*iInterpFactor+1)*M_PI;


    fReal = 1.0;
    fImag = 0.0;    
    fRunSumFreq = 0.0f;
    for (j = 0; j < iOrder; j++) {
        fRunSumFreq += fFreq;
        fReal += pfPredCoef[j] * (float)cos(fRunSumFreq);
        fImag -= pfPredCoef[j] * (float)sin(fRunSumFreq);
    }
    

    fPhase = (float)atan2(fImag,fReal) / M_PI;

    return fPhase;
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  BuildAPModel
 *
 * PURPOSE:   Compute All-Pole model coefficients
 * INPUT/OUTPUT:
 *   pstRec - pointer to the Reconstructor
 *
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void BuildAPModel(Reconstructor *pstRec)
{
    float pfMag[MAX_NUM_PITCH_HARM];
    float *pfPredCoef;
    int i, iNHar, iNumIter;
    HarmonicInfo *pstHarmonic = pstRec->pstHarmonicInfo;

    if (UV_PITCH == pstRec->fPitchPeriod) return;

    iNHar = pstRec->iNoOfPitchHarmonics;
    pfPredCoef = pstRec->pfAPModelCoef;

        

    /*
     * Get the harmonic magnitudes
     */

    for (i = 0; i < iNHar; i++)
    {
      pfMag[i] = pstHarmonic[i].fAmp; 
    }


    /*
     * Compute the predictor coefficients from the harmonic
     * magnitudes
     */

    iNumIter = 1;
    iit(pfMag,iNHar,iNumIter,pstRec->iAPModelOrder,pfPredCoef,
        &pstRec->iAPModelInterpFactor,&pstRec->iAPModelInterpSize);

}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  weight_spec_mag
 *
 * PURPOSE:    Weight the spectral magnitudes by AP model derived postfilter
 *             similar to an adaptive postfilter in CELP coders
 * INPUT/OUTPUT:
 *   pstRec - pointer to the Reconstructor
 *
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void weight_spec_mag(Reconstructor *pstRec)

{



  int i,j;
  int iNHar;
  int iOrder;

  float pfDrCoef[MAX_AP_MODEL_ORDER];
  float pfNrCoef[MAX_AP_MODEL_ORDER];
  float pfWtArray[MAX_NUM_PITCH_HARM];

  float *pfPredCoef;

  float fDrFactor;
  float fNrFactor;

  float fImag1;
  float fImag2;
  float fImag3;

  float fReal1;
  float fReal2;
  float fReal3;

  float fEnrg;
  float fFreq;

  float fGain;
  float fRunSumFreq;
  float fScale;
  float fSum;
  float fSumSq;

  HarmonicInfo *pstHarmonic;

  int iInterpFactor;
  int iInterpSize;




  /*
   * Get the necessary information from the Reconstructor structure
   */


  pstHarmonic = pstRec->pstHarmonicInfo;
  pfPredCoef = pstRec->pfAPModelCoef;
  iNHar = pstRec->iNoOfPitchHarmonics;
  iInterpFactor = pstRec->iAPModelInterpFactor;
  iInterpSize = pstRec->iAPModelInterpSize; 


    iOrder = pstRec->iAPModelOrder;
        

    /*
     * Compute the numerator and denominator coefficients of the
     * weighting filter from the predictor coefficients
     */

    fDrFactor = 1.0;
    fNrFactor = 1.0;

    for (j = 0; j < iOrder; j++)
    {
      fDrFactor *= PF_ALPHA;
      pfDrCoef[j] = pfPredCoef[j] * fDrFactor;
      fNrFactor *= PF_BETA;
      pfNrCoef[j] = pfPredCoef[j] * fNrFactor;
    }


    /*
     * Compute the weights from the filter coefficients
     */

    for(i = 0; i < iNHar; i++)
    {

      fReal1 = 1.0;
      fImag1 = 0.0;

      fReal2 = 1.0;
      fImag2 = 0.0;

      fReal3 = 1.0;
      fImag3 = 0.0;

      fFreq = (float)(i*iInterpFactor+1)*M_PI/(float)(iInterpSize+1);

      fRunSumFreq = 0.0;

      for (j = 0; j < iOrder; j++)
      {

        fRunSumFreq += fFreq;

        fReal1 += (pfDrCoef[j] * (float)cos(fRunSumFreq));
        fImag1 -= (pfDrCoef[j] * (float)sin(fRunSumFreq));

        fReal2 += (pfNrCoef[j] * (float)cos(fRunSumFreq));
        fImag2 -= (pfNrCoef[j] * (float)sin(fRunSumFreq));

      }

      fReal3 -= (PF_MU * (float)cos(fFreq));
      fImag3 += (PF_MU * (float)sin(fFreq));

      pfWtArray[i] = (fReal2*fReal2+fImag2*fImag2);
      pfWtArray[i] /= (fReal1*fReal1+fImag1*fImag1);
      pfWtArray[i] *= (float)sqrt(fReal3*fReal3+fImag3*fImag3);

    }


    /*
     * Normalize and limit the weights
     */

    fSum = 0.0;
    for (i = 0; i < iNHar; i++)
    {
      fSum += (float)pow(pfWtArray[i],4.0);
    }

    fScale = 1.0f / (float)pow((fSum/(float)iNHar),0.25);

    for (i = 0; i < iNHar; i++)
    {
      pfWtArray[i] *= fScale;

      if (pfWtArray[i] > MAX_WT)
      {
        pfWtArray[i] = MAX_WT;
      }
      if (pfWtArray[i] < MIN_WT)
      {
        pfWtArray[i] = MIN_WT;
      }
    }


    /*
     * Apply the weights to the spectral magnitudes
     * making sure that the energy remains the same
     */

    fEnrg = 0.0;
    fSumSq = 0.0;

    for (i = 0; i < iNHar; i++)
    {
      fEnrg += (pstHarmonic[i].fAmp * pstHarmonic[i].fAmp);
      fFreq = (float)(i*iInterpFactor+1)*M_PI/(float)(iInterpSize+1);

      if (fFreq >= 0.05*M_PI)      
      {
        pstHarmonic[i].fAmp *= pfWtArray[i];
      }
      fSumSq += (pstHarmonic[i].fAmp * pstHarmonic[i].fAmp);      
    }

    if (fSumSq > 0.0)
    {
      fGain = (float)sqrt(fEnrg/fSumSq);
    }
    else
    {
      fGain = 1.0;
    }

    for (i = 0; i < iNHar; i++)
    {
      pstHarmonic[i].fAmp *= fGain;                 
    }
  

  return;

}

