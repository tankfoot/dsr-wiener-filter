/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: bfun_mag.c
 * PURPOSE:   BFUN magnitudes reconstruction method implementation
 *
 *-------------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <math.h>


#include "common.h"



/* =====================================================================

                     INTERNAL FUNCTIONS

   ===================================================================== */


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  SqrtBins
 *
 * PURPOSE:   Given power binned spectrum approximate amplitude binned spectrum
 * INPUT/OUTPUT: 
 *   pstRec   - pointer to the Reconstructor
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void SqrtBins(Reconstructor *pstRec)
{
    int i, j;
    float fS;

    for (i=0; i<NUM_OF_FILTERS; i++) {
        fS = 0.f;
        for (j=0; j<pstRec->astMelFilter[i].iLength; j++)
            fS += pstRec->astMelFilter[i].pfData[j];
        pstRec->afBinSpec[i] = (float)sqrt(fS*pstRec->afBinSpec[i]);
        pstRec->afBinSpecSave[i] = (float)sqrt(fS*pstRec->afBinSpecSave[i]);
    }
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  SampleBasisFunction
 *
 * PURPOSE:   Samples the basis functions at te harmonic frequencies
 * INPUT/OUTPUT: 
 *   pstRec   - pointer to the Reconstructor
 * INPUT:
 *   iNoOfHarmonics - number of harmonics
 *   pstHarmonicInfo - array of the harmonics
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void SampleBasisFunction(Reconstructor *pstRec,
                                int           iNoOfHarmonics,
                                HarmonicInfo  *pstHarmonicInfo)
{

    int i, iBfNo;
    int iDftFrq;
    int iHarmonicCount;
    BasisFunctionROM  *pstBfRom = pstRec->astBasisFunctionROM;
    BasisFunctionRAM  *pstBfRam = pstRec->astBasisFunctionRAM;


 
    //
    // Loop on all Basis Functions
    //
    for (iBfNo=0; iBfNo < NUM_OF_FILTERS; iBfNo++,pstBfRom++,pstBfRam++) {

        pstBfRam->iFirstHarmonic  = -1; // No harmonic is this basis function
	    iHarmonicCount = 0;

	    // Loop on all harmoics 
	    for(i=0; i<iNoOfHarmonics; i++) {	
		    // Extract DFT point nearset the harmonic
		    iDftFrq = pstHarmonicInfo[i].iDftFreq;
            if (iDftFrq > pstBfRom->iEndingPoint) break;
		    // Check if Harmoic is in current basis function
		    if (iDftFrq >= pstBfRom->iStartingPoint) {
                if (-1 == pstBfRam->iFirstHarmonic) 
				    pstBfRam->iFirstHarmonic = i;
                pstBfRam->pfSampledFunc[iHarmonicCount] = 
				    pstBfRom->pfData[iDftFrq-pstBfRom->iStartingPoint];
			    iHarmonicCount++;
            }	    
        }

        pstBfRam->iTotalHarmonics = iHarmonicCount;
        pstBfRam->iLastHarmonic = pstBfRam->iFirstHarmonic+iHarmonicCount-1;
    
    } // end of loop over all basis function
 
}





/*----------------------------------------------------------------------------
 * FUNCTION NAME:  CalcBasisFunctionBins
 *
 * PURPOSE:   Calulate binned spectrum of each sampled basis function
 * INPUT/OUTPUT: 
 *   pstRec   - pointer to the Reconstructor
 * INPUT:
 *   pstHarmonicInfo - array of the harmonics
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void CalcBasisFunctionBins(Reconstructor   *pstRec,
                                 HarmonicInfo    *pstHarmonicInfo)
{
    BasisFunctionRAM  *pstBfRam = pstRec->astBasisFunctionRAM;
    int i;
                                  

    // Loop over all basis functions
    for (i=0; i<NUM_OF_FILTERS; i++, pstBfRam++) {
  
      // Reset bin values of current basis function
      memset(pstBfRam->pfBins,0,sizeof(float)*NUM_OF_FILTERS);

      // If no harmonics inside the basis function then all bins are zero
      // -- skip to next basis function 
      if (-1 == pstBfRam->iFirstHarmonic) continue;
        

      //
      // Calculate spectrum by convolution with Hamming window Fourier Transform
      // pstRec->pfReconDft is a Complex array of size iFftLimit
      //

      ReconstructDftFromHarmonics(
				  pstRec->pfReconDft,
				  &(pstHarmonicInfo[pstBfRam->iFirstHarmonic]),
				  pstRec->pfAnaWinTranSamples,
				  pstBfRam->iTotalHarmonics,
				  pstRec->iFftLimit,
				  pstRec->iWinFtBw,
				  pstBfRam->pfSampledFunc);

      //
      // Calculate the binned spectrum of this DFT, as done in the front end
      //        
      ApplyMelFiltersBank(pstRec->pfReconDft,
			  pstRec->astMelFilter,
			  pstBfRam->pfBins);                          

    
    }  // end of loop over basis functions


} 



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  LU_Decomposition
 *
 * PURPOSE:   L-U decomposition of a matrix
 * INPUT/OUTPUT: 
 *   A - the matrix
 * INPUT:
 *   N - the matrix order
 * OUTPUT:
 *   Indx - vector containing the rows permuatation indeces
 *   WrkBuf - work space allocated for N elements
 * RETURN VALUE:
 *   1 - OK
 *   0 the matrix is singular
 *---------------------------------------------------------------------------*/
static int LU_Decomposition(
            float  **A,
            int    N,
            int    *Indx,
            float  *WrkBuf
            )
{
    float fmax, sum, dum;
    int i, j, k, imax=0;

    for (i=0; i<N; i++) {
        fmax = 0.f;
        for (j=0; j<N; j++) {
            if (fabs(A[i][j]) > fmax)
                fmax = (float)fabs(A[i][j]);
        }
        if (0 == fmax) return 0;
        WrkBuf[i] = 1.f/fmax;
    }

    // Loop over all the columns
    for (j=0; j<N; j++) {

        for (i=0; i<j; i++) {
            sum = A[i][j];
            for (k=0; k<i; k++)
                sum -= A[i][k]*A[k][j];
            A[i][j] = sum;
        }

        fmax=0.f;
        for (i=j; i<N; i++) {
            sum = A[i][j];
            for (k=0; k<j; k++)
                sum -= A[i][k]*A[k][j];
            A[i][j] = sum;
            dum = WrkBuf[i]*(float)fabs(sum);
            if (dum >= fmax) {
                imax = i;
                fmax = dum;
            }
        }

        if (j != imax) {
            for (k=0; k<N; k++) {
                dum = A[imax][k];
                A[imax][k] = A[j][k];
                A[j][k] = dum;
            }
            WrkBuf[imax] = WrkBuf[j];
        }

        Indx[j] = imax;

        if (0 == A[j][j])
            A[j][j] = 1e-20f;

        if (j != N-1) {
            dum = 1.f/A[j][j];
            for (i=j+1; i<N; i++)
                A[i][j] *= dum;
        }
    } // end of loop over the columns

    return 1;
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  LU_Solve
 *
 * PURPOSE:   Solve matrix equation where the matrix is stored in L/U form
 *
 * INPUT: 
 *   A - the matrix (after call to LU_Decomposition())
 *   N - the matrix order
 *   Indx - vector containing the rows permuatation indeces
 * INPUT/OUTPUT:
 *   B - at input: right side vector; at output: the solution
 * RETURN VALUE:
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void LU_Solve(
        float  **A,
        int    N,
        int    *Indx,
        float  *B
        )
{
    int ii, i, j, LL;
    float sum;

    ii=-1;
    for (i=0; i<N; i++) {
        LL = Indx[i];
        sum = B[LL];
        B[LL] = B[i];
        if (ii != -1) {
            for (j=ii; j<i; j++)
                sum -= A[i][j]*B[j];
        }
        else if (sum != 0)
            ii = i;
        B[i] = sum;
    }

    for (i=N-1; i >= 0; i--) {
        sum = B[i];
        if (i < N-1) {
            for (j=i+1; j<N; j++)
                sum -= A[i][j]*B[j];
        }
        B[i] = sum/A[i][i];
    }

}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  ScalarProduct
 *
 * PURPOSE:   Compute scallar product of two vectors
 *
 * INPUT: 
 *   pfV1, pfV2 - the vectors
 *   iN - the vectors dimension
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   scalar product
 *  
 *---------------------------------------------------------------------------*/
static float ScalarProduct(float *pfV1, float *pfV2, int iN)
{
    float fS=0.f;
    int i;
    for (i=0; i<iN; i++)
        fS += pfV1[i]*pfV2[i];
    return fS;
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  PositiveSolve
 *
 * PURPOSE:  Computes the positive coefficients (weights) of the basis       
 *           functions such that the resulting bins (binned spectrum)
 *           calculated on the reconstructed DFT are close to the original
 *           (decoded) bins   
 * INPUT: 
 *   pstRec - pointer to the Reconstructor
 *   pfTargetBins - original 24 bins
 *   pstBF - array of 24 BasisFunctionRAM structures cntaining the basis
 *           functions bins
 * OUTPUT:
 *   pfResult - vector of the optimal weights
 * RETURN VALUE:
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void PositiveSolve(
                          Reconstructor    *pstRec,
                          float            *pfTargetBins,
                          BasisFunctionRAM *pstBF,
			  float            *pfResult
                          )
{    
    int i, j;
    float fAlpha;
    float **aafMat = pstRec->aafBfunMatrix;
    int   *piLUIndex = pstRec->aiLUPermIndex;

    /* ----------------------------------------------------
             Compute the normal equation Matrix
      ---------------------------------------------------- */
    /* The upper triangle */
    for (i=0; i<NUM_OF_FILTERS; i++) {
        for (j=i; j<NUM_OF_FILTERS; j++) {
            aafMat[i][j] = ScalarProduct(pstBF[i].pfBins,pstBF[j].pfBins,NUM_OF_FILTERS);
        }
    }
    /* The lower triangle */
    for (i=1; i<NUM_OF_FILTERS; i++) {
        for (j=0; j<i; j++) {
            aafMat[i][j] = aafMat[j][i];
        }
    }
    /* Regularization */
    fAlpha = 0.f;
    for (i=0; i<NUM_OF_FILTERS; i++)
        fAlpha += aafMat[i][i];
    fAlpha /= (float)NUM_OF_FILTERS;
    fAlpha *= 0.001f;
    for (i=0; i<NUM_OF_FILTERS; i++)
        aafMat[i][i] += fAlpha;

    /*  Use pfResult as work buffer for LU-decomposition routine */
    LU_Decomposition(aafMat,NUM_OF_FILTERS,piLUIndex,pfResult);

    /*  Compute right-side vector into pfResult */
    for (i=0; i<NUM_OF_FILTERS; i++)
        pfResult[i] = ScalarProduct(pstBF[i].pfBins,pfTargetBins,NUM_OF_FILTERS);

    LU_Solve(aafMat,NUM_OF_FILTERS,piLUIndex,pfResult);
              
    for (i=0; i<NUM_OF_FILTERS; i++)
        if (pfResult[i] < 0) pfResult[i] = 0.f;
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  CalcHarmonicAmplitudes
 *
 * PURPOSE:  Compute harmonic magnitudes as linear combination 
 *           of basis functions
 * INPUT: 
 *   pfCoeffs - vector of the optimal weights
 *   pstBF - array of 24 BasisFunctionRAM structures containing sampled  basis
 *           functions
 *   iNoOfHarmonic - the number of harmonics 
 * OUTPUT:
 *   pstHarmonic - array of the harmonic, their amplitudes are computed by
 *                 the function
 * RETURN VALUE:
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void CalcHarmonicAmplitudes(float             *pfCoeffs,
                                   HarmonicInfo      *pstHarmonic,
                                   BasisFunctionRAM  *pstBF,
                                   int               iNoOfHarmonics
                                   )                              
{
    int i, j;
    int iFirstHarmonic, iLastHarmonic;
 
 
    // Reset all harmonic amplitudes
    for (i=0; i < iNoOfHarmonics; i++)
        pstHarmonic[i].fAmp = 0.0f;


    // A loop over the basis function

    for (i=0; i < NUM_OF_FILTERS; i++) {

        iFirstHarmonic = pstBF[i].iFirstHarmonic;
        iLastHarmonic  = pstBF[i].iLastHarmonic;
    
        for (j = iFirstHarmonic; j <= iLastHarmonic; j++)
            pstHarmonic[j].fAmp += 
		        pfCoeffs[i] * pstBF[i].pfSampledFunc[j-iFirstHarmonic];      
    } 


}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  BfunRepresentation_To_Bins
 *
 * PURPOSE:  Compute binned spectrum as linear combination of the basis function's
 *           bins. Put the result to pstRec-> afBinSpec
 * INPUT/OUTPUT: 
 *   pstRec pointer to the Reconstructor
 *
 * RETURN VALUE:
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void BfunRepresentation_To_Bins(Reconstructor *pstRec)
{
    float *pfCoeffs = pstRec->afBasisFuncCoefs, fCoeff;
    BasisFunctionRAM *pstBF = pstRec->astBasisFunctionRAM;
    float *pfBins = pstRec->afBinSpec;
    float *pfBfunBins;
    int i,j;
    float fAlpha;

    memset(pfBins,0,NUM_OF_FILTERS*sizeof(float));

    // Loop on basis functions
    for (i=0; i < NUM_OF_FILTERS; i++) {
        pfBfunBins = pstBF[i].pfBins;
        fCoeff = pfCoeffs[i];
        // Loop on bins
        for (j=0; j<NUM_OF_FILTERS; j++)
            pfBins[j] += fCoeff*pfBfunBins[j];
    }

    // Regularizations - needed to prevent empty bins
    for (i=0; i<NUM_OF_FILTERS && pfBins[i] > 0; i++);
    if (i < NUM_OF_FILTERS) {
        fAlpha = 0.f;
        for (i=0; i < NUM_OF_FILTERS; i++) 
            fAlpha += pfBins[i]*pfBins[i];
        fAlpha = 0.005f*(float)sqrt(fAlpha/(float)NUM_OF_FILTERS);
        for (i=0; i < NUM_OF_FILTERS; i++) 
            if (pfBins[i] == 0)
                pfBins[i] += fAlpha;
    }

}


/*----------------------------------------------------------------------------
 * FUNCTION NAME: Bins_To_HighestMfcc
 *
 * PURPOSE:     Compute 10 HOC (High Order Cepstra) from the bins located in
 *              pstRec->afBinSpec. Put the result in pstRec->afHighestMfcc.
 * INPUT/OUTPUT: 
 *   pstRec pointer to the Reconstructor
 *
 * RETURN VALUE:
 *   none
 *  
 *---------------------------------------------------------------------------*/
static void Bins_To_HighestMfcc(Reconstructor *pstRec)
{
    int    iDim;
    float  *pfBins  = pstRec->afBinSpec;    
    float  *pfCeps = pstRec->afHighestMfcc;
    float  *pfDCTMatrixRow;
    int    iFirstHighCepsNo;
    int    i,j;
   
    // Log
    for (i=0; i < NUM_OF_FILTERS; i++) {
        if (pfBins[i] < pstRec->f_EXP_LOG_FLOOR)
            pfBins[i] = LOG_FLOOR;
        else			
            pfBins[i] = (float)(log(pfBins[i]));
    }

    iFirstHighCepsNo = pstRec->iCepstralDim-1; 
    // use the rows #iFirstHighCepsNo,...,#NUM_OF_FILTERS-2
    // (the first row has #0)
    iDim = NUM_OF_FILTERS - pstRec->iCepstralDim;

    for (i = 0; i < iDim; i++) {        
        pfCeps[i] = 0.f;
        pfDCTMatrixRow = pstRec->aafDct[i+iFirstHighCepsNo];
        for (j = 0; j < NUM_OF_FILTERS; j++)
            pfCeps[i] += pfBins[j] * pfDCTMatrixRow[j];
   	    	
    }
    
}


/* =====================================================================

                     INTERNAL FUNCTIONS

   ===================================================================== */


/************************************************************************
    Function: Reconstruct harmonic magnitudes by BFUN method.
  ***********************************************************************/
/*----------------------------------------------------------------------------
 * FUNCTION NAME: BFUN_ReconstructMagnitudes
 *
 * PURPOSE:     Reconstruct harmonic magnitudes by BFUN method
 *
 * INPUT/OUTPUT: 
 *   pstRec - pointer to the Reconstructor
 *   pstHarmonicInfo -  the array of the harmonics
 * INPUT:  
 *   iNoOfHarmonics - the number of the harmonics
 *   bVoiced - TRUE if voiced harmonics are passed, FALSE otherwise
 * RETURN VALUE:
 *   none
 *  
 *---------------------------------------------------------------------------*/
void BFUN_ReconstructMagnitudes(Reconstructor *pstRec,
                                int           iNoOfHarmonics,
                                HarmonicInfo  *pstHarmonicInfo,
                                BOOL          bVoiced)
{
    int i, iMissMfccRecovIter;
    
    if (bVoiced) 
        iMissMfccRecovIter = 2;
    else
        iMissMfccRecovIter = 0;

    
    if (bVoiced) {
      /* Do not use harmonic phases */
        for (i=0; i<iNoOfHarmonics; i++) {
            pstHarmonicInfo[i].fAmpCosPhase = 1.f;
            pstHarmonicInfo[i].fAmpSinPhase = 0.f;
        }
    }
    else {
      /* Use harmonic phases */
        for (i=0; i<iNoOfHarmonics; i++) {        
            AddPhase(pstHarmonicInfo[i].fCosPhase,
                     pstHarmonicInfo[i].fSinPhase,
                     pstHarmonicInfo[i].fPreEmpCosPhase,
                    pstHarmonicInfo[i].fPreEmpSinPhase,
                    &(pstHarmonicInfo[i].fAmpCosPhase),
                    &(pstHarmonicInfo[i].fAmpSinPhase));
            
        }
    }

  
    // Generate RAM basis functions
    SampleBasisFunction(pstRec,iNoOfHarmonics,pstHarmonicInfo);
                     

    
    CalcBasisFunctionBins(pstRec,pstHarmonicInfo);
           
    // Approxime amplitude binned spectrum 
    SqrtBins(pstRec);

    // Solve equations to obtain basis functions coefficients
    PositiveSolve(pstRec,
                  pstRec->afBinSpec,
                  pstRec->astBasisFunctionRAM,                                
                  pstRec->afBasisFuncCoefs);

    /* High Order Cepstra restoration */
    for (i=0; i < iMissMfccRecovIter; i++) {
        BfunRepresentation_To_Bins(pstRec);
        Bins_To_HighestMfcc(pstRec);
        AddHighestCepstra(pstRec,pstRec->afHighestMfcc);
        PositiveSolve(pstRec,
                      pstRec->afBinSpec,
                      pstRec->astBasisFunctionRAM,                                
                      pstRec->afBasisFuncCoefs);
    }


    
    // Generate absolute line spectrum as a linear combination of the 
    // basis functions
    CalcHarmonicAmplitudes(pstRec->afBasisFuncCoefs,
                           pstHarmonicInfo,
                           pstRec->astBasisFunctionRAM,
                           iNoOfHarmonics);						   

    // Compensate pre-emphasis
    for (i=0; i<iNoOfHarmonics; i++) {                
        pstHarmonicInfo[i].fAmp /= pstHarmonicInfo[i].fPreEmpAmp;        
    }
  
}

