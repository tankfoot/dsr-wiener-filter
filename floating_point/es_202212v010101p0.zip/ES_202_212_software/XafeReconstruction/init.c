/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: init.c
 * PURPOSE:   Initialize/deinitialize the reconstruction
 *
 *-------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#include "common.h"

#include "init_tab.h"


/* =====================================================================

                     INTERNAL FUNCTIONS

   ===================================================================== */




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  DirichletKernel
 *
 * PURPOSE:    Calculate Dirichlet kernel value at given frequency.
 *             Dirichlet kernel is Fourier Transform of rectangular
 *             window
 * INPUT:
 *   fRadianFreq - frequency
 *   iWinSize    - rectangular window length
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   Dirichlet kernel value
 *---------------------------------------------------------------------------*/
static float DirichletKernel(const float fRadianFreq, const int iWinSize)
{       
  if (0.0f==fRadianFreq) return ((float)iWinSize);

  return ((float)(sin(fRadianFreq * 0.5f * iWinSize) / sin(fRadianFreq * 0.5f)));
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  HammingWindowTransform
 *
 * PURPOSE:    Calculate Fourier Transform of Hamming window at given
 *             frequency
 * INPUT:
 *   fRadianFreq - frequency
 *   iWinSize    - rectangular window length
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   Computed value
 *---------------------------------------------------------------------------*/
static float HammingWindowTransform(      float fRadianFreq,
                             const int   iWinSize)
{
 float fValue;
 float fRadianFreqOffset = M_2PI/(float)(iWinSize - 1);


 fValue = 0.54f * DirichletKernel(fRadianFreq,iWinSize) 
        + 0.23f * ( DirichletKernel(fRadianFreq-fRadianFreqOffset,iWinSize) + 
                    DirichletKernel(fRadianFreq+fRadianFreqOffset,iWinSize)   );
 

 return(fValue);
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  HannWindowTransform
 *
 * PURPOSE:    Calculate Fourier Transform of Hann window at given
 *             frequency
 * INPUT:
 *   fRadianFreq - frequency
 *   iWinSize    - rectangular window length
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   Computed value
 *---------------------------------------------------------------------------*/
static float HannWindowTransform(      float fRadianFreq,
                             const int   iWinSize)
{
 float fValue;
 float fRadianFreqOffset = M_2PI/(float)(iWinSize);


 fValue = 0.50f * DirichletKernel(fRadianFreq,iWinSize) 
        + 0.25f * ( DirichletKernel(fRadianFreq-fRadianFreqOffset,iWinSize) + 
                    DirichletKernel(fRadianFreq+fRadianFreqOffset,iWinSize)   );

 
 return(fValue);
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  SampleWindowTransform
 *
 * PURPOSE:    This function samples a window Fourier Transform (WFT) at evenly spaced
 *             points equivilent to the DFT points, but with an initial offset to
 *             the right. The offset is smaller than a DFT point.
 * INPUT:
 *   pfuncWindowTransform() - pointer to a function for calculation of WFT
 *   iResolution - The number of equal spaced offsets between two DFT points
 *   iSpan - The total number of samples will be 2*iSpan+1, iSpan
 *           samples point on each side
 *   iDftSize - total number of DFT points
 *   iWinSize - window length
 * OUTPUT:
 *   pfWinTransSamples output array of (2*iSpan+1) samples 
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void SampleWindowTransform(float *pfWinTransSamples,
				  float (*pfuncWindowTransform)(float,const int),
                                  const int    iResolution,
                                  const int    iSpan,
                                  const int    iDftSize,
                                  const int    iWinSize)
{
 int i,j;
 int iBandWidth   = 2*iSpan+1;
 int iArrayOffset = 0;
 
 float fRadianFreqRes;
 float fRadianDftPointFreq;
 float fRadianFreq;
 float fInitialRadianFreq;
 
 //
 // Bandwidth (in radian frequency) between two
 // DFT points. This is the sampling step of the 
 // transform in radians.
 //
 fRadianDftPointFreq = M_2PI/(float)(iDftSize);

 //
 // Smallest offset. The above value is divided
 // by the resolution number, which gives the offsets
 // between each sampling set.
 //
 fRadianFreqRes = fRadianDftPointFreq/(float)iResolution;

 //
 // The first sampling set is the left most sampling set, where
 // the center of the window is half a DFT sample left the "center"
 // DFT sample. Here we calcualte the (negative) radian of the left
 // most sample of this first set
 //
 fInitialRadianFreq = -((float)iSpan - 0.5f)*fRadianDftPointFreq ;

 // Loop over all sampling sets
 for(i=0; i<iResolution; i++) {

   fRadianFreq = fInitialRadianFreq;

   // Sample window transform
   for(j=0;j<iBandWidth;j++)  {
     
     
	 pfWinTransSamples[iArrayOffset+j] = ((*pfuncWindowTransform)(fRadianFreq,iWinSize));

     fRadianFreq +=fRadianDftPointFreq;
   }

   // Update begginig cell for the next sampling set
   iArrayOffset += iBandWidth;

   // Update radian frequency of left most sample for the next set
   // (since the window center is sliding right, the left most sample
   // is sliding left).
   fInitialRadianFreq  -= fRadianFreqRes;

 } // of i loop (resolution loop)

}





/*----------------------------------------------------------------------------
 * FUNCTION NAME:  Init_Idct_and_Dct
 *
 * PURPOSE:    Computes DCT and IDCT matrices
 *
 * INPUT:
 *   none
 * OUTPUT:
 *   aafIdctMat - IDCT matrix
 *   aafDctMat - DCT matrix
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void Init_Idct_and_Dct(float aafIdctMat[NUM_OF_FILTERS][NUM_OF_FILTERS-1],
                              float
			      aafDctMat[NUM_OF_FILTERS-1][NUM_OF_FILTERS])                     
{
    float  fMult, fInv, fInv2, fEl;
    int    i, j;

    fInv  = 1.0f / (float)NUM_OF_FILTERS;
    fInv2 = 2.0f * fInv;

    for (i = 0; i < NUM_OF_FILTERS-1; i++) {
        fMult = (float)(M_PI * fInv * (float) (i+1));
        for (j = 0 ; j < NUM_OF_FILTERS; j++) {      
            fEl = (float)cos(fMult * ((float) j + 0.5f));
            aafIdctMat[j][i] = fInv2 * fEl;
            aafDctMat[i][j] = fEl;
        }
    }
}

/*----------------------------------------------------------------------------
 * FUNCTION NAME:  Init_IdctExt
 *
 * PURPOSE:    Computes 27-dimensional IDCT matrix for 16kHz AFE processing
 *
 * INPUT:
 *   none
 * OUTPUT:
 *   aafIdctExtMat - IDCT matrix
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void Init_IdctExt(float aafIdctExtMat[NUM_OF_FILTERS_EXT][NUM_OF_FILTERS_EXT-1])
{
    float  fMult, fInv, fInv2, fEl;
    int    i, j;

    fInv  = 1.0f / (float)NUM_OF_FILTERS_EXT;
    fInv2 = 2.0f * fInv;

    for (i = 0; i < NUM_OF_FILTERS_EXT-1; i++) {
        fMult = (float)(M_PI * fInv * (float) (i+1));
        for (j = 0 ; j < NUM_OF_FILTERS_EXT; j++) {      
            fEl = (float)cos(fMult * ((float) j + 0.5f));
            aafIdctExtMat[j][i] = fInv2 * fEl;
        }
    }
}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GenSinTable
 *
 * PURPOSE:    Tabulates Sin and Cos
 *
 * INPUT:
 *   none
 * OUTPUT:
 *   pfSinTable - array containing SIN_TABLE_SIZE elements 
 *   pfCosTable - array containing SIN_TABLE_SIZE elements
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void GenSinTable(float*      pfSinTable,
                        float*      pfCosTable
                        )                        
{
 int i;
 float fRadPhase;              
 float fDeltaRadPhase;

  
 fDeltaRadPhase = M_2PI / (float)SIN_TABLE_RES;

 for (i = 0, fRadPhase = 0.0f;
       i < SIN_TABLE_SIZE; 
	   i++, fRadPhase += fDeltaRadPhase) {
    pfCosTable[i] = (float)cos(fRadPhase);
    pfSinTable[i] = (float)sin(fRadPhase);
 }

}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  Mel
 *
 * PURPOSE:    Converts frequency (Hz) to Mel-scale
 *
 * INPUT:
 *   x - frequency
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   Mel-frequency
 *---------------------------------------------------------------------------*/
static float Mel(float x)
{
  return (float)(2595.0 * log10(1.0f+x/700.f));
}

/*----------------------------------------------------------------------------
 * FUNCTION NAME:  InvMel
 *
 * PURPOSE:    Converts frequency from Mel-scale to linear scale
 *
 * INPUT:
 *   x - mel-frequency
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   frequency
 *---------------------------------------------------------------------------*/
static float InvMel(float x)
{
    return (700.f*((float)pow(10,x/2595.) - 1.f));
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GenMelFilters
 *
 * PURPOSE:    Create Mel-triangular filters identical to those used at the
 *             Front-end
 *
 * INPUT:
 *   iSampleRate - sampling rate in Hz
 *   iDftSize - FFT length
 * OUTPUT:
 *   astMelFilter - array of NUM_OF_FILTERS Mel-filters
 * RETURN VALUE:
 *   0 - OK
 *   1 - memory allocation error
 *---------------------------------------------------------------------------*/
static int GenMelFilters(MelFilter*   astMelFilter,
                         const int    iSampleRate,
                         const int    iDftSize)                         
{

    int           i, j, iReturnCode;
    float         fMaxMel, fStartMel, fMelStep, f;    
    int           iRiseFilterLength, iFallFilterLength;
 
    int iDftNode[NUM_OF_FILTERS+2];

    iDftNode[0] = (int)(iDftSize*STARTING_FREQ/(float)iSampleRate + 0.5f);
    iDftNode[NUM_OF_FILTERS+1] = iDftSize/2;
    fStartMel = Mel(STARTING_FREQ);
    fMaxMel = Mel((float)(iSampleRate/2));
    fMelStep = (fMaxMel - fStartMel)/(float)(NUM_OF_FILTERS+1);
    for (i=1; i <= NUM_OF_FILTERS; i++) {
        f = InvMel(fStartMel + (float)i*fMelStep);
        iDftNode[i] = (int)(iDftSize*f/(float)iSampleRate + 0.5f);
    }
  
    for (i=0; i < NUM_OF_FILTERS; i++)
        astMelFilter[i].pfData = NULL;
  
    for (i = 0; i < NUM_OF_FILTERS; i++) {
        astMelFilter[i].iStartingPoint = iDftNode[i];
        astMelFilter[i].iEndingPoint = iDftNode[i+2];
        astMelFilter[i].iLength = 
            astMelFilter[i].iEndingPoint - astMelFilter[i].iStartingPoint +1;
        MALLOCATE(astMelFilter[i].pfData, float, astMelFilter[i].iLength, iReturnCode);
        if (0 != iReturnCode) return 1;
    
        iRiseFilterLength = iDftNode[i+1] - iDftNode[i] +1;      
        iFallFilterLength= astMelFilter[i].iLength - iRiseFilterLength + 1;
    
        // Lower frequency part of the triangle
        for (j = 0; j < iRiseFilterLength; j++)
            astMelFilter[i].pfData[j] = (float)(j+1)/(float)iRiseFilterLength;    
    
        // Higher frequency part of the triangle 
        for (j = 1; j < iFallFilterLength; j++) {
            astMelFilter[i].pfData[iRiseFilterLength+j-1] = 
                (float)(iFallFilterLength-j)/(float)iFallFilterLength;
        }
    }
    
    
    return 0;
}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GenBasisFunctionsROM
 *
 * PURPOSE:    Create masis functions defined at the Mel-channels 
 *
 * INPUT:
 *   astMelFilter - array of NUM_OF_FILTERS Mel-filters
 * OUTPUT:
 *   astBasisFunction - array of NUM_OF_FILTERS basis functions
 * RETURN VALUE:
 *   0 - OK
 *   1 - memory allocation error
 *---------------------------------------------------------------------------*/
static int    GenBasisFunctionsROM(BasisFunctionROM*   astBasisFunction,
                                   MelFilter*          astMelFilter)
{ 
    BasisFunctionROM *pstBasis;
    MelFilter     *pstMel;
    int i, j, iReturnCode;
    float fMelFilterValue;
    float fPolyFactor = 0.6f;


    for (i=0; i < NUM_OF_FILTERS; i++)
        astBasisFunction[i].pfData = NULL;
    

    for (i=0; i < NUM_OF_FILTERS; i++) {
        pstBasis = &(astBasisFunction[i]);
        pstMel = &(astMelFilter[i]);

        pstBasis->iStartingPoint = pstMel->iStartingPoint;
        pstBasis->iEndingPoint   = pstMel->iEndingPoint;
        pstBasis->iLength        = pstMel->iLength;

        // Allocate memory for the data field         
        MALLOCATE(pstBasis->pfData, float, pstBasis->iLength, iReturnCode);
        if (0 != iReturnCode) return 1;

        // Define a concave shaped curve as a function of the mel filter
        // value
        for(j=0; j<pstMel->iLength; j++) {
	        fMelFilterValue = pstMel->pfData[j];
	        pstBasis->pfData[j] = 
                fPolyFactor*fMelFilterValue*fMelFilterValue + 
                (1.0f-fPolyFactor)*fMelFilterValue;
        }
        
    }

  
    return 0;
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  AllocBasisFunctionsRAM
 *
 * PURPOSE:    Allocate BasisFunctionRAM[] structures used by BFUN
 *             magnitudes reconstruction method
 * INPUT:
 *   astBasisFunctionROM - array of NUM_OF_FILTERS basis functions
 * OUTPUT:
 *   astBasisFunctionRAM - array of NUM_OF_FILTERS elements
 * RETURN VALUE:
 *   0 - OK
 *   1 - memory allocation error
 *---------------------------------------------------------------------------*/
static int    AllocBasisFunctionsRAM(BasisFunctionROM*   astBasisFunctionROM,
                                     BasisFunctionRAM*   astBasisFunctionRAM)
{     
    int i, iReturnCode;
    
    for (i=0; i < NUM_OF_FILTERS; i++) {
        astBasisFunctionRAM[i].pfSampledFunc = NULL;
        astBasisFunctionRAM[i].pfBins = NULL;
    }
    

    for (i=0; i < NUM_OF_FILTERS; i++) {                 
        MALLOCATE(astBasisFunctionRAM[i].pfBins,float,NUM_OF_FILTERS,iReturnCode);
        if (0 != iReturnCode) return 1;

        MALLOCATE(astBasisFunctionRAM[i].pfSampledFunc,float,2*astBasisFunctionROM[i].iLength,iReturnCode);
        if (0 != iReturnCode) return 1;
    }

  
    return 0;
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  FormatUvHarmonicInfo
 *
 * PURPOSE:    Initialize unvoiced harmonic array
 * INPUT/OUTPUT:
 *   pstRec   - pointer to the Reconstructor
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *   
 *---------------------------------------------------------------------------*/
static void FormatUvHarmonicInfo(Reconstructor  *pstRec)                                                
{    
    int iDftPoint;
    HarmonicInfo *pstHarmonic;
    float fDftBinToHz = (float)pstRec->iSampleRate/(float)pstRec->iFftSize;
 
            
    pstHarmonic = pstRec->pstUvHarmonicInfo;
    for (iDftPoint=1; iDftPoint < pstRec->iFftLimit; 
        iDftPoint++, pstHarmonic++) {
        pstHarmonic->iWinSampleSet = WIN_TRANS_SETS/2;
        pstHarmonic->iDftFreq      = iDftPoint;            
        pstHarmonic->fFreqHz = (float)iDftPoint*fDftBinToHz;
        pstHarmonic->fOmega = M_2PI * (float)iDftPoint/(float)pstRec->iFftSize;
    }
    pstRec->iNoOfUvHarmonics = iDftPoint - 1;

    SamplePreEmpFilter(pstRec,
                       pstRec->iNoOfUvHarmonics,
                       pstRec->pstUvHarmonicInfo);
                     

}


/* =====================================================================

                      EXTERNAL  FUNCTIONS

   ===================================================================== */

/*----------------------------------------------------------------------------
 * FUNCTION NAME: XDSR_InitReconstructor
 *
 * PURPOSE:       Initialize the reconstruction, i.e. create an instance
 *                of Reconstructor that should be passed to other
 *                API functions
 *
 * INPUT:
 *    iSampleRatekHz   Sampling rate in kHz
 * OUTPUT
 *   ppvReconstructor  Pointer to the Reconstructor data structure
 *   piPcmFrameSize    Length of the portion (frame) of output speech signal
 *                     produced by each call to the XDSR_ReconstructFrame()
 *                     function
 * RETURN VALUE
 *   0 - OK
 *   1 - memomy allocation error
 *---------------------------------------------------------------------------*/
int XDSR_InitReconstructor(
                void**            ppvReconstructor,
                const int         iSampleRatekHz, 
                int*              piPcmFrameSize)
{
    Reconstructor* pstRec;
    int iMaxNoOfHarmonics;
    int i;
    int iReturnCode;


    /*
     We assume the Cmplx structure is tightly packed, allowing casting
     from float* to Cmplx*. Otherwise error.
    */
    if (sizeof(Cmplx) != 2*sizeof(float) ) {
      printf("\n ERROR: cannot initialize RECONCTRUCTOR\n");
      exit(1);
    }


 
    MALLOCATE(pstRec, Reconstructor, 1, iReturnCode);
    if (0 != iReturnCode) {
      *ppvReconstructor = NULL;
      return 1;
    }

    pstRec->f_EXP_LOG_FLOOR = (float)exp(LOG_FLOOR);
	    

    switch (iSampleRatekHz) {
    case 8:
      pstRec->iSampleRateOrig = 8000;
      break;
    case 16:
      pstRec->iSampleRateOrig = 16000;
      break;
    default:
      printf("\n ERROR: cannot initialize RECONCTRUCTOR\n");
      exit(1);
    }

    pstRec->iSampleRate = 8000; 
    pstRec->iFrameSize  = 80;
    pstRec->iFftSize    = 256;
    pstRec->iAnaWinSize = 200; 
    pstRec->iAPModelOrder = 10;


    
    pstRec->iVUvTransitionDftPoint = 1 + (int)
        (V_UV_TRANSITION_FREQ/(float)pstRec->iSampleRate*(float)pstRec->iFftSize);
    *piPcmFrameSize = pstRec->iFrameSize;
    
    pstRec->fPreEmph = 0.90f;

    pstRec->afAfeRefCep[0] = -6.618909f;
    pstRec->afAfeRefCep[1] =  0.198269f;
    pstRec->afAfeRefCep[2] = -0.740308f;
    pstRec->afAfeRefCep[3] =  0.055132f;
    pstRec->afAfeRefCep[4] = -0.227086f;
    pstRec->afAfeRefCep[5] =  0.144280f;
    pstRec->afAfeRefCep[6] = -0.112451f;
    pstRec->afAfeRefCep[7] = -0.146940f;
    pstRec->afAfeRefCep[8] = -0.327466f;
    pstRec->afAfeRefCep[9] =  0.134571f;
    pstRec->afAfeRefCep[10] =  0.027884f;
    pstRec->afAfeRefCep[11] = -0.114905f;
           
    iReturnCode = GenMelFilters(pstRec->astMelFilter, 
                                pstRec->iSampleRate,
                                pstRec->iFftSize);                         
    if (0 != iReturnCode)
        return 1;

    pstRec->iCepstralDim  = 13;

    Init_Idct_and_Dct(pstRec->aafIdct, pstRec->aafDct);
    if (16000 == pstRec->iSampleRateOrig) {
        Init_IdctExt(pstRec->aafIdctExt);
    }
    

    /* Last effective DFT point (when starting the count from DFT bin 0) */
    pstRec->iFftLimit = pstRec->iFftSize>>1;
	   
    iMaxNoOfHarmonics = 2*(pstRec->iFftLimit + 1);


    /* Initialize sin and cosine tables */
    GenSinTable(pstRec->afSinTable,
                pstRec->afCosTable);


    /* ----------------------------------------------------------------- 
         Prepare sampling sets of windowing functions Fourier transform
       ----------------------------------------------------------------- */


    /*
     The windowing function FT is sampled at 2*iWinFtBw+1
     points, roughly coresponding to a 100 Hz window span on each
     side of the window center peak. The following calculates how
     many DFT points correspond to 100 Hz in the current configuration.
    */
    pstRec->iWinFtBw     
        = (int)( WIN_TRANS_BW * (float) pstRec->iFftSize / (float) pstRec->iSampleRate + 0.5f);

                  
    /*
     Allocate memory for sampling sets. Each sampling set has
     2*iWinFtBw+1 values at the DFT points, assuming a different (sub sample)
     offset of the window transform center.
    */

    /*  Analysis window (used at front-end) */
    MALLOCATE(pstRec->pfAnaWinTranSamples,float,WIN_TRANS_SETS*(2*pstRec->iWinFtBw+1),iReturnCode);
    if (0 != iReturnCode) return 1;    
    SampleWindowTransform(pstRec->pfAnaWinTranSamples,
			  (float (*)(float, const int))HammingWindowTransform,
                          WIN_TRANS_SETS,
                          pstRec->iWinFtBw,
                          pstRec->iFftSize,
                          pstRec->iAnaWinSize);

    /* Synthesis window (used for OLA at the reconstruction) */
    MALLOCATE(pstRec->pfSynWinTranSamples,float,WIN_TRANS_SETS*(2*pstRec->iWinFtBw+1),iReturnCode);
    if (0 != iReturnCode) return 1;
    SampleWindowTransform(pstRec->pfSynWinTranSamples,
			  (float (*)(float, const int))HannWindowTransform,
                          WIN_TRANS_SETS,
                          pstRec->iWinFtBw,
                          pstRec->iFftSize,
                          2*pstRec->iFrameSize);

    /* Rectangular window, Dirichlet kernel  */
    MALLOCATE(pstRec->pfDirWinTranSamples,float,WIN_TRANS_SETS*(2*pstRec->iWinFtBw+1),iReturnCode);
    if (0 != iReturnCode) return 1;    
    SampleWindowTransform(pstRec->pfDirWinTranSamples,
			  (float (*)(float, const int))DirichletKernel,
                          WIN_TRANS_SETS,
                          pstRec->iWinFtBw,
                          pstRec->iFftSize,
                          pstRec->iAnaWinSize);
    
 
    /* -----------------------------------------------------------------
           Prepare  BFUN magnitudes reconstruction method
       ----------------------------------------------------------------- */
    iReturnCode = GenBasisFunctionsROM(pstRec->astBasisFunctionROM,
				       pstRec->astMelFilter);
    if (0 != iReturnCode) return 1;

    iReturnCode = AllocBasisFunctionsRAM(pstRec->astBasisFunctionROM,
					 pstRec->astBasisFunctionRAM);
    if (0 != iReturnCode) return 1;

    for (i=0; i<NUM_OF_FILTERS; i++)
        pstRec->aafBfunMatrix[i] = 
         &(pstRec->afBufMatrixBuffer[i*NUM_OF_FILTERS]);
 

    /*
      Allocate Harmonics Arrays
    */
    MALLOCATE(pstRec->pstHarmonicInfo,HarmonicInfo,iMaxNoOfHarmonics,iReturnCode);
    if (0 != iReturnCode) return 1;

    MALLOCATE(pstRec->pstUvHarmonicInfo,HarmonicInfo,iMaxNoOfHarmonics,iReturnCode);
    if (0 != iReturnCode) return 1;

 
 

    /*
         Alocate synthesis buffers
    */
    
    MALLOCATE(pstRec->pfReconDft,Cmplx,pstRec->iFftLimit+1,iReturnCode);
    if (0 != iReturnCode) return 1;

    MALLOCATE(pstRec->pfReconPcm,float,pstRec->iFrameSize,iReturnCode);
    if (0 != iReturnCode) return 1;
  
    

    pstRec->piUVphaseTable    = &aiUVphaseTable[0];
    pstRec->iUVPhaseTableSize = UV_PHASE_TABLE_SIZE;
    pstRec->piRationalFactors = &aiRationalFactors[0];
    pstRec->iNoOfRationalFactors = NO_OF_RATIONAL_FACTORS;
    
    

    pstRec->iUpperDftFreq = 
        (int)((float)pstRec->iFftLimit*UPPER_NORM_FREQ+0.5f);

    
    /* --------------------------------------------------------------------------
       Missing MFCC recovery initialization and INTERP-method related settings
    ---------------------------------------------------------------------------- */


    pstRec->pfMissMfccPitchThld = afPitchThld_AFE;

    pstRec->pfFixCep13_INTERP = afFixCep_AFE_8K_13;
    pstRec->pfFixCep23_INTERP = afFixCep_AFE_8K_23;
    pstRec->pfCBinMelFreq_INTERP = afCBinMelFreq_8K;
    pstRec->pfMissMfccCentroids = afMissMfccCentroid_AFE_8K;
               

   

    pstRec->iNoOfMissMfccCentroids = N_OF_MISS_MFCC_CENTROIDS;                

    /*   RESET   */
    memset(pstRec->pfReconPcm, 0, pstRec->iFrameSize * sizeof(float));
    pstRec->fPrevPitchPeriod      = UV_PITCH;
    pstRec->fPrevPitchPhase       = 0.0f;
    pstRec->pfPrevOutputSample    = 0.0f;
    memset(pstRec->afAfeCepBias,0,(STD_NUM_CEPS-1)*sizeof(float));


    pstRec->iUVPhaseIndex         = 0;

    FormatUvHarmonicInfo(pstRec);


    *ppvReconstructor = (void *)pstRec;

    return 0;
}





/*----------------------------------------------------------------------------
 * FUNCTION NAME: XDSR_ReleaseReconstructor
 *
 * PURPOSE:       Deallocate the Reconstructor
 *
 * INPUT:
 *   pvReconstructor  Pointer to Reconstructor (produced by XDSR_InitReconstructor())
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void	XDSR_ReleaseReconstructor(void* pvReconstructor)
{
    Reconstructor *pstRec = (Reconstructor*)pvReconstructor;
    int i;
    

    for (i=0; i < NUM_OF_FILTERS; i++) {
        MDEALLOCATE(pstRec->astMelFilter[i].pfData);
        MDEALLOCATE(pstRec->astBasisFunctionRAM[i].pfBins);
        MDEALLOCATE(pstRec->astBasisFunctionROM[i].pfData);
        MDEALLOCATE(pstRec->astBasisFunctionRAM[i].pfSampledFunc);
    }
   
    MDEALLOCATE(pstRec->pfReconPcm);    
    MDEALLOCATE(pstRec->pstHarmonicInfo);
    MDEALLOCATE(pstRec->pstUvHarmonicInfo);
    MDEALLOCATE(pstRec->pfReconDft); 
    MDEALLOCATE(pstRec->pfAnaWinTranSamples);
    MDEALLOCATE(pstRec->pfSynWinTranSamples);
    MDEALLOCATE(pstRec->pfDirWinTranSamples);
    MDEALLOCATE(pstRec);


}









