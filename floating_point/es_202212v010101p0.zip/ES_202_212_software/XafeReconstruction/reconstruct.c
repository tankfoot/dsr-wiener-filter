/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: reconstruct.c
 * PURPOSE:   Implementation of XDSR_ReconstructFrame() API function
 *
 *-------------------------------------------------------------------------------*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>


#include "common.h"




/* =====================================================================

                     INTERNAL FUNCTIONS

   ===================================================================== */



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  AFE_DeEqualizeCepstra
 *
 * PURPOSE:   Invert cepstra blind equalization transform performed
 *            at the front-end
 *
 * INPUT/OUTPUT:
 *   pstRec       Pointer to Reconstructor object, pstRec->fAfeCepBias is modified
 *   pfCepstra  - feature vector
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void AFE_DeEqualizeCepstra(
					Reconstructor  *pstRec,
                    float          *pfCepstra
					)
{
	float weightingPar, stepSize, new_bias;
	int i;
    
    

	if (pfCepstra[13] == 0) {
		return;
	}

	weightingPar = pfCepstra[13] - 211.0f/64.0f;
	if (weightingPar < 0.f) weightingPar = 0.f;
	if (weightingPar > 1.f) weightingPar = 1.f;

	stepSize = 0.0087890625f*weightingPar;

	for (i=0; i<12; i++) {
		new_bias = 0.999f*pstRec->afAfeCepBias[i] + 
			           stepSize*(pfCepstra[i] - pstRec->afAfeRefCep[i]);
		pfCepstra[i] += pstRec->afAfeCepBias[i];        
		pstRec->afAfeCepBias[i] = new_bias;
	}

}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  FormatHarmonicInfo
 *
 * PURPOSE:    Initialize voiced harmonics array  
 *
 * INPUT/OUTPUT:
 *   pstRec       Pointer to Reconstructor object
 * INPUT:                    
 *   none
 * 
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void FormatHarmonicInfo(Reconstructor  *pstRec)
                                                
{    
    HarmonicInfo *pstHarmonic;            
    int iLastPitchHarmNo, iHarmNo;
    float fDftPitchFreq, fDftHarmonicFreq;
        

    // Calculate the pitch frequency (F0) in DFT points
    fDftPitchFreq = pstRec->iFftSize / pstRec->fPitchPeriod;        

    // Calculate serial number of the last pitch harmonic to be taken                   
    iLastPitchHarmNo = (int)(pstRec->fPitchPeriod/2.f);
          
    pstHarmonic = pstRec->pstHarmonicInfo;
    for (iHarmNo=1; iHarmNo <= iLastPitchHarmNo; iHarmNo++, pstHarmonic++) {

        fDftHarmonicFreq = (float)iHarmNo*fDftPitchFreq;          
        pstHarmonic->iDftFreq = (int)(0.5f + fDftHarmonicFreq);
        // Calculate closest window sampling set
        pstHarmonic->iWinSampleSet = 
        (int)((fDftHarmonicFreq-pstHarmonic->iDftFreq+0.5f)*WIN_TRANS_SETS + 0.5f);

        // If win transform center is rounded to half DFT point ABOVE the
        // integer DFT point, then advance the integer DFT point by one
        // and use the left most sampling set instead
        if (WIN_TRANS_SETS==pstHarmonic->iWinSampleSet) {
            pstHarmonic->iDftFreq++;
            pstHarmonic->iWinSampleSet = 0;
        }

        pstHarmonic->fFreqHz = (float)(iHarmNo)*(float)pstRec->iSampleRate/
                                         pstRec->fPitchPeriod;
        pstHarmonic->fOmega = M_2PI*(float)(iHarmNo)/pstRec->fPitchPeriod;

    } // end for pitch harmonics

    pstRec->iNoOfPitchHarmonics = iLastPitchHarmNo;

    // Sample pre-emphasis filter at the harmonic frequencies
    SamplePreEmpFilter(pstRec,
                       pstRec->iNoOfPitchHarmonics,
                       pstRec->pstHarmonicInfo);
           
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  SetActiveHarmonicArray
 *
 * PURPOSE:    Determine which harmonic array will be used for the reconstruction
 *
 * INPUT/OUTPUT:
 *   pstRec       Pointer to Reconstructor object
 * INPUT:                    
 *   none
 * 
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
static void SetActiveHarmonicArray(Reconstructor *pstRec)                       
{
    switch (pstRec->eVoicingClass) {
        case VOICING_CLASS_MIX:            
            pstRec->pstActiveHarmonicInfo = pstRec->pstHarmonicInfo;
            pstRec->iActiveNoOfHarmonics = pstRec->iNoOfHarmonics;
            break;
        case VOICING_CLASS_FULL:
            pstRec->pstActiveHarmonicInfo = pstRec->pstHarmonicInfo;        
            pstRec->iActiveNoOfHarmonics = pstRec->iNoOfPitchHarmonics;
            break;
        case VOICING_CLASS_NULL:
            pstRec->pstActiveHarmonicInfo = pstRec->pstUvHarmonicInfo;
            pstRec->iActiveNoOfHarmonics = pstRec->iNoOfUvHarmonics;
            break;
        default:
            fprintf(stderr,"Internal error: Illegal voicing class\n");
            exit(1);
    }

}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  FilterOutNyquistVicinity
 *
 * PURPOSE:    Limit the number of elements in the active harmonic
 *             array to exclude vicinity of the Nyquist frequency
 * INPUT/OUTPUT:
 *   pstRec       Pointer to Reconstructor object
 * INPUT:                    
 *   none
 * 
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *
 *---------------------------------------------------------------------------*/
static void FilterOutNyquistVicinity(Reconstructor *pstRec)
{
    HarmonicInfo *pstHarmonic;
    int i, iNoOfHarmonics;
    
    pstHarmonic = pstRec->pstActiveHarmonicInfo;
    iNoOfHarmonics = pstRec->iActiveNoOfHarmonics;
    
    for (i=iNoOfHarmonics-1; i > 0; i--)
        if (pstHarmonic[i].iDftFreq <= pstRec->iUpperDftFreq) break;

    if (i+1 < iNoOfHarmonics)
        pstRec->iActiveNoOfHarmonics = i+1;
}





/*----------------------------------------------------------------------------
 * FUNCTION NAME:  ScaleByEnergy
 *
 * PURPOSE:   Scale the harmonics amplitude to meet the energy measurement
 *            done at the front-end and given by LogE 
 * INPUT/OUTPUT:
 *   pstRec       Pointer to Reconstructor object
 * INPUT:                    
 *   flogE        Log-energy value
 * 
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *
 *---------------------------------------------------------------------------*/
static void ScaleByEnergy(Reconstructor *pstRec, float fLogE)
{
	float fE, fRefE, fFactor;
    HarmonicInfo *pstHarmonicInfo, *pstHarmonic;
    int i, iNoOfHarmonics;
    
    pstHarmonicInfo = pstRec->pstActiveHarmonicInfo;
    iNoOfHarmonics = pstRec->iActiveNoOfHarmonics;
    
    
    for (i=0; i < iNoOfHarmonics; i++) {                
        pstHarmonicInfo[i].fAmpCosPhase = 
            pstHarmonicInfo[i].fAmp*pstHarmonicInfo[i].fCosPhase;
        pstHarmonicInfo[i].fAmpSinPhase = 
            pstHarmonicInfo[i].fAmp*pstHarmonicInfo[i].fSinPhase;
    }
    
    /* Compute DFT of the frame "weighted" by rectangular window */
    ReconstructDftFromHarmonics(pstRec->pfReconDft,
                                pstHarmonicInfo,
				pstRec->pfDirWinTranSamples,
				iNoOfHarmonics,
                                pstRec->iFftLimit,
				pstRec->iWinFtBw,
                                NULL);



    /* --------------------------------------------------------------
                         Calculate the energy 
       -------------------------------------------------------------- */
    fE = 0.f;	    
    for (i=1; i < pstRec->iFftLimit; i++)         
      fE += pstRec->pfReconDft[i].real*pstRec->pfReconDft[i].real +
	pstRec->pfReconDft[i].imag*pstRec->pfReconDft[i].imag;
    fE *= 2.f;    
    fE += pstRec->pfReconDft[0].real*pstRec->pfReconDft[0].real +
      pstRec->pfReconDft[0].imag*pstRec->pfReconDft[0].imag;
    fE /= (float)pstRec->iFftSize;

    if (0 == fE) return;

	
    /*  Get reference energy value   */
    fRefE = (float)exp(fLogE);
			
		
    /*  Normalize */
    fFactor = (float)sqrt(fRefE/fE);
    pstHarmonic = pstHarmonicInfo;
    for (i=0; i < iNoOfHarmonics; i++, pstHarmonic++)
      pstHarmonic->fAmp *= fFactor;
	
}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  FloatToShort
 *
 * PURPOSE:   Convert output PCM samples from float to short
 *            and copy it to the out buffer
 * INPUT:
 *   pfOutPcm       Floating point buffer
 *   iFrameSize     The length of the buffer
 * 
 * OUTPUT:
 *   psOutPCM      output buffer 
 * RETURN VALUE:
 *   none
 *
 *---------------------------------------------------------------------------*/
static void FloatToShort(float          *pfOutPcm,
                         int            iFrameSize,
                         short          *psOutputPCM)
{
    int   i; 
    float fOutSample;

    for (i = 0; i < iFrameSize; i++) {     
        fOutSample = pfOutPcm[i];     
        if (fOutSample > 32767.0f)
            psOutputPCM[i] = 32767;
        else if (fOutSample < -32768.0f)
            psOutputPCM[i] = -32768;
        else
            psOutputPCM[i] = (short)fOutSample;
    }
  
    
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  BfunMag2InterpMagScaleFactor
 *
 * PURPOSE:   Compute scaling factor to be applied to the BFUN magnitudes
 *            before they are mixed with INTERP magnitudes
 * INPUT:
 *   iNoOfHarmonics - number of harmonics
 *   pstHarmonic   - array of harmonics
 * 
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   sacling factor
 *
 *---------------------------------------------------------------------------*/
static float BfunMag2InterpMagScaleFactor(
                                    int          iNoOfHarmonics,                    
                                    HarmonicInfo *pstHarmonic
                                    )
{
    float fEn1, fEn2, fScale;
    int i;
    
    fEn1 = fEn2 = 0.f;
    for (i=0; i<iNoOfHarmonics; i++) {
        fEn1 += pstHarmonic[i].fAmp*pstHarmonic[i].fAmp;
        fEn2 += pstHarmonic[i].fAmpIM*pstHarmonic[i].fAmpIM;
    }
    if (0 == fEn1) return 0.f;
    fScale = (float)sqrt(fEn2/fEn1);
    return fScale;
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  ScaleMagnitudes
 *
 * PURPOSE:   Multiply harmonics amplitude  by a frequency dependent 
 *            factor. The factor curve is given by two points:
 *            (fScaleLow,fFreqHzLow) and (fScaleHigh,fFreqHzHigh).
 *            In the low band (F <= fFreqHzLow) the scaling factor is fScaleLow.
 *            In the high band (F >= fFreqHzHigh) the scaling factor is fScaleHigh.
 *            Scaling factor is linearly interpolated Between fFreqHzLow and
 *            fFreqHzHigh.
 *            If fScaleHigh < 0 the constant scaling is done by fScaleLow  
 * INPUT/OUTPUT:
 *   pstHarmonic   - array of harmonics
 * INPUT:
 *   iNoOfHarmonics - the length of the array
 *   fScaleLow
 *   fScaleHigh
 *   fFreqHzLow
 *   fFreqHzHigh 
 * OUTPUT:
 *   none
 * RETURN VALUE
 *   none
 *
 *---------------------------------------------------------------------------*/
static void ScaleMagnitudes(
                          int          iNoOfHarmonics,
                          HarmonicInfo *pstHarmonic,
                          float        fScaleLow,
                          float        fScaleHigh,
                          float        fFreqHzLow,
                          float        fFreqHzHigh
                          )
{
    int i;
    float fScale, fLambda;

    if (fScaleHigh < 0) {
        for (i=0; i<iNoOfHarmonics; i++)
            pstHarmonic[i].fAmp *= fScaleLow; 
        return;
    }

    // Frequency dependent scaling
    for (i=0; i < iNoOfHarmonics; i++) {
        if (pstHarmonic[i].fFreqHz <= fFreqHzLow)
            fScale = fScaleLow;
        else if (pstHarmonic[i].fFreqHz >= fFreqHzHigh)
            fScale = fScaleHigh;
        else { // Interpolate scaling factor
            fLambda = (fFreqHzHigh-pstHarmonic[i].fFreqHz) /
                      (fFreqHzHigh - fFreqHzLow);
            fScale = fLambda*fScaleLow + (1.f-fLambda)*fScaleHigh;
        }
        pstHarmonic[i].fAmp *= fScale;
    }

}

/*----------------------------------------------------------------------------
 * FUNCTION NAME:  MixMagnitudes
 *
 * PURPOSE:   Mix BFUN and INTERP magnitudes in a given proportion
 *
 * INPUT/OUTPUT:
 *   pstHarmonic   - array of harmonics
 * INPUT:
 *   iNoOfHarmonics - the length of the array
 *   fAlpha      weighting coefficient for BFUN magnitude
 *   fBeta       weighting coefficient for INTERP magnitude
 * OUTPUT:
 *   none
 * RETURN VALUE
 *   none
 *
 *---------------------------------------------------------------------------*/
static void MixMagnitudes(
                          int          iNoOfHarmonics,
                          HarmonicInfo *pstHarmonic,
                          float        fAlpha,
                          float        fBeta
                          )
{
    int i;
    for (i=0; i<iNoOfHarmonics; i++)
        pstHarmonic[i].fAmp = 
              fAlpha*pstHarmonic[i].fAmp + fBeta*pstHarmonic[i].fAmpIM;    
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  MixVoicedMagnitudes
 *
 * PURPOSE:   Define the mixing ratio and mix BFUN and INTERP magnitudes
 *            for voiced harmonics
 *
 * INPUT/OUTPUT:
 *   pstRec   Pointer to the Reconstructor
 * INPUT:
 *   none
 * OUTPUT:
 *   none
 * RETURN VALUE
 *   none
 *
 *---------------------------------------------------------------------------*/
static void MixVoicedMagnitudes(Reconstructor *pstRec)                 
{

  /* Frequency dependent mixing constants */
#define PITCH_THR_FOR_FREQ_DEPEND_MIX 55.f // 8kHz samples
#define FREQ_BP_FOR_FREQ_DEPEND_MIX   1200.f // Hz
#define FLOW_FOR_FREQ_DEPEND_MIX       200.f // Hz
#define FHIGH_FOR_FREQ_DEPEND_MIX     2500.f // Hz

#define NUM_OF_MIX_MAG_NODES   26

typedef struct MIX_NODE_tag{
        float  fPit; 
        float  fAlpha;
} MixNode;

/* ------------------------------------- */
/*     Alpha vs. Pitch Curve             */
/* ------------------------------------- */

    static MixNode astMixNode_XAFE[NUM_OF_MIX_MAG_NODES] = {
    { 22.5f,  0.0459f},
    { 27.5f,  0.0765f},
    { 32.5f,  0.1124f},
    { 37.5f,  0.1384f},
    { 42.5f,  0.1869f},
    { 47.5f,  0.2858f},
    { 52.5f,  0.4309f},
    { 57.5f,  0.5676f},
    { 62.5f,  0.6458f},
    { 67.5f,  0.6779f},
    { 72.5f,  0.7009f},
    { 77.5f,  0.7646f},
    { 82.5f,  0.8347f},
    { 87.5f,  0.8740f},
    { 92.5f,  0.8586f},
    { 97.5f,  0.8306f},
    {102.5f,  0.8299f},
    {107.5f,  0.8496f},
    {112.5f,  0.8346f},
    {117.5f,  0.7617f},
    {122.5f,  0.7336f},
    {127.5f,  0.6321f},
    {132.5f,  0.5522f},
    {137.5f,  0.4016f},
    {142.5f,  0.3306f},
    {147.5f,  0.2909f}
};



    int  last_node;
    float  fAlpha, fBeta, fScale, fScaleLow, fScaleHigh, fLambda;
    float fPitch8kHz;
    MixNode *pstMixNode;
        
    pstMixNode = astMixNode_XAFE;

    /* --------------------------------------------------------
             Compute pitch dependent mixing factor Alpha
	     by linear interpolation between the nodes
             of the "Alpha vs. Pitch" curve.
       -------------------------------------------------------- */
    fPitch8kHz = pstRec->fPitchPeriod*8000.f/(float)pstRec->iSampleRate;
    last_node = NUM_OF_MIX_MAG_NODES - 1;
    if (fPitch8kHz <= pstMixNode[0].fPit)
      fAlpha = pstMixNode[0].fAlpha;
    else if (fPitch8kHz >= pstMixNode[last_node].fPit)
      fAlpha = pstMixNode[last_node].fAlpha;
    else {
      int left_node, right_node;

      for (right_node=1; right_node < NUM_OF_MIX_MAG_NODES; right_node++) {
	if (pstMixNode[right_node].fPit > fPitch8kHz) break;
      }
      left_node = right_node - 1;
      fLambda = (pstMixNode[right_node].fPit - fPitch8kHz) /
	(pstMixNode[right_node].fPit - pstMixNode[left_node].fPit);
      fAlpha = fLambda*pstMixNode[left_node].fAlpha + 
	(1.f-fLambda)*pstMixNode[right_node].fAlpha;
    }

    fBeta = (1.f - fAlpha);


    if (fPitch8kHz < PITCH_THR_FOR_FREQ_DEPEND_MIX) {
      /* ----------------------------------------------------------------
            Scale BFUN magnitudes by a frequency dependent factor
	 ---------------------------------------------------------------- */
      int  iBpHarmNo;
            

      iBpHarmNo = (int)(FREQ_BP_FOR_FREQ_DEPEND_MIX *
			pstRec->fPitchPeriod / (float)pstRec->iSampleRate);
            
      fScaleLow = BfunMag2InterpMagScaleFactor(iBpHarmNo,
                                               pstRec->pstHarmonicInfo);
                        
      fScaleHigh = BfunMag2InterpMagScaleFactor(
						pstRec->iNoOfPitchHarmonics - iBpHarmNo,
						&(pstRec->pstHarmonicInfo[iBpHarmNo]));

      ScaleMagnitudes(pstRec->iNoOfPitchHarmonics,
		      pstRec->pstHarmonicInfo,
		      fScaleLow,fScaleHigh,
		      FLOW_FOR_FREQ_DEPEND_MIX,
		      FHIGH_FOR_FREQ_DEPEND_MIX);            
    }
    else {
      /*     Constant scale   */
      fScale = BfunMag2InterpMagScaleFactor(pstRec->iNoOfPitchHarmonics,
                                            pstRec->pstHarmonicInfo);
      ScaleMagnitudes(pstRec->iNoOfPitchHarmonics,
		      pstRec->pstHarmonicInfo,
		      fScale,-1.f, 0, 0);
    }
                  

    /*      MIX     */
    MixMagnitudes(pstRec->iNoOfPitchHarmonics,
		  pstRec->pstHarmonicInfo,
		  fAlpha, fBeta);                           
                       
            
}

/* -----------------------------------------------------------------
    Mix pstRec->pstUvHarmonicInfo[].fAmp and pstRec->pstUvHarmonicInfo[].fAmpIM
    and put the result in pstRec->pstUvHarmonicInfo[].fAmp.
  ------------------------------------------------------------------ */
/*----------------------------------------------------------------------------
 * FUNCTION NAME:  MixUnvoicedMagnitudes
 *
 * PURPOSE:   Define the mixing ratio and mix BFUN and INTERP magnitudes
 *            for unvoiced harmonics
 *
 * INPUT/OUTPUT:
 *   pstRec   Pointer to the Reconstructor
 * INPUT:
 *   none
 * OUTPUT:
 *   none
 * RETURN VALUE
 *   none
 *
 *---------------------------------------------------------------------------*/
static void MixUnvoicedMagnitudes(Reconstructor *pstRec)
{
#define MIX_UV_MAGS_BFUN_WEIGHT 0.9f
    float fScale, fAlpha, fBeta;

    fScale = BfunMag2InterpMagScaleFactor(pstRec->iNoOfUvHarmonics,
                                          pstRec->pstUvHarmonicInfo);
    ScaleMagnitudes(pstRec->iNoOfUvHarmonics,
                    pstRec->pstUvHarmonicInfo,
                    fScale,-1.f, 0, 0);
    
    fAlpha = MIX_UV_MAGS_BFUN_WEIGHT;
    fBeta = 1.f - fAlpha;

    MixMagnitudes(pstRec->iNoOfUvHarmonics,
                  pstRec->pstUvHarmonicInfo,
                  fAlpha, fBeta);        
}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  SyntLineSpectrum_MIX
 *
 * PURPOSE:      Compute BFUN and INTERP magnitudes and mix them
 *
 * INPUT/OUTPUT:
 *   pstRec       Pointer to Reconstructor object
 * INPUT:                    
 *   pfFeatureVector  Feature vector containing 13 MFCC and log-energy
 *                    [C1,...,C12,C0,logE]
 * OUTPUT
 *   none
 * RETURN VALUE
 *   none
 *---------------------------------------------------------------------------*/
static void SyntLineSpectrum_MIX(
                 Reconstructor *pstRec,
                 float         *pfFeatureVector
                 )
{
  BOOL bVoiced;
  /* Convert cepstra to binned spectrum */
  CepstraToBinSpectrum(pstRec, pfFeatureVector);
    
  if (pstRec->eVoicingClass != VOICING_CLASS_NULL) {    
    FormatHarmonicInfo(pstRec);
                            
    /* Initialize missing MFCC recovery */
    GetMissingMfccCentroid(pstRec, pstRec->fPitchPeriod,
			   pstRec->afHighestMfcc);
    AddHighestCepstra(pstRec,pstRec->afHighestMfcc);                

    BFUN_ReconstructMagnitudes(pstRec,
			       pstRec->iNoOfPitchHarmonics,
			       pstRec->pstHarmonicInfo,
			       bVoiced = TRUE); 
    INTERP_ReconstructMagnitudes(pstRec,
				 pstRec->fPitchPeriod,
				 pstRec->iNoOfPitchHarmonics,
				 pstRec->pstHarmonicInfo,
				 pfFeatureVector);

    MixVoicedMagnitudes(pstRec);
  } // endif VOICING_CLASS_MIX or VOICING_CLASS_FULL


  if (pstRec->eVoicingClass != VOICING_CLASS_FULL) {
    GenerateUvPhase(pstRec);
    BFUN_ReconstructMagnitudes(pstRec,
			       pstRec->iNoOfUvHarmonics,
			       pstRec->pstUvHarmonicInfo,
			       bVoiced = FALSE);
    INTERP_ReconstructMagnitudes(pstRec,
				 UV_PITCH,
				 pstRec->iNoOfUvHarmonics,
				 pstRec->pstUvHarmonicInfo,
				 pfFeatureVector);

    MixUnvoicedMagnitudes(pstRec);
  } // endif unvoiced component required

        
}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  MergeVoicedUnvoicedComponents
 *
 * PURPOSE:   Create line spectrum of a semi-voiced frame by merging
 *            voiced and unvoiced components
 *
 * INPUT/OUTPUT:
 *   pstRec   Pointer to the Reconstructor
 * INPUT:
 *   none
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   none
 *
 *---------------------------------------------------------------------------*/
static void MergeVoicedUnvoicedComponents(Reconstructor *pstRec)
{
    int i, j, iLastPitchHarm, iFirstUvHarm;
    float fEnrgV, fEnrgUV, fGain;
    HarmonicInfo *pstHarmonic = pstRec->pstHarmonicInfo,
                 *pstUvHarmonic = pstRec->pstUvHarmonicInfo;
    
    /*  Determine the last voiced harmonic to take */
    iLastPitchHarm = (int)(V_UV_TRANSITION_FREQ/
                   ((float)pstRec->iSampleRate/pstRec->fPitchPeriod));

    /* The first unvoiced harmonic to be taken */
    iFirstUvHarm = pstRec->iVUvTransitionDftPoint;

    /* Compute the reference energy of the tail */
    fEnrgV = 0.f;
    for (i=iLastPitchHarm+1; i < pstRec->iNoOfPitchHarmonics; i++)
        fEnrgV += pstHarmonic[i].fAmp*pstHarmonic[i].fAmp;

    /* Compute the actual energy of the tail */
    fEnrgUV = 0.f;
    for (i=iFirstUvHarm; i < pstRec->iNoOfUvHarmonics; i++)
        fEnrgUV += pstUvHarmonic[i].fAmp*pstUvHarmonic[i].fAmp;

    /*  Compute gain factor for the unvoiced tail */
    fGain = (float)sqrt(fEnrgV/fEnrgUV);


    /*  Copy noise harmonics and scale their amplitudes */
    for (j=iLastPitchHarm+1, i=iFirstUvHarm; i<pstRec->iNoOfUvHarmonics; 
    i++, j++) {
        pstHarmonic[j] = pstUvHarmonic[i];
        pstHarmonic[j].fAmp *= fGain;
    }

    pstRec->iNoOfHarmonics = 1+iLastPitchHarm + 
                             pstRec->iNoOfUvHarmonics - iFirstUvHarm +1; 


}





/* =====================================================================

                     EXTERNAL  FUNCTIONS

  ===================================================================== */


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  XDSR_ReconstructFrame
 *
 * PURPOSE:     Reconstruct the next frame of speech signal
 *
 * INPUT/OUTPUT:
 *   pvReconstructor  Pointer to Reconstructor object which is modified 
 *                    by every call to this function
 * INPUT:
 *   pfFeatureVector  Feature vector containing 13 MFCC and log-energy
 *                    [C1,...,C12,C0,logE]
 *   fPitchPeriod8khz Pitch period (number of samples at 8kHz rate)
 *   cVoicingClass    Voicing class
 * OUTPUT:
 *   psOutputPCM      Reconstructed frame, its size is defined by
 *                    the call to XDSR_InitReconstructor()
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void XDSR_ReconstructFrame(
                void*  pvReconstructor,
                float  *pfFeatureVector, 
                float  fPitchPeriod8kHz,
                unsigned char cVoicingClass,
                short  *psOutputPCM
                )

{
  Reconstructor *pstRec = (Reconstructor*)pvReconstructor;
  float *pfFftBuf;
  float *pfOutPcm;
  int i, j;
  HarmonicInfo *pstHarmonic;
  int iNoOfHarmonics;
    
    
  pstRec->pstActiveHarmonicInfo = NULL;
  pstRec->iActiveNoOfHarmonics = 0;

  if (UV_PITCH == fPitchPeriod8kHz) {
    /* Unvoiced speech */
    pstRec->eVoicingClass = VOICING_CLASS_NULL;
    pstRec->fPitchPeriod = UV_PITCH;
  }
  else {
    /* ------------------ */
    /*   Voiced Speech    */
    /* ------------------ */

    /*  Adjust pitch period to the current sampling rate */
    pstRec->fPitchPeriod = 
      fPitchPeriod8kHz*(float)pstRec->iSampleRate/(float)REF_SAMPLE_RATE;
    if ('2' == cVoicingClass)
      pstRec->eVoicingClass = VOICING_CLASS_MIX;
    else
      pstRec->eVoicingClass = VOICING_CLASS_FULL;    
  }


  /* Invert cepstra blind dequalizqation transform */
  AFE_DeEqualizeCepstra(pstRec, pfFeatureVector);

  if (16000==pstRec->iSampleRateOrig)
    /* "Cancell" 16kHz processing done at the front-end  */
    Fix16kHzCepstraAndEnergy(pstRec,pfFeatureVector);

  SyntLineSpectrum_MIX(pstRec,pfFeatureVector);

    

  if (VOICING_CLASS_NULL != pstRec->eVoicingClass) {
    /* ------------------------------------------------- */
    /*  All-pole modeling, min-phase, postfiltering      */
    /* ------------------------------------------------- */
    GeneratePitchPhase(pstRec);
    BuildAPModel(pstRec);
    GenerateAdditionalPhase(pstRec);
    weight_spec_mag(pstRec);        
  }


  if (VOICING_CLASS_MIX == pstRec->eVoicingClass)
    MergeVoicedUnvoicedComponents(pstRec);
    
  SetActiveHarmonicArray(pstRec);

  FilterOutNyquistVicinity(pstRec);
        
  ScaleByEnergy(pstRec, pfFeatureVector[pstRec->iCepstralDim]);

    
  iNoOfHarmonics = pstRec->iActiveNoOfHarmonics;
  pstHarmonic = pstRec->pstActiveHarmonicInfo;

  /* ------------------------------------------------------- */
  /*    Compute Real and Imaginary parts of each harmonic    */
  /*    in .fAmpCosPhase and .fAmpSinPhase                   */
  /* ------------------------------------------------------- */   
  for (i=0; i < iNoOfHarmonics; i++) {                
    pstHarmonic[i].fAmpCosPhase = pstHarmonic[i].fAmp*pstHarmonic[i].fCosPhase;
    pstHarmonic[i].fAmpSinPhase = pstHarmonic[i].fAmp*pstHarmonic[i].fSinPhase;
  }




  /* ---------------------------------------------------------------- 
     Convert the Line Spectrum to DFT
     This is done by convolving the Line Spectrum with Fourier
     Transform of Synthesis Windowing Function, and sampling the
     convolution result at DFT frequencies.
     Note that the Synthesis Windowing Function is Hann window
     of the length 2*pstRec->iFrameSize, that is 20ms.     
    ---------------------------------------------------------------- */
  ReconstructDftFromHarmonics(pstRec->pfReconDft,
			      pstHarmonic,
			      pstRec->pfSynWinTranSamples,
			      iNoOfHarmonics,
			      pstRec->iFftLimit,
			      pstRec->iWinFtBw,
			      NULL);


  /* -------------------------------------------------------
                Inverse FFT inplace
    ------------------------------------------------------- */

  pfFftBuf = (float*)pstRec->pfReconDft;
  /* Compact DFT representatoin: real value at PI is placed in imaginary part
     of DC */
  pfFftBuf[1] = pfFftBuf[pstRec->iFftSize];
 
  realft(pfFftBuf, pstRec->iFftSize, -1);


  /* -----------------------------------------------------------------------
                         Overlap And Add

      By the IFFT we've obtained pstRec->iFftSize length time domain signal.
      However only 2*FrameSize samples of its (synthesis window) are 
      usefull. 
      The left half of the synthesis window will be added with
      the contents of the OLA buffer, and the result will be moved
      to the output buffer. Then the right half of the synthesis
      window will be copied to the OLA buffer in order to prepare
      for the next OLA operation.

      The left half of the synthesis window is represented by
      the last pstRec->iFrameSize-1 samples of the FFT buffer followed
      by the 0-th sample. The right half of the synthesis window
      is represented by the pstRec->iFrameSize samples of FFT buffer 
      starting with the sample #1
    ----------------------------------------------------------------------- */

  pfOutPcm = pstRec->pfReconPcm; /* This is the OLA buffer */
  
      
  /*  Add the left half of the synthesis window to the OLA buffer */
    j = pstRec->iFftSize - pstRec->iFrameSize + 1;
    for (i=0; i<pstRec->iFrameSize-1; i++,j++)
        pfOutPcm[i] += pfFftBuf[j];
    pfOutPcm[i] += pfFftBuf[0];
 
    /*  Move the result to the output buffer */
    FloatToShort(pfOutPcm,
                 pstRec->iFrameSize,
                 psOutputPCM);
                         
    /*
      Prepare the next OLA operation by copying the right half of
      the synthesis window to the OLA buffer
    */
    memcpy(pfOutPcm, &pfFftBuf[1], pstRec->iFrameSize * sizeof(float));
        
    /* Store pitch value */
    pstRec->fPrevPitchPeriod = pstRec->fPitchPeriod;


}



