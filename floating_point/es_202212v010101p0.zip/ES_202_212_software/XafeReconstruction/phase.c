/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: phase.c
 * PURPOSE:   Harmonic phase calculation implementation
 *
 *-------------------------------------------------------------------------------*/


#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#include "common.h"



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  FindBestRationalFactor
 *
 * PURPOSE:   Given two positive numbers fN1 and fN2, find the integer numbers
 *            iR1 and iR2 such that the following expression is minimized:
 *              min   { abs(fN1*iR1-iN2*iR2)/fN1*iR1 }
 *            iR1,iR2
 * INPUT:
 *   fN1, fN2
 *   piRationalFactors - array of integer values for iR1, iR2
 *   NoOfFractors - length of the above array
 * OUTPUT:
 *   none
 * RETURN VALUE:
 *   fMult = iR1/iR2
 *---------------------------------------------------------------------------*/
static void FindBestRationalFactor(const float fN1, 
                                   const float fN2, 
				   int*  piRationalFactors,
                                   const int   NoOfFractors,
                                   float *fMult)
{
 float fErr,fMinErr = FLT_MAX;
 float fN1R1,fN2R2;
 int   iIndx=0,iBestIndx=0;
 
 for(iIndx=0;iIndx<2*NoOfFractors;iIndx+=2) {

  fN1R1 = fN1*(float)piRationalFactors[iIndx];
  fN2R2 = fN2*(float)piRationalFactors[iIndx+1];  

  fErr = (ABS(fN1R1-fN2R2)) / fN1R1 ;

  if (fErr < fMinErr) {
   fMinErr   = fErr;
   iBestIndx = iIndx;
  }

 }

 // Restore best rational factors
 *fMult = (float)piRationalFactors[iBestIndx]/(float)piRationalFactors[iBestIndx+1];
}



/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GeneratePitchPhase
 *
 * PURPOSE:   Compute linear in freaquency pitch dependent phase for
 *            voiced harmonics
 * INPUT/OUTPUT:
 *   pstRec - pointer to the Reconstructor
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GeneratePitchPhase(Reconstructor    *pstRec)
                                      
{
    int i, iNoOfHarmonics;
    float fPitchFreq, fPitchPhase;      

    HarmonicInfo *pstHarmonic;
    
    pstHarmonic = pstRec->pstHarmonicInfo;
    iNoOfHarmonics = pstRec->iNoOfPitchHarmonics;
    
 
    // ----------------------------------------------------
    // Prepare for linear phase calculation 
    // ----------------------------------------------------
    fPitchFreq  = 1.0f/pstRec->fPitchPeriod;
   
    if (UV_PITCH == pstRec->fPrevPitchPeriod) {
        // Beginning of voiced region - the linear phase at the
        // first pitch harmonic can be 0.
        fPitchPhase = 0.0f;  
    }   
    else {
        // Continuation of voiced region - the linear phase at
        // the first pitch harmonic should support time-alignment
        // with the previously synthesized piece of signal so
        // that OLA will produce smooth signal.
        float fAveragePitchFreq, fPrevPitchFreq, fMult;
    
        fPrevPitchFreq = 1.0f/pstRec->fPrevPitchPeriod;
            
        // Compensate gross pitch jumps between the current
        // and the previous frames
        FindBestRationalFactor(pstRec->fPitchPeriod, 
                           pstRec->fPrevPitchPeriod, 
                           pstRec->piRationalFactors,
                           pstRec->iNoOfRationalFactors,
                           &fMult);
        // The effective previous pitch value to be used is
        // fPrevPitchPeriod*fMult
        fAveragePitchFreq = 0.5f*(fPrevPitchFreq*fMult + fPitchFreq);    
        fPitchPhase = pstRec->fPrevPitchPhase*fMult + 
                      fAveragePitchFreq*(float)pstRec->iFrameSize;

        // The phase we obtained is measured in 1/(2pi) units.
        // That is 1 represents 2pi. Therefore truncation of the
        // integral part corresponds to removing integer 
        // multiplies of 2pi  
        fPitchPhase -= (int)fPitchPhase; 
            

    } // endif consecutive voiced frames


    // Save pitch phase for next frame 
    pstRec->fPrevPitchPhase = fPitchPhase;


    // ------------------------------------------
    //     Loop over the harmonics
    // ------------------------------------------


    for (i=0; i < iNoOfHarmonics; i++, pstHarmonic++) {
                                                                              
        // Compute linear phase
        GetCosSinOfNormalizedArg(pstRec, 
                                 (i+1)*fPitchPhase,
                                 &(pstHarmonic->fSinPhase),
                                 &(pstHarmonic->fCosPhase));	                                 
    } // end of loop over the harmonics


}




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GenerateUvPhase
 *
 * PURPOSE:   Compute random phase for unvoiced harmonics
 *
 * INPUT/OUTPUT:
 *   pstRec - pointer to the Reconstructor
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GenerateUvPhase(Reconstructor    *pstRec)                                      
{
    int i, iNoOfHarmonics;      
    HarmonicInfo *pstHarmonic;
    
    pstHarmonic = pstRec->pstUvHarmonicInfo;
    iNoOfHarmonics = pstRec->iNoOfUvHarmonics;
          

    // ------------------------------------------
    //     Loop over the harmonics
    // ------------------------------------------

    for (i=0; i < iNoOfHarmonics; i++, pstHarmonic++) {                        
        GetRandomPhase(pstRec,
                       &pstHarmonic->fSinPhase,
                       &pstHarmonic->fCosPhase);
    } // end of loop over the harmonics

}





/*----------------------------------------------------------------------------
 * FUNCTION NAME:  get_phase_excite
 *
 * PURPOSE:  Get LPC excitation phase at given frequency   
 *
 * INPUT:
 *   fOmega - normalized frequency, (Nyquist --> 1)
 * RETURN VALUE:
 *   the phase value (radian)
 *---------------------------------------------------------------------------*/
static float get_phase_excite(float fOmega)
{


static float pfPhaseModel[257] = {
0.000000f,
0.577271f,
0.471039f,
0.402039f,
0.341461f,
0.282104f,
0.221069f,
0.157074f,
0.089905f,
0.019989f,
-0.051819f,
-0.124237f,
-0.195770f,
-0.264679f,
-0.328705f,
-0.385162f,
-0.430573f,
-0.460846f,
-0.472351f,
-0.464783f,
-0.444977f,
-0.425323f,
-0.415466f,
-0.418579f,
-0.433502f,
-0.457764f,
-0.488617f,
-0.523315f,
-0.559174f,
-0.593689f,
-0.625031f,
-0.652130f,
-0.674835f,
-0.693390f,
-0.707428f,
-0.715729f,
-0.717133f,
-0.713837f,
-0.713104f,
-0.723785f,
-0.750366f,
-0.791931f,
-0.845093f,
-0.905945f,
-0.970825f,
0.963654f,
0.901123f,
0.846222f,
0.805481f,
0.788788f,
0.807312f,
0.857269f,
0.904724f,
0.922668f,
0.913757f,
0.888916f,
0.856750f,
0.823730f,
0.796082f,
0.781250f,
0.786346f,
0.809631f,
0.831787f,
0.831818f,
0.806122f,
0.761841f,
0.707184f,
0.649353f,
0.595245f,
0.553375f,
0.535004f,
0.551025f,
0.593689f,
0.629669f,
0.641205f,
0.637146f,
0.630432f,
0.626068f,
0.618439f,
0.597534f,
0.558716f,
0.504242f,
0.439545f,
0.371796f,
0.314423f,
0.322479f,
0.692352f,
0.820557f,
0.775940f,
0.703735f,
0.625885f,
0.549744f,
0.479889f,
0.420258f,
0.374023f,
0.341888f,
0.319366f,
0.297546f,
0.268768f,
0.230896f,
0.186066f,
0.137939f,
0.090027f,
0.045288f,
0.005859f,
-0.026398f,
-0.049316f,
-0.059448f,
-0.052521f,
-0.028687f,
-0.000732f,
0.012024f,
0.001312f,
-0.028900f,
-0.070801f,
-0.117004f,
-0.160583f,
-0.194824f,
-0.214020f,
-0.217743f,
-0.215424f,
-0.221161f,
-0.241730f,
-0.274475f,
-0.313202f,
-0.351440f,
-0.384247f,
-0.409363f,
-0.428986f,
-0.449249f,
-0.476257f,
-0.512085f,
-0.555054f,
-0.601379f,
-0.646881f,
-0.687469f,
-0.720123f,
-0.743896f,
-0.760712f,
-0.774292f,
-0.786865f,
-0.796417f,
-0.797058f,
-0.782288f,
-0.753052f,
-0.723755f,
-0.710052f,
-0.714722f,
-0.731720f,
-0.753998f,
-0.776672f,
-0.797760f,
-0.817749f,
-0.838562f,
-0.861664f,
-0.887115f,
-0.913971f,
-0.941437f,
-0.969849f,
0.999176f,
0.963562f,
0.922089f,
0.875092f,
0.824432f,
0.773285f,
0.726074f,
0.688934f,
0.669617f,
0.674377f,
0.698090f,
0.719421f,
0.721069f,
0.702698f,
0.671631f,
0.634674f,
0.596527f,
0.559784f,
0.525757f,
0.494995f,
0.468231f,
0.446991f,
0.433105f,
0.427216f,
0.426483f,
0.424225f,
0.414124f,
0.393951f,
0.365723f,
0.333374f,
0.301086f,
0.272278f,
0.249054f,
0.231750f,
0.219360f,
0.211182f,
0.207703f,
0.209747f,
0.215332f,
0.217590f,
0.208527f,
0.184631f,
0.147583f,
0.101593f,
0.051697f,
0.002960f,
-0.039154f,
-0.068756f,
-0.080597f,
-0.073730f,
-0.055573f,
-0.038666f,
-0.030792f,
-0.033630f,
-0.047180f,
-0.072174f,
-0.109039f,
-0.156860f,
-0.213318f,
-0.275146f,
-0.338562f,
-0.398956f,
-0.450836f,
-0.487793f,
-0.505707f,
-0.510162f,
-0.518524f,
-0.545410f,
-0.592499f,
-0.654510f,
-0.725586f,
-0.801025f,
-0.877136f,
-0.950897f,
0.980316f,
0.918762f,
0.866211f,
0.824219f,
0.795319f,
0.786377f,
0.810913f,
0.872406f,
0.925385f,
0.926483f,
0.882111f,
0.808807f,
0.716248f,
0.608063f,
0.480927f,
0.310974f,
-0.054810f,
-0.554077f,
-0.763275f,
-0.904968f,
0.977448f,
0.884125f,
0.849152f,
0.999969f };



  int iIndex;
  float fExcPhase;

  iIndex = (int)floor((double)fOmega*256.0 + 0.5);

  fExcPhase = pfPhaseModel[iIndex];

  return fExcPhase;

}


/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GenerateAdditionalPhase
 *
 * PURPOSE:   For voiced harmonics compute the all-pole model derived phase 
 *            plus prestored residual domain phase, and "add" to the phase
 *            stored in  pstRec->pstHarmonicInfo[].fCosPhase and
              pstRec->pstHarmonicInfo[].fSinPhase
 * INPUT/OUTPUT:
 *   pstRec - pointer to the Reconstructor
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GenerateAdditionalPhase(Reconstructor *pstRec)
{

  int i;
  int iNHar;

  float fOmega;
  float fExcPhase;  
  float fPhase;

  float fFundOmega;
  float fFundPhase=0;
  float fFundPhaseRunSum;
  float fInvEnvPhase;
  float fCosPhase, fSinPhase;

  HarmonicInfo *pstHarmonic;



  pstHarmonic = pstRec->pstHarmonicInfo;
  iNHar = pstRec->iNoOfPitchHarmonics;


  
    /*
     * Get the excitation domain phase for the pitch harmonics
     */

    fFundOmega = 2.0f / pstRec->fPitchPeriod;
    fFundPhaseRunSum = 0.0;
    for (i = 0; i < iNHar; i++)
    {
      fOmega = (float)(i+1) * fFundOmega;
      fExcPhase = get_phase_excite(fOmega);
      fInvEnvPhase = APM_sample_phase(pstRec,i);


      fPhase = fExcPhase - 2.0f*fInvEnvPhase;

      /*
       * Remove the linear phase component due to fundamental    
       */

      if (0 == i) fFundPhase = fPhase;
      fFundPhaseRunSum += fFundPhase;
      fPhase -= fFundPhaseRunSum;

      /*
       * Wrap the phases to be within [-1,1)
       */
      while (fPhase >= 1.0)
      {
        fPhase -= 2.0;
      }

      while (fPhase < -1.0)
      {
        fPhase += 2.0;    
      }

      fPhase *= M_PI;
      fCosPhase = (float)cos(fPhase);
      fSinPhase = (float)sin(fPhase);
      AddPhase(pstHarmonic[i].fCosPhase, pstHarmonic[i].fSinPhase,
               fCosPhase,fSinPhase,
               &(pstHarmonic[i].fCosPhase),&(pstHarmonic[i].fSinPhase));
    }
                           

  
  return;

}



