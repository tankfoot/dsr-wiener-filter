/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: interp_mag.c
 * PURPOSE:   INTERP magnitudes reconstruction method implementation
 *
 *-------------------------------------------------------------------------------*/

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "common.h"




/*----------------------------------------------------------------------------
 * FUNCTION NAME:  GetMissingMfccCentroid
 *
 * PURPOSE:   Determine initial values for HOC (High Order Cepstra)
 * INPUT:
 *   pstRec   - pointer to the Reconstructor
 *   fPitchPeriod - pitch period (positive)
 * OUTPUT:
 *   pfMissCeps - array of 10 HOC
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void GetMissingMfccCentroid(Reconstructor *pstRec,                       
                            float         fPitchPeriod,
                            float         *pfMissCeps)
                        
{
    int i, j;
    static const int iMissDim = NUM_OF_FILTERS - STD_NUM_CEPS;
    float *pfPitchThld = pstRec->pfMissMfccPitchThld;
    float *pfMissingVal = pstRec->pfMissMfccCentroids;
                        
    if (NULL == pfMissingVal) return;

    for (j=0; j<pstRec->iNoOfMissMfccCentroids &&
    fPitchPeriod > pfPitchThld[j]; j++);
    if (j== pstRec->iNoOfMissMfccCentroids) j--;
 
            
    for (i = 0; i < iMissDim; i++)      
        pfMissCeps[i] = pfMissingVal[iMissDim*j + i];
      
}

/*----------------------------------------------------------------------------
 * FUNCTION NAME:  INTERP_ReconstructMagnitudes
 *
 * PURPOSE:   Reconstruct harmonic magnitudes by INTERP method
 * INPUT:
 *   pstRec   - pointer to the Reconstructor
 *   fPitchPeriod - pitch period
 *   iNoOfHarmonics - the number of the harmonics
 *   pfCep - MFCC vector
 * INPUT/OUTPUT:
 *   pstHarmonicInfo - array of the harmonics
 * RETURN VALUE:
 *   none
 *---------------------------------------------------------------------------*/
void INTERP_ReconstructMagnitudes(Reconstructor *pstRec,
                                  float         fPitchPeriod,
                                  int           iNoOfHarmonics,
                                  HarmonicInfo  *pstHarmonicInfo,
                                  float         *pfCep)
{
    
  int i,j;
  int iBinIndex;

  float pfTempCep[NUM_OF_FILTERS];
  float *pfCBinMelFreq;
  float *pfFixCep;

  float fMelFreq;
  float fMelIndex;
  float fMelIndexTemp=0;
  float fTemp;
  float fFreq;
  int iNumCep;
  int iSampFreq;
  HarmonicInfo *pstHarmonic;
  float *pfAmp;



  iSampFreq = pstRec->iSampleRate;
  

  /*
   *  Copy the input cepstra excluding C0 to a working buffer
   */

  for (i = 0; i < pstRec->iCepstralDim-1; i++)
      pfTempCep[i] = pfCep[i];
   
  /* HOC recovery */
  if (fPitchPeriod > 0.f)
  {
        GetMissingMfccCentroid(pstRec,fPitchPeriod,
                               &(pfTempCep[STD_NUM_CEPS-1]));                            
        iNumCep = NUM_OF_FILTERS;
	pfFixCep = pstRec->pfFixCep23_INTERP;
  }
  else
  {
    /*
     * Pitch period is zero
     */           
        iNumCep = pstRec->iCepstralDim;
	pfFixCep = pstRec->pfFixCep13_INTERP;
  }


  pfTempCep[iNumCep-1] = pfCep[pstRec->iCepstralDim -1];
  for (i = 0; i < iNumCep; i++)
        pfTempCep[i] -= pfFixCep[i];


  pfCBinMelFreq = pstRec->pfCBinMelFreq_INTERP;


  pstHarmonic = pstHarmonicInfo;
  for (i = 0; i < iNoOfHarmonics; i++, pstHarmonic++)
  {

        pfAmp = &(pstHarmonic->fAmpIM);


    /*
     * Calculate the Mel-frequency index in the range [0.5,23.5]
     * for each frequency at which the spectral amplitude has to
     * be estimated
     */

    fFreq = pstHarmonic->fFreqHz;
    
    fMelFreq = 2595.0f * (float)log10(1.0 + fFreq/700.0);

    iBinIndex = 1;
    while (fMelFreq > pfCBinMelFreq[iBinIndex])
    {
      iBinIndex++;
      if (iBinIndex == 24)
      {
        break;
      }
    }

    if (iBinIndex == 1)
    {
      if (fMelFreq < ((pfCBinMelFreq[0]+pfCBinMelFreq[1])/2.0))
      {
        fMelIndex = 0.5f;
        fMelIndexTemp = fMelFreq/((pfCBinMelFreq[0]+pfCBinMelFreq[1])/2.0f);
      }
      else
      {
        fMelIndex = (fMelFreq-pfCBinMelFreq[0]) /
                    (pfCBinMelFreq[1]-pfCBinMelFreq[0]);
      }
    }
    else if (iBinIndex == 24)
    {
      if (fMelFreq > pfCBinMelFreq[24])
      {
        fMelFreq = pfCBinMelFreq[24];
      }
      if (fMelFreq > ((pfCBinMelFreq[23]+pfCBinMelFreq[24])/2.0f))
      {
        fMelIndex = 23.5f;
        fMelIndexTemp = (pfCBinMelFreq[24]-fMelFreq) /
                        ((pfCBinMelFreq[24]-pfCBinMelFreq[23])/2.0f);
      }
      else
      {
        fMelIndex = 23.0f + (fMelFreq-pfCBinMelFreq[23]) /
                            (pfCBinMelFreq[24]-pfCBinMelFreq[23]);
      }
    }
    else
    {
      fMelIndex = (float)(iBinIndex - 1) +
                  (fMelFreq-pfCBinMelFreq[iBinIndex-1]) /
                  (pfCBinMelFreq[iBinIndex]-pfCBinMelFreq[iBinIndex-1]);
    }


    /*
     * Perform inverse DCT at that index and exponentiate to get
     * the spectral amplitude
     */

    fTemp = pfTempCep[iNumCep-1] / 23.0f;

    for (j = 0; j < iNumCep-1; j++)
    {
      fTemp += pfTempCep[j]*(2.0f/23.0f)*
                 (float)cos((2.0*fMelIndex-1)*((double)j+1.0)*M_PI/(2.0*23.0));
    }

    *pfAmp = (float)exp(fTemp);

    if (fMelIndex == 0.5f || fMelIndex == 23.5f)
    {
      *pfAmp *= fMelIndexTemp;
    }
    
  }

  pstHarmonic = pstHarmonicInfo;
  for (i = 0; i < iNoOfHarmonics; i++)
    {
      pfAmp = &(pstHarmonic[i].fAmpIM);
      *pfAmp = (float)sqrt(*pfAmp);
    }


  return;

}


