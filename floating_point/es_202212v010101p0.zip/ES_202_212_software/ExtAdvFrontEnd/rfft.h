/*===============================================================================
 *      ETSI ES 202 212   Distributed Speech Recognition
 *      Extended Advanced Front-End Feature Extraction Algorithm & Compression Algorithm
 *      Speech Reconstruction Algorithm.
 *      C-language software implementation                                      
 *      Version 1.1.1   October, 2003                                            
 *===============================================================================*/
/*-------------------------------------------------------------------------------
 *
 * FILE NAME: rfft.h
 * PURPOSE: Real valued, in-place split-radix FFT.
 *
 *-------------------------------------------------------------------------------*/
#ifndef _RFFT_H
#define _RFFT_H

#ifdef M_PI
#undef M_PI
#endif
#define M_PI        3.14159265358979323846
#ifdef M_SQRT2
#undef M_SQRT2
#endif
#define M_SQRT2     1.41421356237309504880

void rfft (float *x, int n, int m);

#endif
